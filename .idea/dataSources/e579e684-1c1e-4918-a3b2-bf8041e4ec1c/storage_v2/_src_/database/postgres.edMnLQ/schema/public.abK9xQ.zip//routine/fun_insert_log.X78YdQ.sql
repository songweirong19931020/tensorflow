create function fun_insert_log(v_butype character varying, v_rundt character varying, v_pname character varying, v_stepname character varying, v_flag character varying, v_remark character varying)
  returns integer
language plpgsql
as $$
BEGIN
   insert into his_bi.etl_proc_log(run_dt,bu_type,proc_name,step_name, insert_dt,status,remark)
   values(v_rundt,
          v_butype,
          v_pname,
          v_stepname,
          now(),
          v_flag,
          v_remark);

   commit;
	 RETURN 0;
 EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                ROLLBACK;
                 return 1;
            END;   
	
END;
$$;

alter function fun_insert_log(varchar, varchar, varchar, varchar, varchar, varchar)
  owner to postgres;

