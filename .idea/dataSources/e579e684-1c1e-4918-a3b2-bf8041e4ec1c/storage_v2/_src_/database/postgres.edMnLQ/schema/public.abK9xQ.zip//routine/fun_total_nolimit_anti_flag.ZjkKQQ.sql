create function fun_total_nolimit_anti_flag(v_start_date character varying, v_end_date character varying)
  returns character varying
language plpgsql
as $$
BEGIN
 INSERT into his_bi.id_quality_antictrl(key,value,patient_id,visit_id,pai_visit_id,insert_date,remark,st_date) 
 select 'nolimit_anti_flag','1',tmp.patient_id,tmp.visit_id,tmp.pai_visit_id,now(),'使用非限制级抗菌药物标识', tmp.day_str 
   from (select to_char(pt.discharge_dept_date,'yyyyMMdd') as day_str,
							 pt.pai_visit_id,
							 pt.patient_id,
							 pt.visit_id
							   from his_bi.pts_pai_visit pt
								 where   pt.current_status = '5' 
								    and pt.patient_id not like '%-%' --排除新生儿
        and pt.discharge_dept_date >= to_date(v_start_date,'yyyyMMdd')
        and pt.discharge_dept_date <  his_bi.add_months(to_date(v_end_date,'yyyyMMdd'),1)
		  group by pt.discharge_dept_date,
               pt.pai_visit_id,
               pt.patient_id,
               pt.visit_id) tmp 
	    inner join his_bi.bms_bill_item bm 
			   on (tmp.pai_visit_id = bm.pai_visit_id and bm.in_out_flag = 'I')
			where exists (select 1 from his_bi.dms_pham_cust_def_cont 
			               where cont_type_id = 'TJ0055' 
										   and cont_value = '1' 
											 and pham_std_code = bm.item_code)
      group by tmp.day_str,
               tmp.pai_visit_id,
               tmp.patient_id,
               tmp.visit_id;
   RETURN 'SUCCESS';
	    
END;
$$;

alter function fun_total_nolimit_anti_flag(varchar, varchar)
  owner to postgres;

