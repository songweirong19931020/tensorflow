create function fun_total_records()
  returns integer
language plpgsql
as $$
DECLARE
  v_total integer;
	v_array_kpi_code VARCHAR[];
BEGIN
v_array_kpi_code :=array['D000069','D000070','D000071','D000083'];
  SELECT count(*) into v_total FROM pca_prepay_balance_test;  
   RETURN v_array_kpi_code[1];
END;
$$;

alter function fun_total_records()
  owner to postgres;

