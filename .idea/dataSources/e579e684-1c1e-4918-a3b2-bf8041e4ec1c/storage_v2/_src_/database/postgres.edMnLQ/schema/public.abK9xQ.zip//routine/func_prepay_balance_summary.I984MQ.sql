create function func_prepay_balance_summary(OUT o_monthstr text, OUT o_num text)
  returns SETOF record
language plpgsql
as $$
DECLARE
	v_rec record;
BEGIN
		FOR v_rec IN SELECT
		to_char( A.trans_time, 'MM' ) AS monthStr,
		COUNT ( * ) AS num 
	FROM
		PCA_PREPAY_BALANCE_TEST A 
	GROUP BY
		to_char( A.trans_time, 'MM' )
		loop
		o_monthStr := v_rec.monthStr;
	o_num := v_rec.num;
	RETURN NEXT;
	
END loop;

END;
$$;

alter function func_prepay_balance_summary(out text, out text)
  owner to postgres;

