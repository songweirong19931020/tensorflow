create function fun_dw_outp_patient_info_m(v_start_month character varying, v_end_month character varying)
  returns character varying
language plpgsql
as $$
/***
函数名称：门诊患者就诊相关指标月汇总
    作用：汇总统计某月门诊患者相关指标
  开发人：liuf 2020-05-09
命名规范：FUN_模型层级(DW)_业务解释_日期类型M，M表示按月统计
业务解释：根据保存数据的DW表规划来的
    入参：v_start_month，v_end_month  格式均为yyyymm，可以一次运行多天的数据
		
		说明：由于采用INSERT INTO SELECT方式进行数据汇总后，再将结果插入到目标表的方式，
				  性能较低，可能会导致函数执行超过PG配置项statment_timeout所配置的超时时长，
				  从而导致函数执行被PG终结，采用PG COPY特性能大幅度提升该业务场景性能，操作步骤如下：
					1. 执行COPY TO命令将SELECT结果保存csv临时文件
					2. 执行COPY FROM命令将临时文件数据加载到目标表
					注意：该方案适用于数据量大且性能低下的统计，性能能满足要求的，为了方便开发、维护，可继续使用INSERT INTO SELECT方案
***/
DECLARE
  c_monthlist   record;
  o_start_month varchar;
  o_end_month   varchar;
  i_start_month varchar;
  i_end_month   varchar;
  i_count       int4;
	tmp_file 			varchar;  --COPY方案临时文件名：该文件将被保存在所连接的服务器的文件目录。
BEGIN
	/*
	  COPY方案临时文件名。
		注意：
		1. 该文件将被保存在所连接的服务器的文件目录中，每一个函数必须使用自定义能够与其他函数区分的文件名
		2. 方便维护，历史文件都保存到'/home/postgres/'目录中。
		TODO : 后续规划统一临时文件目录，KETTLE调度完成之后，需要删除对应的临时文件（*需要想办法在每台服务器上统一创建临时目录）
	*/
	tmp_file := '/home/postgres/fun_dw_outp_patient_info_m.csv';
	
  /*如果指标没有历史指标数据，甘肃默认以202001开始计算，结束月份以当前月份往前推1个月*/
  select count(1),to_char((date_trunc('month', now()) + interval '-1 month'),'yyyymm')
	       into i_count,i_end_month
    from his_bi.dw_outp_patient_info_m;
   
  if(i_count = 0)
    then 
      i_start_month := '202001';
      --raise notice '0 i_start_month is: %', i_start_month;
  else if(i_count > 0)
    then
      i_start_month := i_end_month;
      --raise notice '1 i_start_month is: %', i_start_month;
  end if;
  end if;
    
  if(length(trim(v_start_month)) = 0 and length(trim(v_end_month)) = 0)
  /*kettle 调用时，如果不设置参数，默认传入 空字符串，那么默认取当前月份前1个月为截止月份 */
    then 
      o_start_month := i_start_month;
      o_end_month := i_end_month;
      --raise notice '2 o_start_month is: %', o_start_month;
      --raise notice '2 o_end_month is: %', o_end_month;
  else if (length(trim(v_start_month)) <> 0 and length(trim(v_end_month)) <> 0)
  /*PG function 如果参入任何参数，那么以实际入参为准*/
    then 
      o_start_month := v_start_month;
      o_end_month := v_end_month;
      --raise notice '3 o_start_month is: %', o_start_month;
      --raise notice '3 o_end_month is: %', o_end_month;
  end if;
  end if;
  
  for c_monthlist in (select distinct month_id from his_bi.dim_date_info where month_id >= o_start_month and month_id <= o_end_month order by month_id)
  loop 
  
   --raise notice '4 c_monthlist.month_id is: %', c_monthlist.month_id;
   
    delete from his_bi.dw_outp_patient_info_m where month_id = c_monthlist.month_id;
		 
	  insert into his_bi.dw_outp_patient_info_m
		select c_monthlist.month_id                                                           as month_id,
       pt.patient_id,
       pt.visit_id,
       pt.outp_visit_id,
       pt.pati_name,
       case
           when pt.birth_date > now() then -1
           else cast(split_part(cast(age(CURRENT_DATE, pt.birth_date) as text), ' ', 1) as numeric)
           end                                                            as pati_age,
			 pt.pati_sex,
			 pt.dept_code,
			 pt.visit_begin_date,
			 pt.ghsj,
			 wd1.outp_type_code                                            as outp_type_code,
				wd1.return_visit                                              as return_visit,
				wd1.registry_resource                                         as registry_resource,
				wd1.is_emergency                                              as is_emergency,
				wd1.is_keep                                                   as is_keep,
				wd1.is_tj                                                     as is_tj,
				wd1.is_visited                                                as is_visited,
				wq1.is_use_fxzjkjy                                         as is_use_fxzjkjy,
				wq1.is_use_xzjkjyw                                            as is_use_xzjkjyw,
				wq1.is_use_tsjkjyw                                            as is_use_tsjkjyw,
				wq1.cf_num                                                    as cf_num,
				wq1.kjyw_cf_num                                               as kjyw_cf_num,
				wq1.jmsy_cf_num                                               as jmsy_cf_num,
				wq1.jz_cf_num                                                 as jz_cf_num,
				wq1.jz_kjyw_cf_num                                            as jz_kjyw_cf_num,
				wq1.jz_jmsy_cf_num                                            as jz_jmsy_cf_num,
				wd1.is_yygh                                                   as is_yygh,
				wd1.is_yyjc                                                   as is_yyjc,
				wq1.kjyw_ddd_sum                                              as kjyw_ddd_sum,
				wq1.fxzj_kjyw_ddd_sum                                         as fxzj_kjyw_ddd_sum,
				wq1.xzj_kjyw_ddd_sum                                          as xzj_kjyw_ddd_sum,
				wq1.tsj_kjyw_ddd_sum                                          as tsj_kjyw_ddd_sum,
				split_part(cast(age(CURRENT_DATE, pt.birth_date) as text), ' ', 2) as age_tag,
				pt.outp_special_id,
				pt.hospital_area_code,
				wg1.outp_diag_code                                            as outp_diag_code,
				wg1.outp_diag_name                                            as outp_diag_name,
				wg1.outp_diag_strcode                                         as outp_diag_strcode,
				wg1.outp_diag_strname                                         as outp_diag_strname,
				pt.admission_doctor,
				um.people_name,
				wq18.value                                                   as total_fees
				from his_bi.pts_outp_patient_visit pt
								 left join his_bi.uum_uum_user um on pt.admission_doctor = um.user_name
								 left join (
						select wd1.outp_visit_id,
									 max(case when wd1.key = 'D00132' then wd1.value end)              as outp_type_code,
									 max(case when wd1.key = 'D00135' then wd1.value end)              as return_visit,
									 max(case when wd1.key = 'D00138' then wd1.value end)              as registry_resource,
									 max(case when wd1.key = 'D00129' then wd1.value end)              as is_emergency,
									 max(case when wd1.key = 'D00130' then wd1.value end)              as is_keep,
									 max(case when wd1.key = 'D00131' then wd1.value end)              as is_tj,
									 max(case when wd1.key = 'D00133' then COALESCE(wd1.value, 0) end) as is_visited,
									 max(case when wd1.key = 'D00139' then wd1.value end)              as is_yygh,
									 max(case when wd1.key = 'D00140' then wd1.value end)              as is_yyjc
						from his_bi.dwd_outp_work_d wd1
						inner join his_bi.dim_date_info d4 on wd1.st_date = d4.day_id and d4.month_id = c_monthlist.month_id
						where wd1.key in ('D00132', 'D00135', 'D00138', 'D00129', 'D00130', 'D00131', 'D00133', 'D00139', 'D00140')
						group by wd1.outp_visit_id
				) wd1 on pt.outp_visit_id = wd1.outp_visit_id
								 left join (
						select
									 wq1.outp_visit_id,
									 max(case when wq1.key = 'D00032' then wq1.value end) as is_use_fxzjkjy,
									 max(case when wq1.key = 'D00033' then wq1.value end) as is_use_xzjkjyw,
									 max(case when wq1.key = 'D00034' then wq1.value end) as is_use_tsjkjyw,
									 sum(case when wq1.key = 'D00035' then wq1.value end) as cf_num,
									 sum(case when wq1.key = 'D00036' then wq1.value end) as kjyw_cf_num,
									 sum(case when wq1.key = 'D00037' then wq1.value end) as jmsy_cf_num,
									 sum(case when wq1.key = 'D00038' then wq1.value end) as jz_cf_num,
									 sum(case when wq1.key = 'D00039' then wq1.value end) as jz_kjyw_cf_num,
									 sum(case when wq1.key = 'D00040' then wq1.value end) as jz_jmsy_cf_num,
									 sum(case when wq1.key = 'D00141' then wq1.value end) as kjyw_ddd_sum,
									 sum(case when wq1.key = 'D00142' then wq1.value end) as fxzj_kjyw_ddd_sum,
									 sum(case when wq1.key = 'D00143' then wq1.value end) as xzj_kjyw_ddd_sum,
									 sum(case when wq1.key = 'D00144' then wq1.value end) as tsj_kjyw_ddd_sum
						from his_bi.dwd_outp_quantity_d wq1
						inner join his_bi.dim_date_info d5 on wq1.st_date = d5.day_id and d5.month_id = c_monthlist.month_id
						where wq1.key in
									('D00032', 'D00033', 'D00034', 'D00035', 'D00036', 'D00037', 'D00038', 'D00039', 'D00040', 'D00141', 'D00142',
									 'D00143', 'D00144')
						group by wq1.outp_visit_id
				) wq1 on pt.outp_visit_id = wq1.outp_visit_id
								 left join (
						select wg1.st_date,
									 wg1.patient_id,
									 wg1.visit_id,
									 max(case when wg1.key = 'D00248' then wg1.value end) as outp_diag_code,
									 max(case when wg1.key = 'D00250' then wg1.value end) as outp_diag_name,
									 max(case when wg1.key = 'D00249' then wg1.value end) as outp_diag_strcode,
									 max(case when wg1.key = 'D00251' then wg1.value end) as outp_diag_strname
						from his_bi.dwd_outp_diag_d wg1
						where wg1.key in ('D00248', 'D00249', 'D00250', 'D00251')
						group by wg1.st_date,
										 wg1.patient_id,
										 wg1.visit_id
				) wg1 on pt.patient_id = wg1.patient_id and pt.visit_id = wg1.visit_id
								 left join his_bi.dim_date_info d2 on wg1.st_date = d2.day_id and d2.month_id = c_monthlist.month_id
								 left join (select ind.outp_visit_id, sum(ind.value) as value
														from his_bi.dwd_outp_income_d ind
														inner join his_bi.dim_date_info d6 on ind.st_date = d6.day_id and d6.month_id = c_monthlist.month_id
														where ind.key = 'D00014'
														group by ind.outp_visit_id) wq18
													 on pt.outp_visit_id = wq18.outp_visit_id
				where 1 = 1
					and pt.registry_flag IN ('0', '1')
					---and pt.outp_visit_id='270799'
					and pt.ghsj >= to_date(c_monthlist.month_id, 'yyyymm')
					and pt.ghsj < to_date(c_monthlist.month_id, 'yyyymm') + interval '1' month;
				 
   end loop;
   RETURN 'SUCCESS';  
END;
$$;

alter function fun_dw_outp_patient_info_m(varchar, varchar)
  owner to postgres;

