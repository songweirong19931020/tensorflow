create function fun_dw_outp_patient_amount_m(v_start_month character varying, v_end_month character varying)
  returns character varying
language plpgsql
as $$
/***
函数名称：门诊患者费用相关指标月汇总
    作用：汇总统计某月门诊患者费用相关指标
  开发人：wy 2020-05-12
命名规范：FUN_模型层级(DW)_业务解释_日期类型M，M表示按月统计
业务解释：根据保存数据的DW表规划来的
    入参：v_start_month，v_end_month  格式均为yyyymm，可以一次运行多天的数据
		
		说明：由于采用INSERT INTO SELECT方式进行数据汇总后，再将结果插入到目标表的方式，
				  性能较低，可能会导致函数执行超过PG配置项statment_timeout所配置的超时时长，
				  从而导致函数执行被PG终结，采用PG COPY特性能大幅度提升该业务场景性能，操作步骤如下：
					1. 执行COPY TO命令将SELECT结果保存csv临时文件
					2. 执行COPY FROM命令将临时文件数据加载到目标表
					注意：该方案适用于数据量大且性能低下的统计，性能能满足要求的，为了方便开发、维护，可继续使用INSERT INTO SELECT方案
***/
DECLARE
  c_monthlist   record;
  o_start_month varchar;
  o_end_month   varchar;
  i_start_month varchar;
  i_end_month   varchar;
  i_count       int4;
	tmp_file 			varchar;  --COPY方案临时文件名：该文件将被保存在所连接的服务器的文件目录。
BEGIN
	/*
	  COPY方案临时文件名。
		注意：
		1. 该文件将被保存在所连接的服务器的文件目录中，每一个函数必须使用自定义能够与其他函数区分的文件名
		2. 方便维护，历史文件都保存到'/home/postgres/'目录中。
		TODO : 后续规划统一临时文件目录，KETTLE调度完成之后，需要删除对应的临时文件（*需要想办法在每台服务器上统一创建临时目录）
	*/
	tmp_file := '/home/postgres/fun_dw_outp_patient_amount_m.csv';
	
  /*如果指标没有历史指标数据，甘肃默认以202001开始计算，结束月份以当前月份往前推1个月*/
  select count(1),to_char((date_trunc('month', now()) + interval '-1 month'),'yyyymm')
	       into i_count,i_end_month
    from his_bi.dw_outp_patient_amount_m;
   
  if(i_count = 0)
    then 
      i_start_month := '202001';
      --raise notice '0 i_start_month is: %', i_start_month;
  else if(i_count > 0)
    then
      i_start_month := i_end_month;
      --raise notice '1 i_start_month is: %', i_start_month;
  end if;
  end if;
    
  if(length(trim(v_start_month)) = 0 and length(trim(v_end_month)) = 0)
  /*kettle 调用时，如果不设置参数，默认传入 空字符串，那么默认取当前月份前1个月为截止月份 */
    then 
      o_start_month := i_start_month;
      o_end_month := i_end_month;
      --raise notice '2 o_start_month is: %', o_start_month;
      --raise notice '2 o_end_month is: %', o_end_month;
  else if (length(trim(v_start_month)) <> 0 and length(trim(v_end_month)) <> 0)
  /*PG function 如果参入任何参数，那么以实际入参为准*/
    then 
      o_start_month := v_start_month;
      o_end_month := v_end_month;
      --raise notice '3 o_start_month is: %', o_start_month;
      --raise notice '3 o_end_month is: %', o_end_month;
  end if;
  end if;
  
  for c_monthlist in (select distinct month_id from his_bi.dim_date_info where month_id >= o_start_month and month_id <= o_end_month order by month_id)
  loop 
  
   --raise notice '4 c_monthlist.month_id is: %', c_monthlist.month_id;
   
    delete from his_bi.dw_outp_patient_amount_m where month_id = c_monthlist.month_id;
		 
	  -- 执行COPY命令，保存统计结果到临时文件（tmp_file）
		execute '
    copy (
		
		select
        '''||c_monthlist.month_id||''' as month_id,
        t1.patient_id,
        t1.visit_id,
        sum(case when t1.key=''D00014'' and d1.month_id='''||c_monthlist.month_id||''' then t1.value else 0 end  ) as total_fees,
        sum(case when t1.key=''D00017'' and d1.month_id='''||c_monthlist.month_id||''' then t1.value else 0 end  ) as pham_fees,
        sum(case when t1.key=''D00016'' and d1.month_id='''||c_monthlist.month_id||''' then t1.value else 0 end  ) as material_fees,
        sum(case when t1.key=''D00018'' and d1.month_id='''||c_monthlist.month_id||''' then t1.value else 0 end  ) as inspect_fees,
        sum(case when t1.key=''D00021'' and d1.month_id='''||c_monthlist.month_id||''' then t1.value else 0 end  ) as examination_fees,
				sum(case when t1.key=''D00020'' and d1.month_id='''||c_monthlist.month_id||''' then t1.value else 0 end  ) as cur_fees,
        sum(case when t1.key=''D00022'' and d1.month_id='''||c_monthlist.month_id||''' then t1.value else 0 end  ) as western_fees,
				sum(case when t1.key=''D00024'' and d1.month_id='''||c_monthlist.month_id||''' then t1.value else 0 end  ) as herb_fees,
        sum(case when t1.key=''D00023'' and d1.month_id='''||c_monthlist.month_id||''' then t1.value else 0 end  ) as chinese_patent_fees,
				sum(case when t1.key=''D00025'' and d1.month_id='''||c_monthlist.month_id||''' then t1.value else 0 end  ) as anti_pham_fees,
				sum(case when t1.key=''D00019'' and d1.month_id='''||c_monthlist.month_id||''' then t1.value else 0 end  ) as check_fees,
				sum(case when t1.key=''D00015'' and d1.month_id='''||c_monthlist.month_id||''' then t1.value else 0 end  ) as service_fess,
        sum(case when t1.key=''D00026'' and d1.month_id='''||c_monthlist.month_id||''' then t1.value else 0 end  ) as support_fess,
        sum(case when t1.key=''D00027'' and d1.month_id='''||c_monthlist.month_id||''' then t1.value else 0 end  ) as basic_fess,
        sum(case when t1.key=''D00028'' and d1.month_id='''||c_monthlist.month_id||''' then t1.value else 0 end  ) as key_point_fess,
        sum(case when t1.key=''D00029'' and d1.month_id='''||c_monthlist.month_id||''' then t1.value else 0 end  ) as non_res_fess,
        sum(case when t1.key=''D00030'' and d1.month_id='''||c_monthlist.month_id||''' then t1.value else 0 end  ) as res_fess,
        sum(case when t1.key=''D00031'' and d1.month_id='''||c_monthlist.month_id||''' then t1.value else 0 end  ) as special_fess,
        sum(case when t1.key=''D00145'' and d1.month_id='''||c_monthlist.month_id||''' then t1.value else 0 end  ) as tj_fess,
        sum(case when t1.key=''D00146'' and d1.month_id='''||c_monthlist.month_id||''' then t1.value else 0 end  ) as nurse_fess,
        sum(case when t1.key=''D00147'' and d1.month_id='''||c_monthlist.month_id||''' then t1.value else 0 end  ) as operation_fess,
        sum(case when t1.key=''D00148'' and d1.month_id='''||c_monthlist.month_id||''' then t1.value else 0 end  ) as tdsp_fess,
        sum(case when t1.key=''D00149'' and d1.month_id='''||c_monthlist.month_id||''' then t1.value else 0 end  ) as yntj_fess,
        sum(case when t1.key=''D01001'' and d1.month_id='''||c_monthlist.month_id||''' then t1.value else 0 end  ) as other_fees
    from his_bi.dwd_outp_income_d t1 
    left join his_bi.dim_date_info d1 on t1.st_date = d1.day_id and d1.month_id = '''||c_monthlist.month_id||'''
   where 1=1
     and t1.key in(''D00014'',''D00017'',''D00015'',''D00016'',''D00018'',
''D00019'',''D00020'',''D00021'',''D00022'',''D00023'',''D00024'',''D00025'',''D00026'',''D00027'',
''D00028'',''D00029'',''D00030'',''D00031'',''D00145'',''D00146'',''D00147'',''D00148'',''D00149'',''D01001'')
     and d1.month_id = '''||c_monthlist.month_id||'''
   group by
        t1.patient_id,
        t1.visit_id)to '''||tmp_file||''' WITH CSV' ;
			
			---- 执行COP FROM Y命令，将统计结果从临时文件加载到目标表（tmp_file）
      execute 'COPY his_bi.dw_outp_patient_amount_m FROM '''||tmp_file||''' WITH csv';
				 
   end loop;
   RETURN 'SUCCESS';  
END;
$$;

alter function fun_dw_outp_patient_amount_m(varchar, varchar)
  owner to postgres;

