create function "fun_dwd_D00092_d"(v_start_date character varying, v_end_date character varying)
  returns character varying
language plpgsql
as $$
/***
函数名称：是否微生物检验样本送检
    作用：是否微生物检验样本送检
  开发人：hamter.lize 2020年5月8日
命名规范：FUN_模型层级(DWD或者DW)_KPI编码_日期类型D或者M，D表示按天统计，M表示按月统计
 KPI编码：D00092  根据原子指标编码规划来的
    入参：v_start_date，v_end_date  格式均为yyyymmdd，可以一次运行多天的数据
***/
DECLARE
	c_daylist record;
	o_start_date varchar;
	o_end_date varchar;
	i_start_date varchar;
	i_end_date varchar;
	i_count  int4;
BEGIN

   RETURN 'SUCCESS';  
END;
$$;

alter function "fun_dwd_D00092_d"(varchar, varchar)
  owner to postgres;

