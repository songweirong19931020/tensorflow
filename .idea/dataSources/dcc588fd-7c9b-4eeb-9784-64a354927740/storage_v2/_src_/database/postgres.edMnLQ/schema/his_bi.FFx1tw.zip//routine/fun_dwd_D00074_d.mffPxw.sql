create function "fun_dwd_D00074_d"(v_start_date character varying, v_end_date character varying)
  returns character varying
language plpgsql
as $$
/***
函数名称：住院患者中医治疗费
    作用：统计某天住院患者中医治疗费（以病案首页归档数据中的费用数据为准）
  开发人：wy 2020-04-10
命名规范：FUN_模型层级(DWD或者DW)_KPI编码_日期类型D或者M，D表示按天统计，M表示按月统计
 KPI编码：D00074  根据原子指标编码规划来的
    入参：v_start_date，v_end_date  格式均为yyyymmdd，可以一次运行多天的数据
***/
DECLARE
	c_daylist record;
	o_start_date varchar;
	o_end_date varchar;
	i_start_date varchar;
	i_end_date varchar;
	i_count  int4;
BEGIN

  /*如果指标没有历史指标数据，甘肃默认以20200101开始计算*/
	/*住院数据，每次运行当前日期前15天出院的患者，因为病案首页归档有2周左右的延迟*/
  select count(1),to_char(to_date(to_char(now(),'yyyymmdd'),'yyyymmdd') - 15,'yyyymmdd')
         into i_count,i_end_date
	  from his_bi.dwd_inp_income_d
	 where key = 'D00074';
	 
  if(i_count = 0)
	  then 
		  i_start_date := '20200101';
			--raise notice '0 i_start_date is: %', i_start_date;
	else if(i_count > 0)
	  then
		  i_start_date := i_end_date;
			--raise notice '1 i_start_date is: %', i_start_date;
  end if;
	end if;
		
  if(length(trim(v_start_date)) = 0 and length(trim(v_end_date)) = 0)
	/*kettle 调用时，如果不设置参数，默认传入 空字符串，那么默认取当前日期后退一天 */
	  then 
	    o_start_date := i_start_date;
	    o_end_date := i_end_date;
			--raise notice '2 o_start_date is: %', o_start_date;
			--raise notice '2 o_end_date is: %', o_end_date;
	else if (length(trim(v_start_date)) <> 0 and length(trim(v_end_date)) <> 0)
	/*PG function 如果参入任何参数，那么以实际入参为准*/
	  then 
		  o_start_date := v_start_date;
	    o_end_date := v_end_date;
			--raise notice '3 o_start_date is: %', o_start_date;
			--raise notice '3 o_end_date is: %', o_end_date;
	end if;
	end if;
	
	for c_daylist in (select day_id from his_bi.dim_date_info where day_id >= o_start_date and day_id <= o_end_date order by day_id)
	loop 
	
	--raise notice '4 c_daylist.day_id is: %', c_daylist.day_id;
	
	delete from his_bi.dwd_inp_income_d where st_date = c_daylist.day_id and key = 'D00074';
	
  INSERT into his_bi.dwd_inp_income_d(key,value,patient_id,visit_id,pai_visit_id,insert_date,
																			 remark,st_date) 
  select 'D00074',
				 to_number(c.datastore_name,'9999999999.9999'),/*9999999999.9999 表示14位长度，其中4个是小数位*/
				 d.bah as patient_id,
				 d.zycs as visit_id,
				 a.pai_visit_id,
				 now(),
				 '住院患者中医治疗费',
			  to_char(d.cyrq,'yyyymmdd') AS st_date
   from his_bi.ods_patient_medical_record d
   left join his_bi.pts_pai_visit a
   on (a.visit_id =d.zycs and a.patient_id =d.bah)
  inner join (select inpati_id,max(hp_basic_business_id) as hp_basic_business_id 
                from his_bi.emr_mrms_hp_basic_business
               where reportcard_type is null 
               group by inpati_id) b 
     on a.pai_visit_id = b.inpati_id
  inner join his_bi.emr_mrms_hp_datarecord c
     on c.hp_basic_business_id = b.hp_basic_business_id
  where d.cyrq is not null 
    and c.hp_datacol_config_key = 'tCMFee'
    and d.cyrq >= to_date(c_daylist.day_id,'yyyyMMdd')
    and d.cyrq <  to_date(c_daylist.day_id,'yyyyMMdd')+1
    and c.datastore_name <>'0.00';
 
	 end loop;
   RETURN 'SUCCESS';  
END;
$$;

alter function "fun_dwd_D00074_d"(varchar, varchar)
  owner to postgres;

