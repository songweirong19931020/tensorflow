create function fun_dw_inp_important_operation_fy(v_start_month character varying, v_end_month character varying)
  returns character varying
language plpgsql
as $$
/***
函数名称： 三级妇幼等级评审重点手术
    作用：三级妇幼等级评审重点手术
  开发人：肖斌 2020年6月16日
命名规范：FUN_模型层级(DWD或者DW)_KPI编码_日期类型D或者M，D表示按天统计，M表示按月统计
 KPI编码：D00236根据原子指标编码规划来的
    入参：v_start_date，v_end_date  格式均为yyyymmdd，可以一次运行多天的数据
***/
DECLARE
  c_monthlist   record;
  o_start_month varchar;
  o_end_month   varchar;
  i_start_month varchar;
  i_end_month   varchar;
  i_count       int4;
  tmp_file      varchar;  --COPY方案临时文件名：该文件将被保存在所连接的服务器的文件目录。
BEGIN
  /*
    COPY方案临时文件名。
    注意：
    1. 该文件将被保存在所连接的服务器的文件目录中，每一个函数必须使用自定义能够与其他函数区分的文件名
    2. 方便维护，历史文件都保存到'/home/postgres/'目录中。
    TODO : 后续规划统一临时文件目录，KETTLE调度完成之后，需要删除对应的临时文件（*需要想办法在每台服务器上统一创建临时目录）
  */
  
  /*如果指标没有历史指标数据，甘肃默认以202001开始计算，结束月份以当前月份往前推1个月*/
  select count(1),to_char((date_trunc('month', now()) + interval '-1 month'),'yyyymm')
         into i_count,i_end_month
    from his_bi.dw_inp_important_operation_fy;
   
  if(i_count = 0)
    then 
      i_start_month := '202001';
      --raise notice '0 i_start_month is: %', i_start_month;
  else if(i_count > 0)
    then
      i_start_month := i_end_month;
      --raise notice '1 i_start_month is: %', i_start_month;
  end if;
  end if;
    
  if(length(trim(v_start_month)) = 0 and length(trim(v_end_month)) = 0)
  /*kettle 调用时，如果不设置参数，默认传入 空字符串，那么默认取当前月份前1个月为截止月份 */
    then 
      o_start_month := i_start_month;
      o_end_month := i_end_month;
      --raise notice '2 o_start_month is: %', o_start_month;
      --raise notice '2 o_end_month is: %', o_end_month;
  else if (length(trim(v_start_month)) <> 0 and length(trim(v_end_month)) <> 0)
  /*PG function 如果参入任何参数，那么以实际入参为准*/
    then 
      o_start_month := v_start_month;
      o_end_month := v_end_month;
      --raise notice '3 o_start_month is: %', o_start_month;
      --raise notice '3 o_end_month is: %', o_end_month;
  end if;
  end if;
    for c_monthlist in (select distinct month_id from his_bi.dim_date_info where month_id >= o_start_month and month_id <= o_end_month order by month_id)
    loop
    --raise notice '4 c_daylist.day_id is: %', c_daylist.day_id;
    
    delete from his_bi.dw_inp_important_operation_fy where month_id = c_monthlist.month_id;
    
		insert into his_bi.dw_inp_important_operation_fy
		select 
			c_monthlist.month_id as month_id,
			pd.patient_id,
			pd.visit_id,
			pd.pai_visit_id,
			to_date((pd.st_date)::text, 'yyyymmdd'::text) AS operate_date,
			substr((pd.remark)::text, 6, length((pd.remark)::text)) AS operation_name,
			sum(pd.value) AS operation_count,
			sum(pd2.value) AS "48h_return_count",
			sum(pd3.value) AS "31d_return_count"
			from his_bi.dwd_inp_medical_d pd
			left join his_bi.dwd_inp_medical_d pd2 on pd2.pai_visit_id = pd.pai_visit_id and pd2.key = 'D05024' and pd.st_date = pd2.st_date
			left join his_bi.dwd_inp_medical_d pd3 on pd3.pai_visit_id = pd.pai_visit_id and pd3.key = 'D05025' and pd.st_date = pd3.st_date
			left join his_bi.dim_date_info d1 on pd.st_date = d1.day_id and d1.month_id = c_monthlist.month_id
			where pd.key in('D00192','D00193','D00194','D00195','D00196','D00197','D00198','D00199','D00200','D00201','D00202','D00203','D00204')
			 and d1.month_id = c_monthlist.month_id
			GROUP BY
			pd.patient_id,
			pd.visit_id,
			pd.pai_visit_id ,
			to_date((pd.st_date)::text, 'yyyymmdd'::text) ,
			substr((pd.remark)::text, 6, length((pd.remark)::text));
   end loop;
   RETURN 'SUCCESS';  
END;
$$;

alter function fun_dw_inp_important_operation_fy(varchar, varchar)
  owner to postgres;

