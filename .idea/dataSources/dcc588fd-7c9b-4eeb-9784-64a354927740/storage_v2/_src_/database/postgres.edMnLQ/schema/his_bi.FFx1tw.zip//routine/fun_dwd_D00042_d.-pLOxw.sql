create function "fun_dwd_D00042_d"(v_start_date character varying, v_end_date character varying)
  returns character varying
language plpgsql
as $$
/***
函数名称：产伤——非器械辅助阴道分娩
    作用：统计某天住院患者产伤——器械辅助阴道分娩
  开发人：wrsong 2020-05-24
命名规范：FUN_模型层级(DWD或者DW)_KPI编码_日期类型D或者M，D表示按天统计，M表示按月统计
 KPI编码：D00042  根据原子指标编码规划来的
    入参：v_start_date，v_end_date  格式均为yyyymmdd，可以一次运行多天的数据
***/
DECLARE
  c_daylist record;
  o_start_date varchar;
  o_end_date varchar;
  i_start_date varchar;
  i_end_date varchar;
  i_count  int4;
BEGIN

  /*如果指标没有历史指标数据，甘肃默认以20200101开始计算*/
  /*住院数据，每次运行当前日期前15天出院的患者，因为病案首页归档有2周左右的延迟*/
  select count(1),to_char(to_date(to_char(now(),'yyyymmdd'),'yyyymmdd') - 15,'yyyymmdd')
         into i_count,i_end_date
    from his_bi.dwd_inp_medical_d 
   where key = 'D00042';
   
  if(i_count = 0)
    then 
      i_start_date := '20200101';
      --raise notice '0 i_start_date is: %', i_start_date;
  else if(i_count > 0)
    then
      i_start_date := i_end_date;
      --raise notice '1 i_start_date is: %', i_start_date;
  end if;
  end if;
    
  if(length(trim(v_start_date)) = 0 and length(trim(v_end_date)) = 0)
  /*kettle 调用时，如果不设置参数，默认传入 空字符串，那么默认取当前日期后退一天 */
    then 
      o_start_date := i_start_date;
      o_end_date := i_end_date;
      --raise notice '2 o_start_date is: %', o_start_date;
      --raise notice '2 o_end_date is: %', o_end_date;
  else if (length(trim(v_start_date)) <> 0 and length(trim(v_end_date)) <> 0)
  /*PG function 如果参入任何参数，那么以实际入参为准*/
    then 
      o_start_date := v_start_date;
      o_end_date := v_end_date;
      --raise notice '3 o_start_date is: %', o_start_date;
      --raise notice '3 o_end_date is: %', o_end_date;
  end if;
  end if;
  
  for c_daylist in (select day_id from his_bi.dim_date_info where day_id >= o_start_date and day_id <= o_end_date order by day_id)
  loop 
  
  --raise notice '4 c_daylist.day_id is: %', c_daylist.day_id;
  
  delete from his_bi.dwd_inp_medical_d  where st_date = c_daylist.day_id and key = 'D00042';
  
  INSERT into his_bi.dwd_inp_medical_d (key,value,patient_id,visit_id,pai_visit_id,insert_date,
                                       remark,st_date) 
  select distinct 'D00042' as key,
          1 as value,
          hf.patient_id,
          hf.visit_id,
          t1.pai_visit_id,
          Now () as insert_date,
          '非器械分娩' remark ,
          to_char(ha.cyrq,'yyyymmdd') as st_date
    from his_bi.ODS_PATIENT_MEDICAL_RECORD ha
    left join  his_bi.ods_patient_diag_info hf on ha.bah = hf.patient_id and ha.zycs = hf.visit_id
    left join his_bi.pts_pai_visit t1 on ha.bah = t1.patient_id and ha.zycs = t1.visit_id
   where 1=1 
	 and not exists
          (
              select 1
              from his_bi.ods_patient_diag_info tf
              where (tf.diagdiseasecode  like 'O81%' or  tf.diagdiseasecode like 'O84.1%')
              and hf.patient_id = tf.patient_id and hf.visit_id = tf.visit_id
          )
    -- and (hf.diagdiseasecode  not like 'O81%' or  hf.diagdiseasecode not like 'O84.1%')---排除器械分娩
		 and  (hf.diagdiseasecode  like 'O70%' or  hf.diagdiseasecode like 'O71%')
     and ha.cyrq >= to_date(c_daylist.day_id,'yyyyMMdd')
     and ha.cyrq <  to_date(c_daylist.day_id,'yyyyMMdd') + 1 ; 
 
   end loop;
   RETURN 'SUCCESS';
END;
$$;

alter function "fun_dwd_D00042_d"(varchar, varchar)
  owner to postgres;

