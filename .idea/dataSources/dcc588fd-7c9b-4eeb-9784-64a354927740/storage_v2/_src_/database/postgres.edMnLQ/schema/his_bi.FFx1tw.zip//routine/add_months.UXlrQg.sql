create function add_months(timestamp with time zone, integer)
  returns timestamp with time zone
strict
language plpgsql
as $$
declare
  i interval := ($2 || 'month');
  d1 date := date(to_timestamp($1::text,'yyyy-mm') + interval '1 month' - interval '1 day');
  d2 date := date($1);
  res timestamptz;
begin
  select case when d1=d2 then ((to_char($1+i+interval '1 month', 'yyyy-mm')||'-01')::date - 1) + $1::timetz else $1+i end into res;
  return res;
end;

$$;

alter function add_months(timestamp with time zone, integer)
  owner to postgres;

