create view view_dw_inp_dept_work_d as
  SELECT wk.stat_date          AS "统计日期",
         wk.dept_code          AS "科室编码",
         wk.dept_name          AS "科室名称",
         org.root_name         AS "保健部名称",
         wk.bed_used           AS "实际占用总床日数",
         wk.discharge_bed_day  AS "出院患者总床日数",
         wk.bed_used_beginning AS "原在院人数",
         wk.c_num              AS "当日入院人数",
         wk.change_in_num      AS "当日转入人数",
         wk.f_num              AS "当日出院人数",
         wk.n_num              AS "当日取消出院人数",
         wk.actual_f_num       AS "当日实际出院人数",
         wk.cure               AS "治愈人数",
         wk.better             AS "好转人数",
         wk.notcure            AS "未愈人数",
         wk.dead               AS "死亡人数",
         wk.to_dept_num        AS "当日转出人数",
         wk.bed_used_ending    AS "现在院人数",
         wk.sy_num             AS "科室所有开放床位数",
         wk.bz_num             AS "科室编制床位数",
         wk.insert_date        AS "插入时间"
  FROM (his_bi.dw_inp_dept_work_d wk
      LEFT JOIN his_bi.v_system_organization org ON (((wk.dept_code) :: text = (org.code) :: text)));

alter table view_dw_inp_dept_work_d
  owner to postgres;

