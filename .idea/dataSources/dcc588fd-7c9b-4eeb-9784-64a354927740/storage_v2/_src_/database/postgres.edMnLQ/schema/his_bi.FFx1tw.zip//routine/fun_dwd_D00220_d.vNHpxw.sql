create function "fun_dwd_D00220_d"(v_start_date character varying, v_end_date character varying)
  returns character varying
language plpgsql
as $$
/***
函数名称：是否使用营养药物
    作用：统计某天患者是否使用营养药物
  开发人：wy 2020-05-22
命名规范：FUN_模型层级(DWD或者DW)_KPI编码_日期类型D或者M，D表示按天统计，M表示按月统计
 KPI编码：D00220  根据原子指标编码规划来的
    入参：v_start_date，v_end_date  格式均为yyyymmdd，可以一次运行多天的数据
***/
DECLARE
	c_daylist record;
	o_start_date varchar;
	o_end_date varchar;
	i_start_date varchar;
	i_end_date varchar;
	i_count  int4;
BEGIN

  /*如果指标没有历史指标数据，甘肃默认以20200101开始计算*/
  select count(1),to_char(to_date(to_char(now(),'yyyymmdd'),'yyyymmdd') - 1,'yyyymmdd')
         into i_count,i_end_date
	  from his_bi.dwd_inp_quantity_d
	 where key = 'D00220';
	 
  if(i_count = 0)
	  then 
		  i_start_date := '20200101';
			--raise notice '0 i_start_date is: %', i_start_date;
	else if(i_count > 0)
	  then
		  i_start_date := i_end_date;
			--raise notice '1 i_start_date is: %', i_start_date;
  end if;
	end if;
		
  if(length(trim(v_start_date)) = 0 and length(trim(v_end_date)) = 0)
	/*kettle 调用时，如果不设置参数，默认传入 空字符串，那么默认取对应key 最大日期加一天 对应逻辑line 12 */
	  then 
	    o_start_date := i_start_date;
	    o_end_date := i_end_date;
			--raise notice '2 o_start_date is: %', o_start_date;
			--raise notice '2 o_end_date is: %', o_end_date;
	else if (length(trim(v_start_date)) <> 0 and length(trim(v_end_date)) <> 0)
	/*PG function 如果参入任何参数，那么以实际入参为准*/
	  then 
		  o_start_date := v_start_date;
	    o_end_date := v_end_date;
			--raise notice '3 o_start_date is: %', o_start_date;
			--raise notice '3 o_end_date is: %', o_end_date;
	end if;
	end if;
	
	for c_daylist in (select day_id from his_bi.dim_date_info where day_id >= o_start_date and day_id <= o_end_date order by day_id)
	loop 
	
	--raise notice '4 c_daylist.day_id is: %', c_daylist.day_id;
	
	delete from his_bi.dwd_inp_quantity_d where st_date = c_daylist.day_id and key = 'D00220';
	
  INSERT into his_bi.dwd_inp_quantity_d(key,value,patient_id,visit_id,pai_visit_id,insert_date,
																						remark,st_date) 
					
	select distinct 'D00220',
					1,
					tm.patient_id,
					tm.visit_id,
					tm.pai_visit_id,
					now(),
					'是否使用营养药物', 
					to_char(tm.enter_date,'yyyyMMdd')
	from his_bi.bms_bill_item tm
	inner join his_bi.dms_pham_basic_info df on tm.item_code = df.pham_std_code
	left join his_bi.dms_inside_code_dict dt on df.pham_code = dt.cate_code
	where dt.cate_name like '%营养%'
	and tm.enter_date >= to_date(c_daylist.day_id,'yyyyMMdd')
	and tm.enter_date <  to_date(c_daylist.day_id,'yyyyMMdd')+1
	;
	 end loop;
   RETURN 'SUCCESS';  
END;
$$;

alter function "fun_dwd_D00220_d"(varchar, varchar)
  owner to postgres;

