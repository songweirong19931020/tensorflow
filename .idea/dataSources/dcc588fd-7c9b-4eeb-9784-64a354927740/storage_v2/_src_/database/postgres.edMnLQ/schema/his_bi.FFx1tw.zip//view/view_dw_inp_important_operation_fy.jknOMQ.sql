create view view_dw_inp_important_operation_fy as
  SELECT ip.month_id             AS "月份",
         ip.patient_id           AS "患者编号",
         ip.visit_id             AS "住院次数",
         ip.pai_visit_id         AS "患者住院流水",
         ip.operate_date         AS "手术日期",
         ip.operation_name       AS "手术名",
         ip.operation_count      AS "手术次数",
         ip."48h_return_count"   AS "48小时重返",
         ip."3-31d_return_count" AS "3-31天重返",
         inp.patient_name        AS "患者姓名",
         inp.age                 AS "年龄",
         inp.age_flag            AS "年龄类型",
         inp.area_code           AS "院区",
         inp.sex                 AS "性别",
         inp.team_id             AS "诊疗组ID",
         inp.team_name           AS "诊疗组名称",
         inp.is_zqss             AS "是否择期手术",
         inp.in_days             AS "住院天数",
         am.total_fees           AS "总费用",
         inp.is_die              AS "是否死亡",
         inp.out_dept_code       AS "出院科室代码",
         inp.in_dept_name        AS "出院科室名称",
         inp.out_time            AS "出院日期",
         org.root_name           AS "保健部名称"
  FROM (((his_bi.dw_inp_important_operation_fy ip
      LEFT JOIN his_bi.dw_inp_patient_info_m inp ON ((((ip.patient_id) :: text = (inp.patient_id) :: text) AND
                                                      (ip.visit_id = inp.visit_id))))
      LEFT JOIN his_bi.v_system_organization org ON (((inp.out_dept_code) :: text = (org.code) :: text)))
      LEFT JOIN (SELECT t.patient_id, t.visit_id, sum(t.total_fees) AS total_fees
                 FROM his_bi.dw_inp_patient_amount_m t
                 GROUP BY t.patient_id, t.visit_id) am ON ((((am.patient_id) :: text = (ip.patient_id) :: text) AND
                                                            (am.visit_id = ip.visit_id))));

alter table view_dw_inp_important_operation_fy
  owner to postgres;

