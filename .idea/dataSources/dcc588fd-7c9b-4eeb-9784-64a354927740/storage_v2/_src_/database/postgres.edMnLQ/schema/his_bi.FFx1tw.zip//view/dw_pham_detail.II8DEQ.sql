create view dw_pham_detail as
  SELECT t.patient_id                             AS "患者id",
         t.visit_id                               AS "患者就诊次数",
         t.item_code                              AS "药品代码",
         p.pham_general_name                      AS "药品化学名称",
         p.pham_name                              AS "药品商品名称",
         t.in_out_flag                            AS "是否门诊",
         COALESCE(sum(t.charges), (0) :: numeric) AS "药品金额",
         t.enter_date                             AS st_date
  FROM (his_bi.bms_bill_item t
      LEFT JOIN his_bi.dms_pham_basic_info p ON (((p.pham_std_code) :: text = (t.item_code) :: text)))
  WHERE (((t.subj_code) :: text = ANY
          ((ARRAY['J01'::character varying, 'J02'::character varying, 'J03'::character varying, 'J04'::character varying]) :: text [])) AND
         (t.charges <> (0) :: numeric))
  GROUP BY t.patient_id, t.visit_id, t.item_code, t.item_name, p.pham_general_name, p.pham_name, t.in_out_flag,
           t.enter_date;

comment on view dw_pham_detail
is '------------------------------------------------------------
Description： 药品明细

Author: SDD
Create Time： 2020/05/23
Modifier: SDD
Update Time:  2020/05/23
-------------------------------------------------------------
';

alter table dw_pham_detail
  owner to postgres;

