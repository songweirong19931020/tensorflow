create function fun_kpi_master_m_swr(v_start_month character varying, v_end_month character varying)
  returns character varying
language plpgsql
as $$
/***
函数名称：三级公立绩效指标函数
    作用：三级公立绩效指标函数
  开发人：leslie 2020年6月24日
命名规范：FUN_模型层级(DWD或者DW)_KPI编码_日期类型D或者M，D表示按天统计，M表示按月统计
 KPI编码：根据原子指标编码规划来的
    入参：v_start_date，v_end_date  格式均为yyyymmdd，可以一次运行多天的数据
***/
DECLARE
  c_monthlist   record;
  o_start_month varchar;
  o_end_month   varchar;
  i_start_month varchar;
  i_end_month   varchar;
  i_count       int4;
    tmp_file            varchar;  --COPY方案临时文件名：该文件将被保存在所连接的服务器的文件目录。
BEGIN
    /*
      COPY方案临时文件名。
        注意：
        1. 该文件将被保存在所连接的服务器的文件目录中，每一个函数必须使用自定义能够与其他函数区分的文件名
        2. 方便维护，历史文件都保存到'/home/postgres/'目录中。
        TODO : 后续规划统一临时文件目录，KETTLE调度完成之后，需要删除对应的临时文件（*需要想办法在每台服务器上统一创建临时目录）
    */
    
  /*如果指标没有历史指标数据，甘肃默认以202001开始计算，结束月份以当前月份往前推1个月*/
  select count(1),to_char((date_trunc('month', now()) + interval '-1 month'),'yyyymm')
           into i_count,i_end_month
    from his_bi.kpi_master_m;
   
  if(i_count = 0)
    then 
      i_start_month := c_monthlist.month_id;
      --raise notice '0 i_start_month is: %', i_start_month;
  else if(i_count > 0)
    then
      i_start_month := i_end_month;
      --raise notice '1 i_start_month is: %', i_start_month;
  end if;
  end if;
    
  if(length(trim(v_start_month)) = 0 and length(trim(v_end_month)) = 0)
  /*kettle 调用时，如果不设置参数，默认传入 空字符串，那么默认取当前月份前1个月为截止月份 */
    then 
      o_start_month := i_start_month;
      o_end_month := i_end_month;
      --raise notice '2 o_start_month is: %', o_start_month;
      --raise notice '2 o_end_month is: %', o_end_month;
  else if (length(trim(v_start_month)) <> 0 and length(trim(v_end_month)) <> 0)
  /*PG function 如果参入任何参数，那么以实际入参为准*/
    then 
      o_start_month := v_start_month;
      o_end_month := v_end_month;
      --raise notice '3 o_start_month is: %', o_start_month;
      --raise notice '3 o_end_month is: %', o_end_month;
  end if;
  end if;
      for c_monthlist in (select distinct month_id from his_bi.dim_date_info where month_id >= o_start_month and month_id <= o_end_month order by month_id)
    loop
    --raise notice '4 c_daylist.day_id is: %', c_daylist.day_id;
    
  delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX00101';
    
  insert into his_bi.kpi_master_m
        select
        t1.month_id,
        'JX00101' as kpi_code,
        count(distinct t1.outp_visit_id) as kpi_value,
        now() as update_time,
        count(distinct t1.outp_visit_id) as self_value,
        null as check_flag,
        null as check_comm
        from
        his_bi.dw_outp_patient_info_m t1
        where
        t1.month_id = c_monthlist.month_id
        and t1.is_emergency  is null
        and t1.is_tj is null
        group by 
        t1.month_id;

  delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX00102';
    
  insert into his_bi.kpi_master_m
        select
        t1.month_id,
        'JX00102' as kpi_code,
        COALESCE(count(distinct t1.pai_visit_id),0)  as kpi_value,
        now() as update_time,
        COALESCE(count(distinct t1.pai_visit_id),0)  as self_value,
        null as check_flag,
        null as check_comm
        from
        his_bi.dw_inp_patient_info_m t1
        where
        t1.month_id=c_monthlist.month_id
        group by 
        t1.month_id;
        
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX001';
    
  insert into his_bi.kpi_master_m
         select
        t1.month_id,
        'JX001' as kpi_code,
        round(max(t1.kpi_value)/max(t2.kpi_value),5) as kpi_value,
        now() as update_time,
        round(max(t1.kpi_value)/max(t2.kpi_value),5) as self_value,
        null as check_flag,
        null as check_comm
        from
        his_bi.kpi_master_m t1
        left join his_bi.kpi_master_m t2 on t1.kpi_code = t2.kpi_code and t1.month_id = t2.month_id 
        and t2.kpi_code='JX00102'
        where
        t1.month_id=c_monthlist.month_id
        and t1.kpi_code in('JX00102','JX00101')
        group by 
        t1.month_id;
                
        ---下转患者
  delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX00202';
    
  insert into his_bi.kpi_master_m

        select
        t1.month_id,
        'JX00202' as kpi_code,
        COALESCE(COALESCE(count(distinct t1.pai_visit_id),0) ,0) as kpi_value,
        now() as update_time,
        COALESCE(COALESCE(count(distinct t1.pai_visit_id),0) ,0) as self_value,
        null as check_flag,
        null as check_comm
        from
        his_bi.dw_inp_patient_info_m t1
        where
        t1.month_id=c_monthlist.month_id
        and t1.is_xzhz='1'
        group by 
        t1.month_id;

-----日间手术台次数（日间手术人数）
  delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX00301';
    
  insert into his_bi.kpi_master_m
         select
        t1.month_id,
        'JX00301' as kpi_code,
        COALESCE(count(distinct t1.pai_visit_id),0) as kpi_value,
        now() as update_time,
        COALESCE(count(distinct t1.pai_visit_id),0) as self_value,
        null as check_flag,
        null as check_comm
        from
        his_bi.dw_inp_patient_info_m t1
        where
        t1.month_id=c_monthlist.month_id
        and t1.rjss_num>0
        group by 
        t1.month_id;

-----同期出院患者择期手术总台次数（同期出院择期手术总人数）
  delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX00302';
    
  insert into his_bi.kpi_master_m
         select
        t1.month_id,
        'JX00302' as kpi_code,
        COALESCE(count(distinct t1.pai_visit_id),0) as kpi_value,
        now() as update_time,
        COALESCE(count(distinct t1.pai_visit_id),0) as self_value,
        null as check_flag,
        null as check_comm
        from
        his_bi.dw_inp_patient_info_m t1
        where
        t1.month_id=c_monthlist.month_id
        and t1.is_zqss>0
        group by 
        t1.month_id;
                
------日间手术占择期手术比例
  delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX003';
    
  insert into his_bi.kpi_master_m
        select
        t1.month_id,
        'JX003' as kpi_code,
        round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as kpi_value,
        now() as update_time,
        round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as self_value,
        null as check_flag,
        null as check_comm
        from
        his_bi.kpi_master_m t1
        left join his_bi.kpi_master_m t2 on t1.kpi_code = t2.kpi_code and t1.month_id = t2.month_id 
        and t2.kpi_code='JX00301'
        where
        t1.month_id=c_monthlist.month_id
        and t1.kpi_code in('JX00301','JX00302')
        group by 
        t1.month_id;
-----出院患者手术台次数（出院手术人数）
  delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX00401';
    
  insert into his_bi.kpi_master_m
         select
        t1.month_id,
        'JX00401' as kpi_code,
        COALESCE(count(distinct t1.pai_visit_id),0) as kpi_value,
        now() as update_time,
        COALESCE(count(distinct t1.pai_visit_id),0) as self_value,
        null as check_flag,
        null as check_comm
        from
        his_bi.dw_inp_patient_info_m t1
        where
        t1.month_id=c_monthlist.month_id
        and t1.is_sshz>0
        group by 
        t1.month_id;

---同期出院患者总人次数（出院人数）
  delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX00402';
    
  insert into his_bi.kpi_master_m
        select
        t1.month_id,
        'JX00402' as kpi_code,
        COALESCE(count(distinct t1.pai_visit_id),0)  as kpi_value,
        now() as update_time,
        COALESCE(count(distinct t1.pai_visit_id),0)  as self_value,
        null as check_flag,
        null as check_comm
        from
        his_bi.dw_inp_patient_info_m t1
        where
        t1.month_id=c_monthlist.month_id
        group by 
        t1.month_id;


------出院患者手术占比
  delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX004';
    
  insert into his_bi.kpi_master_m
        select
        t1.month_id,
        'JX004' as kpi_code,
        round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as kpi_value,
        now() as update_time,
        round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as self_value,
        null as check_flag,
        null as check_comm
        from
        his_bi.kpi_master_m t1
        left join his_bi.kpi_master_m t2 on t1.kpi_code = t2.kpi_code and t1.month_id = t2.month_id 
        and t2.kpi_code='JX00401'
        where
        t1.month_id=c_monthlist.month_id
        and t1.kpi_code in('JX00401','JX00402')
        group by 
        t1.month_id;


---出院患者微创手术台次数（微创手术人数）
  delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX00501';
    
  insert into his_bi.kpi_master_m
        select
        t1.month_id,
        'JX00501' as kpi_code,
        COALESCE(count(distinct t1.pai_visit_id),0) as kpi_value,
        now() as update_time,
        COALESCE(count(distinct t1.pai_visit_id),0) as self_value,
        null as check_flag,
        null as check_comm
        from
        his_bi.dw_inp_patient_info_m t1
        where
        t1.month_id=c_monthlist.month_id
        and t1.wc_num>0
        group by 
        t1.month_id;

delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX00502';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX00502' as kpi_code,
            COALESCE(count(distinct t1.pai_visit_id),0) as kpi_value,
            now() as update_time,
            COALESCE(count(distinct t1.pai_visit_id),0) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_patient_info_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.is_sshz>0
            group by 
            t1.month_id;
    
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX00601';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX00601' as kpi_code,
            COALESCE(count(distinct t1.pai_visit_id),0) as kpi_value,
            now() as update_time,
            COALESCE(count(distinct t1.pai_visit_id),0) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_patient_info_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.sjss_num>0
            group by 
            t1.month_id;
    
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX00602';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX00602' as kpi_code,
            COALESCE(count(distinct t1.pai_visit_id),0) as kpi_value,
            now() as update_time,
            COALESCE(count(distinct t1.pai_visit_id),0) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_patient_info_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.is_sshz>0
            group by 
            t1.month_id;
delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX00801';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX00801' as kpi_code,
            COALESCE(count(distinct t1.pai_visit_id),0) as kpi_value,
            now() as update_time,
            COALESCE(count(distinct t1.pai_visit_id),0) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_patient_info_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.ssbf_num>0
            group by 
            t1.month_id;
    
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX00802';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX00802' as kpi_code,
            COALESCE(count(distinct t1.pai_visit_id),0) as kpi_value,
            now() as update_time,
            COALESCE(count(distinct t1.pai_visit_id),0) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_patient_info_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.is_sshz>0
            group by 
            t1.month_id;
    
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX00901';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX00901' as kpi_code,
            COALESCE(count(distinct t1.pai_visit_id),0) as kpi_value,
            now() as update_time,
            COALESCE(count(distinct t1.pai_visit_id),0) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_patient_info_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.is_ylqk_gr>0
            group by 
            t1.month_id;
    
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX00902';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX00902' as kpi_code,
            COALESCE(count(distinct t1.pai_visit_id),0) as kpi_value,
            now() as update_time,
            COALESCE(count(distinct t1.pai_visit_id),0) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_patient_info_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.is_ylqk_sh>0
            group by 
            t1.month_id;
                        
----   10.1剖宫产病种例数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX01001';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX01001' as kpi_code,
            COALESCE(count(distinct t1.pai_visit_id),0) as kpi_value,
            now() as update_time,
            COALESCE(count(distinct t1.pai_visit_id),0) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00183'
            group by 
            t1.month_id;


-----平均住院日
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100101';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100101' as kpi_code,
            round(avg(t1.in_days),4)as kpi_value,
            now() as update_time,
            round(avg(t1.in_days),4) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id = c_monthlist.month_id
            and t1.drgs_name = 'D00183'
            group by 
            t1.month_id;

---    同期剖宫产总出院人数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100103';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100103' as kpi_code,
            COALESCE(count(distinct t1.pai_visit_id),0) as kpi_value,
            now() as update_time,
            COALESCE(count(distinct t1.pai_visit_id),0) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00183'
            group by 
            t1.month_id;

----    剖宫产死亡人数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100108';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100108' as kpi_code,
            COALESCE(COALESCE(count(distinct t1.pai_visit_id),0) ,0) as kpi_value,
            now() as update_time,
            COALESCE(COALESCE(count(distinct t1.pai_visit_id),0) ,0) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00183'
            and t1.lyfs = '5'
            group by 
            t1.month_id;

---总费用

    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100105';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100105' as kpi_code,
            round(sum(t1.total_fees),4)as kpi_value,
            now() as update_time,
            round(sum(t1.total_fees),4)as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00183'
            group by 
            t1.month_id;


---社区获得性肺炎病例数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX01002';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX01002' as kpi_code,
            COALESCE(count(distinct t1.pai_visit_id),0) as kpi_value,
            now() as update_time,
            COALESCE(count(distinct t1.pai_visit_id),0) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00173'
            group by 
            t1.month_id;

----平均住院日
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100201';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100201' as kpi_code,
            round(avg(t1.in_days),4)as kpi_value,
            now() as update_time,
            round(avg(t1.in_days),4) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00173'
            group by 
            t1.month_id;
---    同期社区获得性肺炎(住院、儿童)总出院人数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100203';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100203' as kpi_code,
            COALESCE(count(distinct t1.pai_visit_id),0) as kpi_value,
            now() as update_time,
            COALESCE(count(distinct t1.pai_visit_id),0) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00173'
            group by 
            t1.month_id;

---    社区获得性肺炎(住院、儿童)死亡人数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100208';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100208' as kpi_code,
            COALESCE(COALESCE(count(distinct t1.pai_visit_id),0) ,0)as kpi_value,
            now() as update_time,
            COALESCE(COALESCE(count(distinct t1.pai_visit_id),0) ,0)as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00173'
            and t1.lyfs='5'
            group by 
            t1.month_id;


---总费用
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100205';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100205' as kpi_code,
            round(sum(t1.total_fees),4)as kpi_value,
            now() as update_time,
            round(sum(t1.total_fees),4) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00173'
            group by 
            t1.month_id;
---刨宫产病死率
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100107';
        
      insert into his_bi.kpi_master_m
             select
            t1.month_id,
            'JX0100107' as kpi_code,
             round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as kpi_value,
            now() as update_time,
             round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.kpi_master_m t1
            left join his_bi.kpi_master_m t2 on t1.kpi_code = t2.kpi_code and t1.month_id = t2.month_id 
            and t2.kpi_code='JX0100108'
            where
            t1.month_id=c_monthlist.month_id
            and t1.kpi_code in('JX0100108','JX01001')
            group by 
            t1.month_id;


----社区获得性肺炎总天数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100202';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100202' as kpi_code,
            round(sum(t1.in_days),3)as kpi_value,
            now() as update_time,
            round(sum(t1.in_days),3) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00173'
            group by 
            t1.month_id;

----同期社区获得性肺炎总天数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100206';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100206' as kpi_code,
            round(sum(t1.in_days),3)as kpi_value,
            now() as update_time,
            round(sum(t1.in_days),3) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00173'
            group by 
            t1.month_id;

---社区肺炎均次费用
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100204';
        
      insert into his_bi.kpi_master_m
             select
            t1.month_id,
            'JX0100204' as kpi_code,
            round(max(t1.kpi_value)/max(t2.kpi_value),5)as kpi_value,
            now() as update_time,
            round(max(t1.kpi_value)/max(t2.kpi_value),5)as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.kpi_master_m t1
            left join his_bi.kpi_master_m t2 on t1.kpi_code = t2.kpi_code and t1.month_id = t2.month_id 
            and t2.kpi_code='JX01002'
            where
            t1.month_id=c_monthlist.month_id
            and t1.kpi_code in('JX0100205','JX01002')
            group by 
            t1.month_id;

---刨宫产均次费用
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100104';
        
      insert into his_bi.kpi_master_m
             select
            t1.month_id,
            'JX0100104' as kpi_code,
            round(max(t1.kpi_value)/max(t2.kpi_value),5)as kpi_value,
            now() as update_time,
            round(max(t1.kpi_value)/max(t2.kpi_value),5)as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.kpi_master_m t1
            left join his_bi.kpi_master_m t2 on t1.kpi_code = t2.kpi_code and t1.month_id = t2.month_id 
            and t2.kpi_code='JX01001'
            where
            t1.month_id=c_monthlist.month_id
            and t1.kpi_code in('JX0100105','JX01001')
            group by 
            t1.month_id;


----刨宫产总天数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100102';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100102' as kpi_code,
            round(sum(t1.in_days),3)as kpi_value,
            now() as update_time,
            round(sum(t1.in_days),3) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00183'
            group by 
            t1.month_id;

----同期刨宫产总天数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100106';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100106' as kpi_code,
            round(sum(t1.in_days),3)as kpi_value,
            now() as update_time,
            round(sum(t1.in_days),3) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00183'
            group by 
            t1.month_id;

---病例总数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX01003';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX01003' as kpi_code,
            COALESCE(count(distinct t1.pai_visit_id),0) as kpi_value,
            now() as update_time,
            COALESCE(count(distinct t1.pai_visit_id),0) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00113'
            group by 
            t1.month_id;
    
---病例总数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX01004';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX01004' as kpi_code,
            COALESCE(count(distinct t1.pai_visit_id),0) as kpi_value,
            now() as update_time,
            COALESCE(count(distinct t1.pai_visit_id),0) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00208'
            group by 
            t1.month_id;
    
---病例总数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX01005';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX01005' as kpi_code,
            COALESCE(count(distinct t1.pai_visit_id),0) as kpi_value,
            now() as update_time,
            COALESCE(count(distinct t1.pai_visit_id),0) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00224'
            group by 
            t1.month_id;
    
---病例总数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX01006';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX01006' as kpi_code,
            COALESCE(count(distinct t1.pai_visit_id),0) as kpi_value,
            now() as update_time,
            COALESCE(count(distinct t1.pai_visit_id),0) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00210'
            group by 
            t1.month_id;


---平均住院日
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100301';
            
          insert into his_bi.kpi_master_m
                select
                t1.month_id,
                'JX0100301' as kpi_code,
                round(avg(t1.in_days),4)as kpi_value,
                now() as update_time,
                round(avg(t1.in_days),4) as self_value,
                null as check_flag,
                null as check_comm
                from
                his_bi.dw_inp_drgs_patient_m t1
                where
                t1.month_id=c_monthlist.month_id
                and t1.drgs_name = 'D00113'
                group by 
                t1.month_id;
    
---平均住院日
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100401';
            
          insert into his_bi.kpi_master_m
                select
                t1.month_id,
                'JX0100401' as kpi_code,
                round(avg(t1.in_days),4)as kpi_value,
                now() as update_time,
                round(avg(t1.in_days),4) as self_value,
                null as check_flag,
                null as check_comm
                from
                his_bi.dw_inp_drgs_patient_m t1
                where
                t1.month_id=c_monthlist.month_id
                and t1.drgs_name = 'D00208'
                group by 
                t1.month_id;
    
---平均住院日
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100501';
            
          insert into his_bi.kpi_master_m
                select
                t1.month_id,
                'JX0100501' as kpi_code,
                round(avg(t1.in_days),4)as kpi_value,
                now() as update_time,
                round(avg(t1.in_days),4) as self_value,
                null as check_flag,
                null as check_comm
                from
                his_bi.dw_inp_drgs_patient_m t1
                where
                t1.month_id=c_monthlist.month_id
                and t1.drgs_name = 'D00224'
                group by 
                t1.month_id;
    
---平均住院日
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100601';
            
          insert into his_bi.kpi_master_m
                select
                t1.month_id,
                'JX0100601' as kpi_code,
                round(avg(t1.in_days),4)as kpi_value,
                now() as update_time,
                round(avg(t1.in_days),4) as self_value,
                null as check_flag,
                null as check_comm
                from
                his_bi.dw_inp_drgs_patient_m t1
                where
                t1.month_id=c_monthlist.month_id
                and t1.drgs_name = 'D00210'
                group by 
                t1.month_id;


---出院患者占用总床日数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100302';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100302' as kpi_code,
            round(sum(t1.in_days),3)as kpi_value,
            now() as update_time,
            round(sum(t1.in_days),3) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00113'
            group by 
            t1.month_id;
    
---出院患者占用总床日数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100402';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100402' as kpi_code,
            round(sum(t1.in_days),3)as kpi_value,
            now() as update_time,
            round(sum(t1.in_days),3) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00208'
            group by 
            t1.month_id;
    
---出院患者占用总床日数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100502';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100502' as kpi_code,
            round(sum(t1.in_days),3)as kpi_value,
            now() as update_time,
            round(sum(t1.in_days),3) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00224'
            group by 
            t1.month_id;
    
---出院患者占用总床日数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100602';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100602' as kpi_code,
            round(sum(t1.in_days),3)as kpi_value,
            now() as update_time,
            round(sum(t1.in_days),3) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00210'
            group by 
            t1.month_id;


---同期总出院人数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100303';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100303' as kpi_code,
            COALESCE(count(distinct t1.pai_visit_id),0) as kpi_value,
            now() as update_time,
            COALESCE(count(distinct t1.pai_visit_id),0) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00113'
            group by 
            t1.month_id;
    
---同期总出院人数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100403';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100403' as kpi_code,
            COALESCE(count(distinct t1.pai_visit_id),0) as kpi_value,
            now() as update_time,
            COALESCE(count(distinct t1.pai_visit_id),0) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00208'
            group by 
            t1.month_id;
    
---同期总出院人数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100503';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100503' as kpi_code,
            COALESCE(count(distinct t1.pai_visit_id),0) as kpi_value,
            now() as update_time,
            COALESCE(count(distinct t1.pai_visit_id),0) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00224'
            group by 
            t1.month_id;
    
---同期总出院人数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100603';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100603' as kpi_code,
            COALESCE(count(distinct t1.pai_visit_id),0) as kpi_value,
            now() as update_time,
            COALESCE(count(distinct t1.pai_visit_id),0) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00210'
            group by 
            t1.month_id;

---总出院费用
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100305';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100305' as kpi_code,
            round(sum(t1.total_fees),4)as kpi_value,
            now() as update_time,
            round(sum(t1.total_fees),4) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00113'
            group by 
            t1.month_id;
    
---总出院费用
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100405';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100405' as kpi_code,
            round(sum(t1.total_fees),4)as kpi_value,
            now() as update_time,
            round(sum(t1.total_fees),4) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00208'
            group by 
            t1.month_id;
    
---总出院费用
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100505';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100505' as kpi_code,
            round(sum(t1.total_fees),4)as kpi_value,
            now() as update_time,
            round(sum(t1.total_fees),4) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00224'
            group by 
            t1.month_id;
    
---总出院费用
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100605';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100605' as kpi_code,
            round(sum(t1.total_fees),4)as kpi_value,
            now() as update_time,
            round(sum(t1.total_fees),4) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00210'
            group by 
            t1.month_id;

---同期实际占用总床日数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100306';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100306' as kpi_code,
            round(sum(t1.in_days),3)as kpi_value,
            now() as update_time,
            round(sum(t1.in_days),3) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00113'
            group by 
            t1.month_id;
    
---同期实际占用总床日数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100406';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100406' as kpi_code,
            round(sum(t1.in_days),3)as kpi_value,
            now() as update_time,
            round(sum(t1.in_days),3) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00208'
            group by 
            t1.month_id;
    
---同期实际占用总床日数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100506';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100506' as kpi_code,
            round(sum(t1.in_days),3)as kpi_value,
            now() as update_time,
            round(sum(t1.in_days),3) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00224'
            group by 
            t1.month_id;
    
---同期实际占用总床日数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100606';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100606' as kpi_code,
            round(sum(t1.in_days),3)as kpi_value,
            now() as update_time,
            round(sum(t1.in_days),3) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00210'
            group by 
            t1.month_id;
            

---死亡人数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100308';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100308' as kpi_code,
            COALESCE(count(distinct t1.pai_visit_id),0) as kpi_value,
            now() as update_time,
            COALESCE(count(distinct t1.pai_visit_id),0) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00113'
            and t1.lyfs='5'
            group by 
            t1.month_id;
    
---死亡人数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100408';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100408' as kpi_code,
            COALESCE(count(distinct t1.pai_visit_id),0) as kpi_value,
            now() as update_time,
            COALESCE(count(distinct t1.pai_visit_id),0) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00208'
            and t1.lyfs='5'
            group by 
            t1.month_id;
    
---死亡人数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100508';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100508' as kpi_code,
            COALESCE(count(distinct t1.pai_visit_id),0) as kpi_value,
            now() as update_time,
            COALESCE(count(distinct t1.pai_visit_id),0) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00224'
            and t1.lyfs='5'
            group by 
            t1.month_id;
    
---死亡人数
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100608';
        
      insert into his_bi.kpi_master_m
            select
            t1.month_id,
            'JX0100608' as kpi_code,
            COALESCE(count(distinct t1.pai_visit_id),0) as kpi_value,
            now() as update_time,
            COALESCE(count(distinct t1.pai_visit_id),0) as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.dw_inp_drgs_patient_m t1
            where
            t1.month_id=c_monthlist.month_id
            and t1.drgs_name = 'D00210'
            and t1.lyfs='5'
            group by 
            t1.month_id;
                        
    ---病死率
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100207';
        
        insert into his_bi.kpi_master_m
             select
            t1.month_id,
            'JX0100207' as kpi_code,
            round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as kpi_value,
            now() as update_time,
            round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.kpi_master_m t1
            left join his_bi.kpi_master_m t2 on t1.kpi_code = t2.kpi_code and t1.month_id = t2.month_id 
            and t2.kpi_code='JX0100208'
            where
            t1.month_id=c_monthlist.month_id
            and t1.kpi_code in('JX0100208','JX01002')
            group by 
            t1.month_id;                   
                        
  ---病死率
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100307';
        
        insert into his_bi.kpi_master_m
             select
            t1.month_id,
            'JX0100307' as kpi_code,
            round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as kpi_value,
            now() as update_time,
            round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.kpi_master_m t1
            left join his_bi.kpi_master_m t2 on t1.kpi_code = t2.kpi_code and t1.month_id = t2.month_id 
            and t2.kpi_code='JX0100308'
            where
            t1.month_id=c_monthlist.month_id
            and t1.kpi_code in('JX0100308','JX01003')
            group by 
            t1.month_id;
    
    ---病死率
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100407';
        insert into his_bi.kpi_master_m
             select
            t1.month_id,
            'JX0100407' as kpi_code,
            round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as kpi_value,
            now() as update_time,
            round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.kpi_master_m t1
            left join his_bi.kpi_master_m t2 on t1.kpi_code = t2.kpi_code and t1.month_id = t2.month_id 
            and t2.kpi_code='JX0100408'
            where
            t1.month_id=c_monthlist.month_id
            and t1.kpi_code in('JX0100408','JX01004')
            group by 
            t1.month_id;
    
    ---病死率
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100507';
        insert into his_bi.kpi_master_m
             select
            t1.month_id,
            'JX0100507' as kpi_code,
            round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as kpi_value,
            now() as update_time,
            round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.kpi_master_m t1
            left join his_bi.kpi_master_m t2 on t1.kpi_code = t2.kpi_code and t1.month_id = t2.month_id 
            and t2.kpi_code='JX0100508'
            where
            t1.month_id=c_monthlist.month_id
            and t1.kpi_code in('JX0100508','JX01005')
            group by 
            t1.month_id;
    
    ---病死率
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100607';
        insert into his_bi.kpi_master_m
             select
            t1.month_id,
            'JX0100607' as kpi_code,
            round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as kpi_value,
            now() as update_time,
            round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.kpi_master_m t1
            left join his_bi.kpi_master_m t2 on t1.kpi_code = t2.kpi_code and t1.month_id = t2.month_id 
            and t2.kpi_code='JX0100608'
            where
            t1.month_id=c_monthlist.month_id
            and t1.kpi_code in('JX0100608','JX01006')
            group by 
            t1.month_id;
    
---次均费用
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100304';
        
      insert into his_bi.kpi_master_m
             select
            t1.month_id,
            'JX0100304' as kpi_code,
            round(max(t1.kpi_value)/max(t2.kpi_value),5)as kpi_value,
            now() as update_time,
            round(max(t1.kpi_value)/max(t2.kpi_value),5)as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.kpi_master_m t1
            left join his_bi.kpi_master_m t2 on t1.kpi_code = t2.kpi_code and t1.month_id = t2.month_id 
            and t2.kpi_code='JX01003'
            where
            t1.month_id=c_monthlist.month_id
            and t1.kpi_code in('JX0100305','JX01003')
            group by 
            t1.month_id;
    
---次均费用
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100404';
        
      insert into his_bi.kpi_master_m
             select
            t1.month_id,
            'JX0100404' as kpi_code,
            round(max(t1.kpi_value)/max(t2.kpi_value),5)as kpi_value,
            now() as update_time,
            round(max(t1.kpi_value)/max(t2.kpi_value),5)as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.kpi_master_m t1
            left join his_bi.kpi_master_m t2 on t1.kpi_code = t2.kpi_code and t1.month_id = t2.month_id 
            and t2.kpi_code='JX01004'
            where
            t1.month_id=c_monthlist.month_id
            and t1.kpi_code in('JX0100405','JX01004')
            group by 
            t1.month_id;
    
---次均费用
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100504';
        
      insert into his_bi.kpi_master_m
             select
            t1.month_id,
            'JX0100504' as kpi_code,
            round(max(t1.kpi_value)/max(t2.kpi_value),5)as kpi_value,
            now() as update_time,
            round(max(t1.kpi_value)/max(t2.kpi_value),5)as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.kpi_master_m t1
            left join his_bi.kpi_master_m t2 on t1.kpi_code = t2.kpi_code and t1.month_id = t2.month_id 
            and t2.kpi_code='JX01005'
            where
            t1.month_id=c_monthlist.month_id
            and t1.kpi_code in('JX0100505','JX01005')
            group by 
            t1.month_id;
    
---次均费用
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100604';
        
      insert into his_bi.kpi_master_m
             select
            t1.month_id,
            'JX0100604' as kpi_code,
            round(max(t1.kpi_value)/max(t2.kpi_value),5)as kpi_value,
            now() as update_time,
            round(max(t1.kpi_value)/max(t2.kpi_value),5)as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.kpi_master_m t1
            left join his_bi.kpi_master_m t2 on t1.kpi_code = t2.kpi_code and t1.month_id = t2.month_id 
            and t2.kpi_code='JX01006'
            where
            t1.month_id=c_monthlist.month_id
            and t1.kpi_code in('JX0100605','JX01006')
            group by 
            t1.month_id;
---9.I类切口手术部位感染率
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX009';
        insert into his_bi.kpi_master_m
             select
            t1.month_id,
            'JX009' as kpi_code,
            round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as kpi_value,
            now() as update_time,
            round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.kpi_master_m t1
            left join his_bi.kpi_master_m t2 on t1.kpi_code = t2.kpi_code and t1.month_id = t2.month_id 
            and t2.kpi_code='JX00901'
            where
            t1.month_id=c_monthlist.month_id
            and t1.kpi_code in('JX00901','JX00902')
            group by 
            t1.month_id;

---8.手术患者并发症发生率
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX008';
        insert into his_bi.kpi_master_m
             select
            t1.month_id,
            'JX008' as kpi_code,
            round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as kpi_value,
            now() as update_time,
            round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.kpi_master_m t1
            left join his_bi.kpi_master_m t2 on t1.kpi_code = t2.kpi_code and t1.month_id = t2.month_id 
            and t2.kpi_code='JX00801'
            where
            t1.month_id=c_monthlist.month_id
            and t1.kpi_code in('JX00801','JX00802')
            group by 
            t1.month_id;
---6.出院患者四级手术比例
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX006';
        insert into his_bi.kpi_master_m
             select
            t1.month_id,
            'JX006' as kpi_code,
            round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as kpi_value,
            now() as update_time,
            round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.kpi_master_m t1
            left join his_bi.kpi_master_m t2 on t1.kpi_code = t2.kpi_code and t1.month_id = t2.month_id 
            and t2.kpi_code='JX00601'
            where
            t1.month_id=c_monthlist.month_id
            and t1.kpi_code in('JX00601','JX00602')
            group by 
            t1.month_id;

---5.出院患者微创手术占比
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX005';
        insert into his_bi.kpi_master_m
             select
            t1.month_id,
            'JX005' as kpi_code,
            round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as kpi_value,
            now() as update_time,
            round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.kpi_master_m t1
            left join his_bi.kpi_master_m t2 on t1.kpi_code = t2.kpi_code and t1.month_id = t2.month_id 
            and t2.kpi_code='JX00501'
            where
            t1.month_id=c_monthlist.month_id
            and t1.kpi_code in('JX00501','JX00502')
            group by 
            t1.month_id;
---门诊诊疗工作的总人次数（急诊、健康体检者不计入）
  delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0070201';
    
  insert into his_bi.kpi_master_m
        select
        t1.month_id,
        'JX0070201' as kpi_code,
        count(distinct t1.outp_visit_id) as kpi_value,
        now() as update_time,
        count(distinct t1.outp_visit_id) as self_value,
        null as check_flag,
        null as check_comm
        from
        his_bi.dw_outp_patient_info_m t1
        where
        t1.month_id = c_monthlist.month_id
        and t1.is_emergency  is null
        and t1.is_tj is null
        group by 
        t1.month_id;

---出院人数
  delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0070202';
    
  insert into his_bi.kpi_master_m
        select
        t1.month_id,
        'JX0070202' as kpi_code,
        COALESCE(count(distinct t1.pai_visit_id),0)  as kpi_value,
        now() as update_time,
        COALESCE(count(distinct t1.pai_visit_id),0)  as self_value,
        null as check_flag,
        null as check_comm
        from
        his_bi.dw_inp_patient_info_m t1
        where
        t1.month_id=c_monthlist.month_id
        group by 
        t1.month_id;
---该地该时间内活产数
  delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX06302';

  insert into his_bi.kpi_master_m
        select
         left(st_date,6) as month_id,
        'JX06302' as kpi_code,
        count(1)  as kpi_value,
        now() as update_time,
        count(1)  as self_value,
        null as check_flag,
        null as check_comm
        from
        his_bi.dwd_inp_quantity_d t1
        where
         left(st_date,6)=c_monthlist.month_id
        and t1.key = 'D00157'
        and t1.value not in ('2','3')
        group by
         left(st_date,6);

---该地该时间内活产数
  delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX07101';

  insert into his_bi.kpi_master_m
        select
         left(st_date,6) as month_id,
        'JX07101' as kpi_code,
        count(1)  as kpi_value,
        now() as update_time,
        count(1)  as self_value,
        null as check_flag,
        null as check_comm
        from
        his_bi.dwd_inp_quantity_d t1
        where
         left(st_date,6)=c_monthlist.month_id
        and t1.key = 'D00157'
        and t1.value not in ('2','3')
        group by
         left(st_date,6);

---产科门诊复诊预约诊疗人次数
  delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX07701';

  insert into his_bi.kpi_master_m
        select
        t1.month_id,
        'JX07701' as kpi_code,
        count(1)  as kpi_value,
        now() as update_time,
        count(1)   as self_value,
        null as check_flag,
        null as check_comm
        from
        his_bi.dw_outp_patient_info_m t1
        where
        t1.month_id=c_monthlist.month_id
        and t1.return_visit ='1'
        and t1.is_yygh = '1'
        and t1.dept_code in ('12010503','120121','12020101','12020201','12020402','12020502',
                          '12020602','12020702','12020902','120224','120225','120226','120227',
                          '120228','120229','120230','120215','120216','120217','120218','120219',
                          '120221','120222','120223','120231','120232','120233','120234','120235',
                          '120339','12051002')
        group by
        t1.month_id;

---产科门诊总诊疗人次数
  delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX07702';

  insert into his_bi.kpi_master_m
        select
        t1.month_id,
        'JX07702' as kpi_code,
        count(1)  as kpi_value,
        now() as update_time,
        count(1)   as self_value,
        null as check_flag,
        null as check_comm
        from
        his_bi.dw_outp_patient_info_m t1
        where
        t1.month_id=c_monthlist.month_id
        and t1.dept_code in ('12010503','120121','12020101','12020201','12020402','12020502',
                          '12020602','12020702','12020902','120224','120225','120226','120227',
                          '120228','120229','120230','120215','120216','120217','120218','120219',
                          '120221','120222','120223','120231','120232','120233','120234','120235',
                          '120339','12051002')
        group by
        t1.month_id;

  delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX07901';

  insert into his_bi.kpi_master_m
        select
        t1.month_id,
        'JX07901' as kpi_code,
        count(distinct t1.outp_visit_id) as kpi_value,
        now() as update_time,
        count(distinct t1.outp_visit_id) as self_value,
        null as check_flag,
        null as check_comm
        from
        his_bi.dw_outp_patient_info_m t1
        where
        t1.month_id = c_monthlist.month_id
        and t1.is_tj is null
        group by
        t1.month_id;
--- 实际占用的总床日数
  delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX08001';

  insert into his_bi.kpi_master_m
        select
        replace(left(t1.stat_date::text,7),'-','') as month_id,
        'JX08001' as kpi_code,
        sum(t1.bed_used) as kpi_value,
        now() as update_time,
        sum(t1.bed_used) as self_value,
        null as check_flag,
        null as check_comm
        from
        his_bi.dw_inp_dept_work_d t1
        where
        replace(left(t1.stat_date::text,7),'-','') = c_monthlist.month_id
        group by
        replace(left(stat_date::text,7),'-','');
---实际开放的总床日数
  delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX08002';

  insert into his_bi.kpi_master_m
        select
        replace(left(t1.stat_date::text,7),'-','') as month_id,
        'JX08002' as kpi_code,
        sum(t1.sy_num) as kpi_value,
        now() as update_time,
        sum(t1.sy_num) as self_value,
        null as check_flag,
        null as check_comm
        from
        his_bi.dw_inp_dept_work_d t1
        where
        replace(left(t1.stat_date::text,7),'-','') = c_monthlist.month_id
        group by
        replace(left(stat_date::text,7),'-','');

---床位使用率
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX080';
        insert into his_bi.kpi_master_m
             select
            t1.month_id,
            'JX080' as kpi_code,
            round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as kpi_value,
            now() as update_time,
            round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.kpi_master_m t1
            left join his_bi.kpi_master_m t2 on t1.kpi_code = t2.kpi_code and t1.month_id = t2.month_id
            and t2.kpi_code='JX08001'
            where
            t1.month_id=c_monthlist.month_id
            and t1.kpi_code in('JX08001','JX08002')
            group by
            t1.month_id;

---产科复诊预约诊疗率
    delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX077';
        insert into his_bi.kpi_master_m
             select
            t1.month_id,
            'JX077' as kpi_code,
            round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as kpi_value,
            now() as update_time,
            round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as self_value,
            null as check_flag,
            null as check_comm
            from
            his_bi.kpi_master_m t1
            left join his_bi.kpi_master_m t2 on t1.kpi_code = t2.kpi_code and t1.month_id = t2.month_id
            and t2.kpi_code='JX07701'
            where
            t1.month_id=c_monthlist.month_id
            and t1.kpi_code in('JX07701','JX07702')
            group by
            t1.month_id;
	---同期住院患者总人数
  delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX07202';

  insert into his_bi.kpi_master_m
        select
        replace(left(t1.stat_date::text,7),'-','') as month_id,
        'JX07202' as kpi_code,
        count(distinct t1.pai_visit_id) as kpi_value,
        now() as update_time,
        count(distinct t1.pai_visit_id) as self_value,
        null as check_flag,
        null as check_comm
        from
        his_bi.report_adt_status t1
        where
        replace(left(t1.stat_date::text,7),'-','') = c_monthlist.month_id
        and t1.status = 0
        group by
        replace(left(stat_date::text,7),'-','');
   end loop;
   RETURN 'SUCCESS';  
END;
$$;

alter function fun_kpi_master_m_swr(varchar, varchar)
  owner to postgres;

