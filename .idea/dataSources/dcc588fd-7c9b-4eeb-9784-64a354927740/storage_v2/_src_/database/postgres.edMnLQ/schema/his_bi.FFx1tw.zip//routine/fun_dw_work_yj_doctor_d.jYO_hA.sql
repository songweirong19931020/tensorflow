create function fun_dw_work_yj_doctor_d(v_start_date character varying, v_end_date character varying)
  returns character varying
language plpgsql
as $$
/***
函数名称：医技科室检查-检验工作量汇总
    作用：医技科室检查-检验工作量表
  开发人：liuf 2020年7月2日 
命名规范：FUN_模型层级(DWD或者DW)_业务表描叙_日期类型D或者M，D表示按天统计，M表示按月统计
    入参：v_start_date，v_end_date  格式均为yyyymmdd，可以一次运行多天的数据
***/
DECLARE
  c_daylist record;
	o_start_date varchar;
	o_end_date varchar;
	i_start_date varchar;
	i_end_date varchar;
	i_count  int4;
BEGIN
	
  /*如果指标没有历史指标数据，甘肃默认以20200101开始计算*/
  select count(1),to_char(to_date(to_char(now(),'yyyymmdd'),'yyyymmdd') - 1,'yyyymmdd')
         into i_count,i_end_date
	  from his_bi.dw_work_yj_doctor_d
	 ;
   
  if(i_count = 0)
	  then 
		  i_start_date := '20200101';
			--raise notice '0 i_start_date is: %', i_start_date;
	else if(i_count > 0)
	  then
		  i_start_date := i_end_date;
			--raise notice '1 i_start_date is: %', i_start_date;
  end if;
	end if;
		
  if(length(trim(v_start_date)) = 0 and length(trim(v_end_date)) = 0)
	/*kettle 调用时，如果不设置参数，默认传入 空字符串，那么默认取当前日期后退一天 */
	  then 
	    o_start_date := i_start_date;
	    o_end_date := i_end_date;
			--raise notice '2 o_start_date is: %', o_start_date;
			--raise notice '2 o_end_date is: %', o_end_date;
	else if (length(trim(v_start_date)) <> 0 and length(trim(v_end_date)) <> 0)
	/*PG function 如果参入任何参数，那么以实际入参为准*/
	  then 
		  o_start_date := v_start_date;
	    o_end_date := v_end_date;
			--raise notice '3 o_start_date is: %', o_start_date;
			--raise notice '3 o_end_date is: %', o_end_date;
	end if;
	end if;
	
	  for c_daylist in (select day_id from his_bi.dim_date_info where day_id >= o_start_date and day_id <= o_end_date order by day_id)
	  loop 
    --raise notice '4 c_daylist.day_id is: %', c_daylist.day_id;
    
    delete from his_bi.dw_work_yj_doctor_d where st_date = c_daylist.day_id;
    
		insert into his_bi.dw_work_yj_doctor_d
		(
			st_date,item_code,item_name,dept_code,dept_name,parent_dept_code,parent_dept_name,
			diag_emp_id,diag_emp_name,performed_dept_code,performed_dept_name,in_out_flag,
			item_class,amount,patient_num,charges,area_code,work_dept_code,work_dept_name,insert_time         
		)
		SELECT st_date,
			项目父编码 item_code,
			项目父名称 item_name,
			开单科室编码 dept_code,
			开单科室 dept_name,
			parent_dept_code,
			parent_dept_name,
			diag_emp_id,
			diag_emp_name, 
			执行科室编码 AS performed_dept_code,
			执行科室 AS performed_dept_name,
			in_out_flag,
			item_class,
			次数 AS amount, 
			人次 AS patient_num,
			费用 AS charges,
			area_code,
			work_dept AS work_dept_code,
			NAME AS work_dept_name,
			now()
 FROM 
			(
			SELECT to_char(m.enter_date,'yyyymmdd') st_date,
						 count(DISTINCT concat(m.patient_id,m.visit_id)) AS 人次,
						 m.in_out_flag,
						 t2.property1 AS area_code,
						 m.performed_by 执行科室编码,     
						 t1.name AS 执行科室,
						 m.ordered_by 开单科室编码,
						 t2.name AS 开单科室, 
						 n1.code as parent_dept_code,
						 n1.name as parent_dept_name,
						 m.diag_emp_id,
						 m.diag_emp_name,
						 SUM(m.charges) 费用,
						 count(DISTINCT concat(m.order_id,m.clinic_id)) AS 次数,
						 m.clinic_id 项目父编码,
						 tt.item_name 项目父名称,
						 m.item_class, 
						 u.work_dept,  
						 n2.name
		FROM his_bi.bms_bill_item  m
		left join his_bi.bds_bds_clinic_item_list tt on m.clinic_id = tt.id
		left join his_bi.bds_bds_organization t1 on m.performed_by = t1.code
		left join his_bi.bds_bds_organization t2 on m.ordered_by = t2.code
		LEFT join his_bi.bds_bds_organization n1 on t2.parent_id = n1.id
		left join his_bi.uum_uum_user u on m.diag_emp_id = u.user_name
		left join his_bi.bds_bds_organization n2 on u.work_dept = n2.code
		WHERE m.item_name <> '体检费'    --排除体检
		AND m.refund_flag IS NULL 
		AND m.rel_refund_id IS NULL
		AND m.item_class IN ('C','D')
		and t2.property1 in ('H0001')
		AND t1.property3='4'   --执行科室为医技科室
		AND m.in_out_flag='O'
		AND m.clinic_id IS NOT NULL
		AND m.enter_date>= to_date(c_daylist.day_id,'yyyyMMdd')
		AND m.enter_date<  to_date(c_daylist.day_id,'yyyyMMdd') + 1
		GROUP BY   to_char(m.enter_date,'yyyymmdd'),
						 m.in_out_flag, 
						 t2.property1 ,
						 m.performed_by,
						 t1.name ,
						 m.ordered_by, 
						 t2.name,
						 tt.item_name,
						 m.clinic_id ,
						 m.item_class,
							m.diag_emp_id,
						 m.diag_emp_name,
						 u.work_dept,  
						 n2.name,
						 n1.code ,
						 n1.name
		UNION ALL
		SELECT   to_char(m.enter_date,'yyyymmdd') st_date,
						 count(DISTINCT concat(m.patient_id,m.visit_id)) AS 人次,
						 m.in_out_flag,
						 t2.property1 AS area_code,
						 m.performed_by 执行科室编码,     
						 t1.name AS 执行科室,
						 m.ordered_by 开单科室编码,
						 t2.name AS 开单科室,
						 n1.code as parent_dept_code,
						 n1.name as parent_dept_name, 
						 m.diag_emp_id,
						 m.diag_emp_name,
						 SUM(m.charges) 费用,
						 count(DISTINCT concat(m.order_id,m.clinic_id)) AS 次数,
						 m.clinic_id 项目父编码,
						 tt.item_name 项目父名称,
						 m.item_class,
						 u.work_dept,  
						 n2.name
		FROM his_bi.bms_bill_item  m
		left join his_bi.bds_bds_clinic_item_list tt on m.clinic_id = tt.id
		left join his_bi.bds_bds_organization t1 on m.performed_by = t1.code
		left join his_bi.bds_bds_organization t2 on m.ordered_by = t2.code
		LEFT join his_bi.bds_bds_organization n1 on t2.parent_id = n1.id
		left join his_bi.uum_uum_user u on m.diag_emp_id = u.user_name
		left join his_bi.bds_bds_organization n2 on u.work_dept = n2.code
		WHERE m.item_class IN ('C','D')
		AND m.refund_flag IS NULL 
		AND m.rel_refund_id IS NULL
		and t2.property1 in ('H0001')
		AND t1.property3='4'  --执行科室为医技科室
		AND m.in_out_flag='I'
		AND m.clinic_id IS NOT NULL
		AND m.enter_date>= to_date(c_daylist.day_id,'yyyyMMdd')
		AND m.enter_date<  to_date(c_daylist.day_id,'yyyyMMdd') + 1
		GROUP BY   to_char(m.enter_date,'yyyymmdd'),
						 m.in_out_flag, 
						 t2.property1 ,
						 m.performed_by,
						 t1.name ,
						 m.ordered_by, 
						 t2.name,
						 tt.item_name,
						 m.clinic_id ,
						 m.item_class,
							m.diag_emp_id,
						 m.diag_emp_name,
						 u.work_dept,  
						 n2.name,
						 n1.code ,
						 n1.name
						 ) as total
			;

   end loop;
   RETURN 'SUCCESS';  
END;
$$;

alter function fun_dw_work_yj_doctor_d(varchar, varchar)
  owner to postgres;

