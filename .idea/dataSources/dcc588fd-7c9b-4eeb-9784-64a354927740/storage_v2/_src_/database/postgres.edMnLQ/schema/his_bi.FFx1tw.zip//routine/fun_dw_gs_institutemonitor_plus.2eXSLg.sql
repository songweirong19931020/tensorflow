create function fun_dw_gs_institutemonitor_plus(v_year character varying)
  returns character varying
language plpgsql
as $$
/***
函数名称：机构监测数据竖表
    作用：机构监测数据转换成竖表,更新数据
  开发人：sdd 2020-07-13
命名规范：甘肃_机构监测数据
业务解释：
    入参：v_year 年份   按调查年份更新或新增数据
		
		说明：
		
***/
DECLARE
  c_kpilist   record;
	error  int4;
	
	BEGIN
	error:=0;

		--校验原表数据是否准确
		SELECT count(*)
		into error
		from his_bi.gs_institutemonitor t
		where t.调查年度<>v_year;
		
		IF error<>0 then 	
   RETURN '存在年份不一致数据';
	 end if;
	 
	 
	-- 删除该年度调查数据 
    delete from his_bi.gs_institutemonitor_plus  where 调查年度=v_year;		
    delete from his_bi.dim_stitute_info  where 调查年度=v_year;
		

	-- 按指标循环插入该年度调查数据
  for c_kpilist in (
												select	B.attname AS 字段名
												from	pg_class A
												left join pg_attribute B on
													A.oid = B.attrelid AND B.attnum > 0
												where A.relname='gs_institutemonitor'
												and B.attname not in('机构名称（系统名）','调查年度','机构级别')
	 )
  loop 
	
		execute '
		insert into his_bi.gs_institutemonitor_plus
		SELECT t."机构名称（系统名）",
		t.调查年度,
		'''||c_kpilist.字段名||''',
		t.'||'"'||''||c_kpilist.字段名||''||'"'||',
		t.机构级别
		from his_bi.gs_institutemonitor t
		where t.调查年度='''||v_year||'''
		' ;			 
   end loop;
	 /*
	 -- 更新机构信息表
	 INSERT his_bi.dim_stitute_info
	 SELECT "机构名称（系统名）",
	 "行政区划",
	 "机构类型",
	 "机构级别",
	 "调查年度"
	  from his_bi.gs_institutemonitor
		where 调查年度=v_year;*/
	 	 	 
  -- 健康教育材料指标去除逗号，方便统计
	 UPDATE his_bi.gs_institutemonitor_plus SET 指标值=REPLACE(指标值,',','') WHERE 指标名称='健康教育材料' and 调查年度=v_year;
	 
	 --	更新卫技人员是否达标数据
	 SELECT "机构名称",
	 "调查年度",
	 '卫技人员数量是否达标',
	 case when "min"("指标值"::numeric)/"max"("指标值"::numeric)>=0.75 and 机构级别='省级' or "min"("指标值"::numeric)/"max"("指标值"::numeric)>=0.8 then 1 else 0 end as 指标值,
	 机构级别
	 from his_bi.gs_institutemonitor_plus
	 WHERE 指标名称 in('职工总数','卫生技术人员')
	 and 调查年度=v_year
	 group by "机构名称","调查年度",机构级别;
	 
	 -- 更新盈亏数据
	 	 INSERT into his_bi.gs_institutemonitor_plus
	 SELECT t."机构名称",
	 t."调查年度",
	 '盈亏',
	 t."指标值"::numeric-t1."指标值"::numeric as 指标值,
	 t.机构级别
	 from his_bi.gs_institutemonitor_plus t
	 left join his_bi.gs_institutemonitor_plus t1
	 on  t1."机构名称"=t."机构名称"
	 and t1."调查年度"=t."调查年度"
	 and t1.机构级别=t.机构级别
	 and t1.指标名称='总支出'
	 WHERE t.指标名称='总收入'
	 and t.调查年度=v_year;
	 
	 delete from his_bi.gs_institutemonitor;
	 
   RETURN 'SUCCESS';  
END;
$$;

alter function fun_dw_gs_institutemonitor_plus(varchar)
  owner to postgres;

