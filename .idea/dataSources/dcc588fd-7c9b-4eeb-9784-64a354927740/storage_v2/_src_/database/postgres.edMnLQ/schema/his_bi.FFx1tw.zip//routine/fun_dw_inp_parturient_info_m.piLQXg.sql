create function fun_dw_inp_parturient_info_m(v_start_month character varying, v_end_month character varying)
  returns character varying
language plpgsql
as $$
/***
函数名称：产妇信息表（不包含多胎）
    作用：产妇患者信息表
  开发人：leslie 2020年6月16日
命名规范：FUN_模型层级(DWD或者DW)_KPI编码_日期类型D或者M，D表示按天统计，M表示按月统计
 KPI编码：根据原子指标编码规划来的
    入参：v_start_date，v_end_date  格式均为yyyymmdd，可以一次运行多天的数据
***/
DECLARE
  c_monthlist   record;
  o_start_month varchar;
  o_end_month   varchar;
  i_start_month varchar;
  i_end_month   varchar;
  i_count       int4;
	tmp_file 			varchar;  --COPY方案临时文件名：该文件将被保存在所连接的服务器的文件目录。
BEGIN
	/*
	  COPY方案临时文件名。
		注意：
		1. 该文件将被保存在所连接的服务器的文件目录中，每一个函数必须使用自定义能够与其他函数区分的文件名
		2. 方便维护，历史文件都保存到'/home/postgres/'目录中。
		TODO : 后续规划统一临时文件目录，KETTLE调度完成之后，需要删除对应的临时文件（*需要想办法在每台服务器上统一创建临时目录）
	*/
	
  /*如果指标没有历史指标数据，甘肃默认以202001开始计算，结束月份以当前月份往前推1个月*/
  select count(1),to_char((date_trunc('month', now()) + interval '-1 month'),'yyyymm')
	       into i_count,i_end_month
    from his_bi.dw_inp_parturient_info_m;
   
  if(i_count = 0)
    then 
      i_start_month := '202001';
      --raise notice '0 i_start_month is: %', i_start_month;
  else if(i_count > 0)
    then
      i_start_month := i_end_month;
      --raise notice '1 i_start_month is: %', i_start_month;
  end if;
  end if;
    
  if(length(trim(v_start_month)) = 0 and length(trim(v_end_month)) = 0)
  /*kettle 调用时，如果不设置参数，默认传入 空字符串，那么默认取当前月份前1个月为截止月份 */
    then 
      o_start_month := i_start_month;
      o_end_month := i_end_month;
      --raise notice '2 o_start_month is: %', o_start_month;
      --raise notice '2 o_end_month is: %', o_end_month;
  else if (length(trim(v_start_month)) <> 0 and length(trim(v_end_month)) <> 0)
  /*PG function 如果参入任何参数，那么以实际入参为准*/
    then 
      o_start_month := v_start_month;
      o_end_month := v_end_month;
      --raise notice '3 o_start_month is: %', o_start_month;
      --raise notice '3 o_end_month is: %', o_end_month;
  end if;
  end if;
	  for c_monthlist in (select distinct month_id from his_bi.dim_date_info where month_id >= o_start_month and month_id <= o_end_month order by month_id)
    loop
    --raise notice '4 c_daylist.day_id is: %', c_daylist.day_id;
    
    delete from his_bi.dw_inp_parturient_info_m where month_id = c_monthlist.month_id;
    
  insert into his_bi.dw_inp_parturient_info_m
select
t1.pai_visit_id,
t1.patient_id,
t1.visit_id,
pt.mother_name,
pt.age_string,
pt.birth_date,
pt.in_dept_date,
pt.in_dept,
max(case when t1.key='D00151' and d1.month_id=c_monthlist.month_id then t1.value else 0 end ) as is_primipara,
max(case when t1.key='D00152' and d1.month_id=c_monthlist.month_id then t1.value else 0 end ) as parity,
max(case when t1.key='D00155' and d1.month_id=c_monthlist.month_id then t1.value else 0 end ) as is_die,
max(case when t1.key='D00156' and d1.month_id=c_monthlist.month_id then t1.value else 0 end ) as postpartum_hemorrhage,
max(case when t1.key='D00159' and d1.month_id=c_monthlist.month_id then t1.value else 0 end ) as is_parturient,
max(case when t1.key='D00164' and d1.month_id=c_monthlist.month_id then t1.value else 0 end ) as is_cervical_repair,
max(case when t1.key='D00165' and d1.month_id=c_monthlist.month_id then t1.value else 0 end ) as is_placental_retention,
max(case when t1.key='D00166' and d1.month_id=c_monthlist.month_id then t1.value else 0 end ) as is_clearing_the_uterus,
max(case when t1.key='D00167' and d1.month_id=c_monthlist.month_id then t1.value else 0 end ) as is_placental_abruption_by_hand,
max(case when t1.key='D00168' and d1.month_id=c_monthlist.month_id then t1.value else 0 end ) as is_perineum_anesthesia,
max(case when t1.key='D00169' and d1.month_id=c_monthlist.month_id then t1.value else 0 end ) as is_postpartum_hemorrhage,
max(case when t1.key='D00170' and d1.month_id=c_monthlist.month_id then t1.value else 0 end ) as is_doula,
max(case when t1.key='D00171' and d1.month_id=c_monthlist.month_id then t1.value else 0 end ) as is_childbirth_in_water,
max(case when t1.key='D00172' and d1.month_id=c_monthlist.month_id then t1.value else 0 end ) as is_stillbirth,
c_monthlist.month_id as month_id
from 
his_bi.dwd_inp_quantity_d t1
left join his_bi.pts_pai_birth_reg pt on t1.pai_visit_id = pt.pai_visit_id
left join his_bi.dim_date_info d1 on t1.st_date = d1.day_id and d1.month_id = c_monthlist.month_id
where 1=1
 and t1.key in('D00151','D00152','D00155','D00156',
'D00159','D00164','D00165','D00166',
'D00167','D00168','D00169','D00170','D00171','D00172')
 and d1.month_id = c_monthlist.month_id
group by 
t1.pai_visit_id,
t1.patient_id,
t1.visit_id,
pt.mother_name,
pt.age_string,
pt.birth_date,
pt.in_dept_date,
pt.in_dept
having max(case when t1.key='D00152' and d1.month_id=c_monthlist.month_id then t1.value else 0 end ) <> 0; 
   end loop;
   RETURN 'SUCCESS';  
END;
$$;

alter function fun_dw_inp_parturient_info_m(varchar, varchar)
  owner to postgres;

