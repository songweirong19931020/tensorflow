create view view_dw_inp_drgs_patient_m as
  SELECT drgs.month_id              AS "月份",
         drgs.brxh                  AS "病案号",
         drgs.patient_id            AS "患者ID",
         drgs.pai_visit_id          AS "就诊唯一标识",
         drgs.visit_id              AS "就诊次数",
         drgs.patient_name          AS "患者姓名",
         drgs.age                   AS "年龄",
         drgs.age_flag              AS "年龄tag",
         drgs.sex                   AS "性别",
         drgs.area_code             AS "院区",
         drgs.in_dept_code          AS "入院科室编码",
         drgs.in_dept_name          AS "入院科室名称",
         drgs.out_dept_code         AS "出院科室编码",
         drgs.out_dept_name         AS "出院科室",
         org.root_name              AS "出院保健部名称",
         drgs.in_time               AS "入院日期",
         drgs.out_time              AS "出院日期",
         drgs.out_diag_code         AS "出院主诊断编码",
         drgs.out_diag_name         AS "出院主诊断名称",
         drgs.in_days               AS "住院天数",
         drgs.drgs_name             AS "重点疾指标编码",
         drgs.return_drgs_1         AS "重点疾病当天重返标志",
         drgs.return_drgs_2to15     AS "重点疾病2-15日内重返标志",
         drgs.return_drgs_16to31    AS "重点疾病16-31日内重返标志",
         drgs.return_drgs_1to31     AS "1-31天重返",
         drgs.return_z_drgs_7to15   AS "重点疾病7-15日重返标志",
         drgs.return_z_drgs_16to31  AS "重点疾病16-31日重返标志",
         drgs.is_exzl               AS "恶性肿瘤编码判断",
         drgs.zgqk                  AS "转归情况",
         drgs.lyfs                  AS "离院方式",
         drgs.total_fees            AS "总费用",
         drgs.pham_fees             AS "药品费用",
         drgs.material_fees         AS "材料费用",
         drgs.cur_fees              AS "治疗费用",
         drgs.oper_fees             AS "手术费用",
         drgs.other_fees            AS "其它费用",
         drgs.western_fees          AS "西药费用",
         drgs.herb_fees             AS "草药费用",
         drgs.anti_pham_fees        AS "抗菌药物费",
         drgs.insert_time           AS "插入日期",
         drgs.team_id               AS "诊疗组ID",
         drgs.team_name             AS "诊疗组名称",
         drgs.doctor_chief          AS "主任医生编码",
         drgs.doctor_chief_name     AS "主任医生姓名",
         drgs.doctor_attending      AS "主治医生编码",
         drgs.doctor_attending_name AS "主治医生姓名",
         drgs.md5,
         k.kpi_name                 AS "重点疾病名称",
         d.value                    AS "是否死亡"
  FROM (((his_bi.dw_inp_drgs_patient_m drgs
      LEFT JOIN his_bi.dwd_kpi_detail_info k ON (((drgs.drgs_name) :: text = (k.kpi_code) :: text)))
      LEFT JOIN his_bi.dwd_inp_quantity_d d ON ((
    ((drgs.patient_id) :: text = (d.patient_id) :: text) AND (drgs.visit_id = d.visit_id) AND
    ((d.key) :: text = 'D00155' :: text))))
      LEFT JOIN his_bi.v_system_organization org ON (((org.code) :: text = (drgs.out_dept_code) :: text)));

alter table view_dw_inp_drgs_patient_m
  owner to postgres;

