create function "fun_dwd_D00154_d"(v_start_date character varying, v_end_date character varying)
  returns character varying
language plpgsql
as $$
/***
函数名称：患者结算方式--(枚举值:1城乡医保(CXYB)、2异地职工(YDZG)、3本院职工(BYZG)、4省医保(GSPHI)、5商业医疗(SYYL)、6异地居民(YDJM)、7市医保(LZCHI)、
          --8居民医保(JM)、9全公费(QGF)、10电力医保(DLYB)、11自费(A)、12铁路医保(TLYB)、13新农合(GSNRCMI)、14农合自费(NHZF)、15省直生育(SZSY)、
          --16新生儿(XSE)、17贫困救助(PKJZ)、18医疗保险(YLBX)、19老年减免(LNJM))
    作用：统计某天患者结算方式
  开发人：wy 2020-05-15
命名规范：FUN_模型层级(DWD或者DW)_KPI编码_日期类型D或者M，D表示按天统计，M表示按月统计
 KPI编码：D00154 根据原子指标编码规划来的
    入参：v_start_date，v_end_date  格式均为yyyymmdd，可以一次运行多天的数据
***/
DECLARE
  c_daylist record;
  o_start_date varchar;
  o_end_date varchar;
  i_start_date varchar;
  i_end_date varchar;
  i_count  int4;
BEGIN

  /*如果指标没有历史指标数据，甘肃默认以20200101开始计算*/
  select count(1),to_char(to_date(to_char(now(),'yyyymmdd'),'yyyymmdd') - 1,'yyyymmdd')
         into i_count,i_end_date
    from his_bi.dwd_inp_quantity_d
   where key = 'D00154';
   
  if(i_count = 0)
    then 
      i_start_date := '20200101';
      --raise notice '0 i_start_date is: %', i_start_date;
  else if(i_count > 0)
    then
      i_start_date := i_end_date;
      --raise notice '1 i_start_date is: %', i_start_date;
  end if;
  end if;
    
  if(length(trim(v_start_date)) = 0 and length(trim(v_end_date)) = 0)
  /*kettle 调用时，如果不设置参数，默认传入 空字符串，那么默认取对应key 最大日期加一天 对应逻辑line 12 */
    then 
      o_start_date := i_start_date;
      o_end_date := i_end_date;
      --raise notice '2 o_start_date is: %', o_start_date;
      --raise notice '2 o_end_date is: %', o_end_date;
  else if (length(trim(v_start_date)) <> 0 and length(trim(v_end_date)) <> 0)
  /*PG function 如果参入任何参数，那么以实际入参为准*/
    then 
      o_start_date := v_start_date;
      o_end_date := v_end_date;
      --raise notice '3 o_start_date is: %', o_start_date;
      --raise notice '3 o_end_date is: %', o_end_date;
  end if;
  end if;
  
  for c_daylist in (select day_id from his_bi.dim_date_info where day_id >= o_start_date and day_id <= o_end_date order by day_id)
  loop 
  
  --raise notice '4 c_daylist.day_id is: %', c_daylist.day_id;
  
  delete from his_bi.dwd_inp_quantity_d where st_date = c_daylist.day_id and key = 'D00154';
  
  INSERT into his_bi.dwd_inp_quantity_d(key,value,patient_id,visit_id,pai_visit_id,insert_date,
                                            remark,st_date) 
	select 'D00154',
					case 
					when pt.cost_type = 'CXYB'then 1
					when pt.cost_type = 'YDZG'then 2
					when pt.cost_type = 'BYZG'then 3
					when pt.cost_type = 'GSPHI'then 4
					when pt.cost_type = 'SYYL'then 5
					when pt.cost_type = 'YDJM'then 6
					when pt.cost_type = 'LZCHI'then 7
					when pt.cost_type = 'JM'then 8
					when pt.cost_type = 'QGF'then 9
					when pt.cost_type = 'DLYB'then 10
					when pt.cost_type = 'A'then 11
					when pt.cost_type = 'TLYB'then 12
					when pt.cost_type = 'GSNRCMI'then 13
					when pt.cost_type = 'NHZF'then 14
					when pt.cost_type = 'SZSY'then 15
					when pt.cost_type = 'XSE'then 16
					when pt.cost_type = 'PKJZ'then 17
					when pt.cost_type = 'YLBX'then 18
					when pt.cost_type = 'LNJM'then 19
					end, 
					--(枚举值:1城乡医保(CXYB)、2异地职工(YDZG)、3本院职工(BYZG)、4省医保(GSPHI)、5商业医疗(SYYL)、6异地居民(YDJM)、7市医保(LZCHI)、
          --8居民医保(JM)、9全公费(QGF)、10电力医保(DLYB)、11自费(A)、12铁路医保(TLYB)、13新农合(GSNRCMI)、14农合自费(NHZF)、15省直生育(SZSY)、
          --16新生儿(XSE)、17贫困救助(PKJZ)、18医疗保险(YLBX)、19老年减免(LNJM))
					pt.patient_id,
					pt.visit_id,
					pt.pai_visit_id,
					now(),
					'患者结算方式', 
					to_char(pt.discharge_dept_date,'yyyyMMdd')
	from his_bi.pts_pai_visit pt
	where 1=1
		and pt.discharge_dept_date >= to_date(c_daylist.day_id,'yyyyMMdd')
		and pt.discharge_dept_date <  to_date(c_daylist.day_id,'yyyyMMdd') + 1	
		;
    
	end loop;
	RETURN 'SUCCESS';  
END;
$$;

alter function "fun_dwd_D00154_d"(varchar, varchar)
  owner to postgres;

