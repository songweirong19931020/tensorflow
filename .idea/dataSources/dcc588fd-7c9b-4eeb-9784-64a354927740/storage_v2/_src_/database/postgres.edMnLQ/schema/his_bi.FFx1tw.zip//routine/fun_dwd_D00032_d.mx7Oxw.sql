create function "fun_dwd_D00032_d"(v_start_date character varying, v_end_date character varying)
  returns character varying
language plpgsql
as $$
/***
函数名称：抗菌药物—门诊非限制性抗菌药物使用统计
    作用：统计某天门诊患者中使用了非限制性抗菌药物的人数
  开发人：liuf 2020-03-31
命名规范：FUN_模型层级(DWD或者DW)_KPI编码_日期类型D或者M，D表示按天统计，M表示按月统计
 KPI编码：D00032  根据原子指标编码规划来的
    入参：v_start_date，v_end_date  格式均为yyyymmdd，可以一次运行多天的数据
***/
DECLARE
	c_daylist record;
	o_start_date varchar;
	o_end_date varchar;
	i_start_date varchar;
	i_end_date varchar;
	i_count  int4;
BEGIN

  /*如果指标没有历史指标数据，甘肃默认以20200101开始计算*/
  select count(1),to_char(to_date(to_char(now(),'yyyymmdd'),'yyyymmdd') - 1,'yyyymmdd')
         into i_count,i_end_date
	  from his_bi.dwd_outp_quantity_d
	 where key = 'D00032';
	 
  if(i_count = 0)
	  then 
		  i_start_date := '20200101';
			--raise notice '0 i_start_date is: %', i_start_date;
	else if(i_count > 0)
	  then
		  i_start_date := i_end_date;
			--raise notice '1 i_start_date is: %', i_start_date;
  end if;
	end if;
		

  if(length(trim(v_start_date)) = 0 and length(trim(v_end_date)) = 0)
	/*kettle 调用时，如果不设置参数，默认传入 空字符串，那么默认取当前日期后退一天 */
	  then 
	    o_start_date := i_start_date;
	    o_end_date := i_end_date;
			--raise notice '2 o_start_date is: %', o_start_date;
			--raise notice '2 o_end_date is: %', o_end_date;
	else if (length(trim(v_start_date)) <> 0 and length(trim(v_end_date)) <> 0)
	/*PG function 如果参入任何参数，那么以实际入参为准*/
	  then 
		  o_start_date := v_start_date;
	    o_end_date := v_end_date;
			--raise notice '3 o_start_date is: %', o_start_date;
			--raise notice '3 o_end_date is: %', o_end_date;
	end if;
	end if;
	
	for c_daylist in (select day_id from his_bi.dim_date_info where day_id >= o_start_date and day_id <= o_end_date order by day_id)
	loop 
	
	--raise notice '4 c_daylist.day_id is: %', c_daylist.day_id;
	
	delete from his_bi.dwd_outp_quantity_d where st_date = c_daylist.day_id and key = 'D00032';
	
  INSERT into his_bi.dwd_outp_quantity_d(key,value,patient_id,visit_id,outp_visit_id,insert_date,
																						remark,st_date) 
  select 
		     'D00032',
			   '1',
				 tmp.patient_id,
				 tmp.visit_id,
				 tmp.outp_visit_id,
				 now(),
				 '是否使用非限制级抗菌药物', 
				 tmp.st_date
    from (select to_char(pt.registering_time,'yyyyMMdd') as st_date,
								 pt.outp_visit_id,
							   pt.patient_id,
							   pt.visit_id
					  from his_bi.pts_outp_patient_visit pt
					 where pt.registry_flag <>3 --3表示作废
             and pt.reg_sequence is not null
             and pt.registering_time >= to_date(c_daylist.day_id,'yyyyMMdd')
             and pt.registering_time <  to_date(c_daylist.day_id,'yyyyMMdd')+1
		       group by to_char(pt.registering_time,'yyyyMMdd'),
										pt.outp_visit_id,
                    pt.patient_id,
                    pt.visit_id) tmp 
	    inner join his_bi.bms_bill_item bm 
			        on (tmp.patient_id = bm.patient_id 
						      and tmp.visit_id = bm.visit_id 
									and bm.in_out_flag = 'O')
			     where exists (select 1 from his_bi.dms_pham_cust_def_cont 
			                    where cont_type_id = 'TJ0055' 
										        and cont_value = '1' 
											      and pham_std_code = bm.item_code)
           group by tmp.st_date,
                    tmp.outp_visit_id,
                    tmp.patient_id,
                    tmp.visit_id;
	 end loop;
   RETURN 'SUCCESS';  
END;
$$;

alter function "fun_dwd_D00032_d"(varchar, varchar)
  owner to postgres;

