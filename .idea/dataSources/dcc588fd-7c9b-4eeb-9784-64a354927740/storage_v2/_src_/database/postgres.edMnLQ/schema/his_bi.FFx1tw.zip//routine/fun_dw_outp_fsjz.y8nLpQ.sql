create function fun_dw_outp_fsjz(v_start_date character varying, v_end_date character varying)
  returns character varying
language plpgsql
as $$
/***
函数名称：分时就诊时间明细表
    作用：分时就诊时间明细表
  开发人：wrsong 2020年6月2日
命名规范：FUN_模型层级(DWD或者DW)_KPI编码_日期类型D或者M，D表示按天统计，M表示按月统计
 KPI编码：D00236根据原子指标编码规划来的
    入参：v_start_date，v_end_date  格式均为yyyymmdd，可以一次运行多天的数据
***/
DECLARE
    c_daylist record;
    o_start_date varchar;
    o_end_date varchar;
    i_start_date varchar;
    i_end_date varchar;
    i_count  int4;
BEGIN

        
  if(length(trim(v_start_date)) = 0 and length(trim(v_end_date)) = 0)
    /*kettle 调用时，如果不设置参数，默认传入 空字符串，那么默认取当前日期后退一天 */
      then 
        o_start_date := i_start_date;
        o_end_date := i_end_date;
            --raise notice '2 o_start_date is: %', o_start_date;
            --raise notice '2 o_end_date is: %', o_end_date;
    else if (length(trim(v_start_date)) <> 0 and length(trim(v_end_date)) <> 0)
    /*PG function 如果参入任何参数，那么以实际入参为准*/
      then 
          o_start_date := v_start_date;
        o_end_date := v_end_date;
            --raise notice '3 o_start_date is: %', o_start_date;
            --raise notice '3 o_end_date is: %', o_end_date;
    end if;
    end if;
    
    for c_daylist in (select day_id from his_bi.dim_date_info where day_id >= o_start_date and day_id <= o_end_date order by day_id)
    loop 
    
    --raise notice '4 c_daylist.day_id is: %', c_daylist.day_id;
    
    delete from his_bi.dw_outp_fsjz where jzsj = c_daylist.day_id;
    
  insert into his_bi.dw_outp_fsjz
        select to_char(opv.visit_begin_date,'yyyymmdd') jzsj,
              opv.outp_visit_id,
              opv.patient_id ,
              opv.visit_id , 
              opv.admission_doctor,
              opv.dept_code,
              trim(left(substring(cast(opv.visit_begin_date as text) from 11 for 11),6)) as qj,
              opv.visit_begin_date,
              opv.sign_in_date,
              t2.type,
              max(k.enter_date),
              max(round(abs(date_part('epoch', k.enter_date - opv.visit_begin_date))::NUMERIC / 60,4)) as jz_jf,--就诊-缴费时间
              max(round(abs(date_part('epoch', k.enter_date - opv.sign_in_date))::NUMERIC / 60,4)) as qd_jf,--签到-缴费时间 
              max(round(abs(date_part('epoch', opv.visit_begin_date - opv.sign_in_date))::NUMERIC / 60,4)) as qd_jz,--签到到就诊时间
              now() as insert_time
          from his_bi.pts_outp_patient_visit opv
          left join  his_bi.bms_bill_item k on k.patient_id = opv.patient_id and k.visit_id = opv.visit_id and k.in_out_flag = 'O'  and k.ITEM_CLASS !='Z'
          left join his_bi.dim_hour_min_secound t2 on (trim(left(substring(cast(opv.visit_begin_date as text) from 11 for 11),6))
                  = t2.time)
        where opv.registry_flag = '1'
          and opv.visit_begin_date >= to_date(c_daylist.day_id,'yyyyMMdd')
          and opv.visit_begin_date <  to_date(c_daylist.day_id,'yyyyMMdd')+1
          and opv.outp_type_code not in ('2','11') --排除便民，急诊
          and opv.sign_in_date is not null 
        group by
          to_char(opv.visit_begin_date,'yyyymmdd'),
          opv.outp_visit_id,
          opv.patient_id ,
          opv.visit_id , 
          opv.admission_doctor,
          opv.dept_code,
          trim(left(substring(cast(opv.visit_begin_date as text) from 11 for 11),6)),
          opv.visit_begin_date,
          opv.sign_in_date,
          t2.type;
     end loop;
   RETURN 'SUCCESS';  
END;
$$;

alter function fun_dw_outp_fsjz(varchar, varchar)
  owner to postgres;

