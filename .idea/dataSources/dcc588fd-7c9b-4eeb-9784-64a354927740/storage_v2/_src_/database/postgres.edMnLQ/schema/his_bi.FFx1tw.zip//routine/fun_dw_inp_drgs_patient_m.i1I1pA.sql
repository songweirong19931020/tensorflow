create function fun_dw_inp_drgs_patient_m(v_start_month character varying, v_end_month character varying)
  returns character varying
language plpgsql
as $$
/***
函数名称：重疾信息表
    作用：重疾信息表
  开发人：leslie 2020年6月17日 
				  modify by liuf 20200619 补充了单病种病种和剖宫产术种
命名规范：FUN_模型层级(DWD或者DW)_KPI编码_日期类型D或者M，D表示按天统计，M表示按月统计
 KPI编码：D00236根据原子指标编码规划来的
    入参：v_start_date，v_end_date  格式均为yyyymmdd，可以一次运行多天的数据
***/
DECLARE
  c_monthlist   record;
  o_start_month varchar;
  o_end_month   varchar;
  i_start_month varchar;
  i_end_month   varchar;
  i_count       int4;
	tmp_file 			varchar;  --COPY方案临时文件名：该文件将被保存在所连接的服务器的文件目录。
BEGIN
	/*
	  COPY方案临时文件名。
		注意：
		1. 该文件将被保存在所连接的服务器的文件目录中，每一个函数必须使用自定义能够与其他函数区分的文件名
		2. 方便维护，历史文件都保存到'/home/postgres/'目录中。
		TODO : 后续规划统一临时文件目录，KETTLE调度完成之后，需要删除对应的临时文件（*需要想办法在每台服务器上统一创建临时目录）
	*/
	
  /*如果指标没有历史指标数据，甘肃默认以202001开始计算，结束月份以当前月份往前推1个月*/
  select count(1),to_char((date_trunc('month', now()) + interval '-1 month'),'yyyymm')
	       into i_count,i_end_month
    from his_bi.dw_inp_drgs_patient_m;
   
  if(i_count = 0)
    then 
      i_start_month := '202001';
      --raise notice '0 i_start_month is: %', i_start_month;
  else if(i_count > 0)
    then
      i_start_month := i_end_month;
      --raise notice '1 i_start_month is: %', i_start_month;
  end if;
  end if;
    
  if(length(trim(v_start_month)) = 0 and length(trim(v_end_month)) = 0)
  /*kettle 调用时，如果不设置参数，默认传入 空字符串，那么默认取当前月份前1个月为截止月份 */
    then 
      o_start_month := i_start_month;
      o_end_month := i_end_month;
      --raise notice '2 o_start_month is: %', o_start_month;
      --raise notice '2 o_end_month is: %', o_end_month;
  else if (length(trim(v_start_month)) <> 0 and length(trim(v_end_month)) <> 0)
  /*PG function 如果参入任何参数，那么以实际入参为准*/
    then 
      o_start_month := v_start_month;
      o_end_month := v_end_month;
      --raise notice '3 o_start_month is: %', o_start_month;
      --raise notice '3 o_end_month is: %', o_end_month;
  end if;
  end if;
	  for c_monthlist in (select distinct month_id from his_bi.dim_date_info where month_id >= o_start_month and month_id <= o_end_month order by month_id)
    loop
    --raise notice '4 c_daylist.day_id is: %', c_daylist.day_id;
    
    delete from his_bi.dw_inp_drgs_patient_m where month_id = c_monthlist.month_id;
    
  insert into his_bi.dw_inp_drgs_patient_m
select distinct 
c_monthlist.month_id as month_id,
b.brxh,
a.patient_id,
a.pai_visit_id,
a.visit_id,
b.brxm,
cast(split_part(cast(age(CURRENT_DATE,b.csrq) as text),' ',1) as numeric) as pati_age,
split_part(cast(age(CURRENT_DATE,b.csrq) as text),' ',2) as age_flag,
cast(b.xb as numeric) as sex,
t1.hospital_area,
t1.admission_dept, ---入院科室编码
t6.name as ryks,
t1.discharge_dept, --- 出院科室编码
t7.name as cyks,
b.ryrq,  --入院时间
b.cyrq, ---出院时间
t8.diagdiseasecode,
t8.diagdiseasename,
b.zyts,---住院天数
a.key, ---重点疾病名称
t2.value as return_drgs_1,-----重点疾病当天重返标志(预留)
t3.value as return_drgs_2to15,--重点疾病2-15日内重返标志(预留)
t4.value as return_drgs_16to31,---重点疾病16-31日内重返标志(预留)
t5.value as return_drgs_1to31,----1-31天重返（国家标准）
t10.value as return_z_drgs_7to15,
t11.value as return_z_drgs_16to31,
case when t12.key = 'D00207' then 1 when t12.key = 'D00208' then 2 when t12.key = 'D00209' then 3 end as is_exzl,
cast(b.zgqk as numeric) as zgqk,
b.lyfs, ---离院方式，1：医嘱离院，2：医嘱转院，3：医嘱转社区卫生服务机构，4：非医嘱离院，5：死亡，9：其他
t9.total_fees,--总费用
t9.pham_fees, --药品费用
t9.material_fees, --材料费用
t9.cur_fees, --治疗费用
t9.oper_fees, --手术费用
t9.other_fees, --其他费用
t9.western_fees, --西药费用
t9.herb_fees, --草药费用
t9.anti_pham_fees, --抗菌药物费用
now() as insert_time, --插入时间
t1.team_id, --诊疗组ID
tm.team_name, --诊疗组名称
t1.doctor_chief as doctor_chief, --主任医生编码(部分直接存储为姓名)
us1.people_name as doctor_chief_name, --主任医生编码
t1.doctor_attending as doctor_attending, --主治医生编码(部分直接存储为姓名)
us2.people_name as doctor_attending_name, --主治医生编码
b.md5 --md5码，访问患者病历时候必传参数
from his_bi.dwd_inp_medical_d a
left join his_bi.pts_pai_visit t1 on (a.pai_visit_id = t1.pai_visit_id)
left join his_bi.ods_patient_medical_record b on (a.patient_id =b.bah and a.visit_id = b.zycs)
left join his_bi.dwd_inp_medical_d t2 on (a.pai_visit_id = t2.pai_visit_id and t2.key = 'D00100')
left join his_bi.dwd_inp_medical_d t3 on (a.pai_visit_id = t3.pai_visit_id and t3.key = 'D00101')
left join his_bi.dwd_inp_medical_d t4 on (a.pai_visit_id = t4.pai_visit_id and t4.key = 'D00102')
left join his_bi.dwd_inp_medical_d t5 on (a.pai_visit_id = t5.pai_visit_id and t5.key = 'D00103')
left join his_bi.dwd_inp_medical_d t10 on (a.pai_visit_id = t10.pai_visit_id and t10.key = 'D00215')
left join his_bi.dwd_inp_medical_d t11 on (a.pai_visit_id = t11.pai_visit_id and t11.key = 'D00216')
left join his_bi.dwd_inp_medical_d t12 on (a.pai_visit_id = t12.pai_visit_id and t12.key in ('D00207','D00208','D00209'))
left join his_bi.bds_bds_organization t6 on (t1.admission_dept = t6.code )
left join his_bi.bds_bds_organization t7 on (t1.discharge_dept = t7.code )
left join his_bi.ods_patient_diag_info t8 on (a.patient_id = t8.patient_id and a.visit_id = t8.visit_id and t8.main_diag='1')
left join his_bi.pts_pts_basic_org_medi_team tm on t1.team_id = tm.team_id
left join
(
select 
td.pai_visit_id,
sum(case when td.key in ('D05000') then td.value end) as total_fees,---总费用
sum(case when td.key in ('D05003') then td.value end) as pham_fees, --药品费用
sum(case when td.key in ('D05002') then td.value end) as material_fees,--材料费用
sum(case when td.key in ('D05006') then td.value end) as cur_fees,--治疗费用
sum(case when td.key in ('D05019') then td.value end) as oper_fees,--手术费用
sum(case when td.key in ('D05022') then td.value end) as other_fees,--其他费用
sum(case when td.key in ('D05008') then td.value end) as western_fees,--西药费用
sum(case when td.key in ('D05010') then td.value end) as herb_fees,--草药费用
sum(case when td.key in ('D05011') then td.value end) as anti_pham_fees--抗菌药物费用
from his_bi.dwd_inp_income_d td
inner join his_bi.dim_date_info d1 on td.st_date = d1.day_id and d1.month_id = c_monthlist.month_id
where td.key in ('D05000','D05003','D05002','D05006','D05019','D05010','D05008','D05022','D05011')
group by td.pai_visit_id
)t9 on a.pai_visit_id = t9.pai_visit_id
left join his_bi.uum_uum_user us1 on t1.doctor_chief = us1.user_name
left join his_bi.uum_uum_user us2 on t1.doctor_attending = us2.user_name
where a.key in ('D00104','D00105','D00106','D00107','D00108','D00109','D00110','D00111','D00112','D00113','D00114','D00115','D00116','D00117','D00118','D00119','D00120','D00121','D00122','D00123','D00124','D00125','D00126','D00127','D00128','D00208','D00210','D00224','D00225','D00173','D00183')
and t1.discharge_dept_date >= to_date(c_monthlist.month_id,'yyyymm')
and t1.discharge_dept_date <  to_date(c_monthlist.month_id,'yyyymm') + interval '1 month';
   end loop;
   RETURN 'SUCCESS';  
END;
$$;

alter function fun_dw_inp_drgs_patient_m(varchar, varchar)
  owner to postgres;

