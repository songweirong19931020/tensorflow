create function has_matched_icd9_rule(biz_type character varying, icd9_code character varying, operation_alias character varying)
  returns boolean
language plpgsql
as $$
DECLARE
	matched_rule_count   int;
	BEGIN
	-- Routine body goes here...
	
	select count(1) into matched_rule_count from his_bi.dim_icd_biz_rules r where r.type_code=biz_type and icd_9=icd9_code and operation_name_alias=operation_alias;
	IF(matched_rule_count>0)
		then
		RETURN TRUE;
	END if;

	RETURN FALSE;
END
$$;

alter function has_matched_icd9_rule(varchar, varchar, varchar)
  owner to postgres;

