create function fun_dw_inp_patient_info_m(v_start_month character varying, v_end_month character varying)
  returns character varying
language plpgsql
as $$
/***
函数名称：住院患者信息表
    作用：住院患者信息表
  开发人：wy 2020年6月15日
命名规范：FUN_模型层级(DWD或者DW)_KPI编码_日期类型D或者M，D表示按天统计，M表示按月统计
 KPI编码：D00236根据原子指标编码规划来的
    入参：v_start_date，v_end_date  格式均为yyyymmdd，可以一次运行多天的数据
***/
DECLARE
  c_monthlist   record;
  o_start_month varchar;
  o_end_month   varchar;
  i_start_month varchar;
  i_end_month   varchar;
  i_count       int4;
	tmp_file 			varchar;  --COPY方案临时文件名：该文件将被保存在所连接的服务器的文件目录。
BEGIN
	/*
	  COPY方案临时文件名。
		注意：
		1. 该文件将被保存在所连接的服务器的文件目录中，每一个函数必须使用自定义能够与其他函数区分的文件名
		2. 方便维护，历史文件都保存到'/home/postgres/'目录中。
		TODO : 后续规划统一临时文件目录，KETTLE调度完成之后，需要删除对应的临时文件（*需要想办法在每台服务器上统一创建临时目录）
	*/
	
  /*如果指标没有历史指标数据，甘肃默认以202001开始计算，结束月份以当前月份往前推1个月*/
  select count(1),to_char((date_trunc('month', now()) + interval '-1 month'),'yyyymm')
	       into i_count,i_end_month
    from his_bi.dw_inp_patient_info_m;
   
  if(i_count = 0)
    then 
      i_start_month := '202001';
      --raise notice '0 i_start_month is: %', i_start_month;
  else if(i_count > 0)
    then
      i_start_month := i_end_month;
      --raise notice '1 i_start_month is: %', i_start_month;
  end if;
  end if;
    
  if(length(trim(v_start_month)) = 0 and length(trim(v_end_month)) = 0)
  /*kettle 调用时，如果不设置参数，默认传入 空字符串，那么默认取当前月份前1个月为截止月份 */
    then 
      o_start_month := i_start_month;
      o_end_month := i_end_month;
      --raise notice '2 o_start_month is: %', o_start_month;
      --raise notice '2 o_end_month is: %', o_end_month;
  else if (length(trim(v_start_month)) <> 0 and length(trim(v_end_month)) <> 0)
  /*PG function 如果参入任何参数，那么以实际入参为准*/
    then 
      o_start_month := v_start_month;
      o_end_month := v_end_month;
      --raise notice '3 o_start_month is: %', o_start_month;
      --raise notice '3 o_end_month is: %', o_end_month;
  end if;
  end if;
	  for c_monthlist in (select distinct month_id from his_bi.dim_date_info where month_id >= o_start_month and month_id <= o_end_month order by month_id)
    loop
    --raise notice '4 c_daylist.day_id is: %', c_daylist.day_id;
    
    delete from his_bi.dw_inp_patient_info_m where month_id = c_monthlist.month_id;
    
  insert into his_bi.dw_inp_patient_info_m
select 
c_monthlist.month_id as mon_id,
a.brxh,
t1.patient_id,
t1.pai_visit_id,
t1.visit_id,
a.brxm,
cast(split_part(cast(age(CURRENT_DATE,a.csrq) as text),' ',1) as numeric) as pati_age,
split_part(cast(age(CURRENT_DATE,a.csrq) as text),' ',2) as age_flag,
cast(a.xb as NUMERIC) as sex,
t1.hospital_area,
t1.team_id,  --诊疗组ID
tm.team_name,  --诊疗组名称
t1.doctor_chief as doctor_chief, --主任医生编码(部分直接存储为姓名)
us1.people_name as doctor_chief_name, --主任医生编码
t1.doctor_attending as doctor_attending, --主治医生编码(部分直接存储为姓名)
us2.people_name as doctor_attending_name, --主治医生编码
t1.admission_dept, ---入院科室编码
t6.name,
t1.discharge_dept, --- 出院科室编码
t7.name,
a.ryrq,  --入院时间
a.cyrq, ---出院时间
t8.diagdiseasecode,
t8.diagdiseasename,
a.zyts,---住院天数
md.is_zqss,  --是否择期手术
md.is_xzhz,  --是否下转患者
md.is_sshz,  --是否手术患者(0 否 1是)
md.is_ylqk_gr,  --是否I类切口感染(0 否 1是)
md.is_ylqk_sh,  --是否I类切口手术(0 否 1是)
md.is_wzhz,  --是否危重患者(0 否 1是)
md.is_wxzl,
md.is_wswsj,  --是否微生物检验样本送检
mq.is_use_sykjyw,  --是否使用抗菌药物
mq.is_use_fxzjkjyw,  --是否使用非限制级抗菌药物
mq.is_use_xzjkjyw,  --是否使用限制级抗菌药物
mq.is_use_tsjkjyw,  --是否使用特殊级抗菌药物
mq.kjyw_ddd_sum,  --抗菌药物累计DDD数
mq.fxzj_kjyw_ddd_sum,  --非限制级抗菌药物累计DDD数
mq.xzj_kjyw_ddd_sum,  --限制级抗菌药物累计DDD数
mq.tsj_kjyw_ddd_sum,  --特殊级抗菌药物DDD数使用强度
md.wc_num,
md.sjss_num,
md.qj_num,
md.hxnj_num,
md.xhnj_num,
case when md.rjss_num >0 then 1 end as rjss_num,
md.ssbf_num,
a.lyfs,
mq.is_die,
case when a.lyfs='4' then 1 else 0 end  as is_zdly,
t1.pathway_status as lcljglxh,
a.lcybl,
a.fsybl,
a.sqysh,
a.md5,
a.zfy as total_fees
from his_bi.ods_patient_medical_record a
left join his_bi.pts_pai_visit t1 on (a.bah = t1.patient_id and a.zycs = t1.visit_id)
left join his_bi.bds_bds_organization t6 on (t1.admission_dept = t6.code )
left join his_bi.bds_bds_organization t7 on (t1.discharge_dept = t7.code )
left join his_bi.ods_patient_diag_info t8 on (a.bah = t8.patient_id and a.zycs = t8.visit_id and t8.main_diag='1')
left join 
(
    select
    md.pai_visit_id,
    max(case when md.key = 'D00044' then md.value end) as ssbf_num,
    max(case when md.key = 'D00045' then md.value end) as is_zqss,  --是否择期手术
    max(case when md.key = 'D00046' then md.value end) as is_xzhz,  --是否下转患者
    --max(case when md.key = 'D00205' then md.value end) as is_rjss,  --是否日间手术患者
    max(case when md.key = 'D00048' then md.value end) as is_sshz,  --是否手术患者(0 否 1是)
    max(case when md.key = 'D00049' then md.value end) as is_wchz,  --是否微创手术患者(0 否 1是)
    max(case when md.key = 'D00050' then md.value end) as is_sjss,  --是否四级手术患者(0 否 1是)
    max(case when md.key = 'D00051' then md.value end) as is_ylqk_gr,  --是否I类切口感染(0 否 1是)
    max(case when md.key = 'D00052' then md.value end) as is_ylqk_sh,  --是否I类切口手术(0 否 1是)
    max(case when md.key = 'D00053' then md.value end) as is_wzhz,  --是否危重患者(0 否 1是)
    max(case when md.key = 'D00092' then md.value end) as is_wswsj,  --是否微生物检验样本送检
    max(case when md.key = 'D00207' then md.value end) as is_wxzl,
    sum(case when md.key = 'D00242' then md.value end) as wc_num,
    sum(case when md.key = 'D00243' then md.value end) as sjss_num,
    sum(case when md.key = 'D00244' then md.value end) as qj_num,
    sum(case when md.key = 'D00245' then md.value end) as hxnj_num,
    sum(case when md.key = 'D00246' then md.value end) as xhnj_num,
    sum(case when md.key = 'D00205' then md.value end) as rjss_num
    from his_bi.dwd_inp_medical_d md
    inner join his_bi.dim_date_info d1 on md.st_date = d1.day_id and d1.month_id = c_monthlist.month_id
    where md.key in ('D00044','D00045','D00046','D00048','D00050','D00051',
        'D00049','D00050','D00052','D00053','D00092','D00207','D00242','D00243','D00244','D00245','D00246','D00205')
    group by md.pai_visit_id
)md on t1.pai_visit_id = md.pai_visit_id
left join 
(
    select
    mq.pai_visit_id,
    sum(case when mq.key = 'D00093' then mq.value end) as kjyw_ddd_sum,  --抗菌药物累计DDD数
    sum(case when mq.key = 'D00094' then mq.value end) as fxzj_kjyw_ddd_sum,  --非限制级抗菌药物累计DDD数
    sum(case when mq.key = 'D00095' then mq.value end) as xzj_kjyw_ddd_sum,  --限制级抗菌药物累计DDD数
    sum(case when mq.key = 'D00096' then mq.value end) as tsj_kjyw_ddd_sum,  --特殊级抗菌药物DDD数使用强度
    max(case when mq.key = 'D00155' then  mq.value end) as is_die,
		max(case when mq.key = 'D00088' then mq.value end) as is_use_sykjyw,  --是否使用抗菌药物
    max(case when mq.key = 'D00089' then mq.value end) as is_use_fxzjkjyw,  --是否使用非限制级抗菌药物
    max(case when mq.key = 'D00090' then mq.value end) as is_use_xzjkjyw,  --是否使用限制级抗菌药物
    max(case when mq.key = 'D00091' then mq.value end) as is_use_tsjkjyw  --是否使用特殊级抗菌药物
    from his_bi.dwd_inp_quantity_d mq
    inner join his_bi.dim_date_info d1 on mq.st_date = d1.day_id and d1.month_id = c_monthlist.month_id
    where mq.key in ('D00093','D00094','D00095','D00096','D00155','D00088','D00089','D00090','D00091')
    group by mq.pai_visit_id
)mq on t1.pai_visit_id = mq.pai_visit_id
left join his_bi.pts_pts_basic_org_medi_team tm on t1.team_id = tm.team_id
left join his_bi.uum_uum_user us1 on t1.doctor_chief = us1.user_name
left join his_bi.uum_uum_user us2 on t1.doctor_attending = us2.user_name
where 1=1
and a.cyrq >= to_date(c_monthlist.month_id,'yyyymm')
and a.cyrq <  to_date(c_monthlist.month_id,'yyyymm') + interval '1 month'; 
   end loop;
   RETURN 'SUCCESS';  
END;
$$;

alter function fun_dw_inp_patient_info_m(varchar, varchar)
  owner to postgres;

