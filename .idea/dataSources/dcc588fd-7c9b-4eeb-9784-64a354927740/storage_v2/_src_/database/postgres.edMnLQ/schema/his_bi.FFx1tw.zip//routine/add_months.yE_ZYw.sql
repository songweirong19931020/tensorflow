create function add_months(timestamp without time zone, integer)
  returns timestamp without time zone
strict
language plpgsql
as $$
declare
  i interval := ($2 || 'month');
  d1 date := date(to_timestamp($1::text,'yyyy-mm') + interval '1 month' - interval '1 day');
  d2 date := date($1);
  res timestamp;
begin
  select case when d1=d2 then ((to_char($1+i+interval '1 month', 'yyyy-mm')||'-01')::date - 1) + $1::time else $1+i end into res;
  return res;
end;

$$;

alter function add_months(timestamp, integer)
  owner to postgres;

