create view view_dw_inp_patient_info_m as
  SELECT t1.month_id              AS "月份",
         t1.brxh                  AS "病案唯一标识",
         t1.patient_id            AS "患者编码",
         t1.pai_visit_id          AS "住院唯一标识",
         t1.visit_id              AS "就诊次数",
         t1.patient_name          AS "患者姓名",
         t1.age                   AS "年龄",
         t1.age_flag              AS "年龄标识",
         t1.sex                   AS "性别",
         t1.area_code             AS "院区",
         t1.team_id               AS "诊疗组编码",
         t1.team_name             AS "诊疗组名称",
         t1.doctor_chief          AS "主任医生编码",
         t1.doctor_chief_name     AS "主任医生名称",
         t1.doctor_attending      AS "主治医生编码",
         t1.doctor_attending_name AS "主治医生名称",
         t1.in_dept_code          AS "入院科室编码",
         t1.in_dept_name          AS "入院科室名称",
         t1.out_dept_code         AS "出院科室编码",
         t1.out_dept_name         AS "出院科室名称",
         t1.in_time               AS "入院时间",
         t1.out_time              AS "出院时间",
         t1.out_diag_code         AS "出院主诊断编码",
         t1.out_diag_name         AS "出院主诊断名称",
         icd10.fdesc              AS "主诊断顺位",
         t1.in_days               AS "住院天数",
         t1.is_zqss               AS "是否择期手术",
         t1.is_xzhz               AS "是否下转患者",
         t1.is_sshz               AS "是否手术患者",
         t1.is_ylqk_gr            AS "是否i类切口感染",
         t1.is_ylqk_sh            AS "是否i类切口手术",
         t1.is_wzhz               AS "是否危重患者",
         t1.is_wxzl               AS "恶性肿瘤名称代码",
         t1.is_wswsj              AS "是否微生物检验样本送检",
         t1.is_use_sykjyw         AS "是否使用抗菌药物",
         t1.is_use_fxzjkjyw       AS "是否使用非限制级抗菌药物",
         t1.is_use_xzjkjyw        AS "是否使用限制级抗菌药物",
         t1.is_use_tsjkjyw        AS "是否使用特殊级抗菌药物",
         t1.kjyw_ddd_sum          AS "抗菌药物累计ddd数",
         t1.fxzj_kjyw_ddd_sum     AS "非限制级抗菌药物累计ddd数",
         t1.xzj_kjyw_ddd_sum      AS "限制级抗菌药物累计ddd数",
         t1.tsj_kjyw_ddd_sum      AS "特殊级抗菌药物ddd数使用强度",
         t1.wc_num                AS "微创手术例数",
         t1.sjss_num              AS "四级手术例数",
         t1.qj_num                AS "腔镜手术例数",
         t1.hxnj_num              AS "呼吸内镜手术例数",
         t1.xhnj_num              AS "消化内镜手术例数",
         t1.rjss_num              AS "日间手术例数",
         t1.ssbf_num              AS "手术并发症例数",
         t1.lyfs                  AS "离院方式",
         t1.is_die                AS "是否死亡",
         t1.is_zdly               AS "自动离院标志",
         t1.lcljglxh              AS "临床路径完成状态",
         t1.lcybl                 AS "临床与病理",
         t1.fsybl                 AS "放射与病理",
         t1.sqysh                 AS "术前与术后",
         t1.md5                   AS "md5码",
         t2.root_name             AS "出院科室保健部名称",
         t3.root_name             AS "入院科室保健部名称",
         ss.one_level             AS "一级手术次数",
         ss.two_level             AS "二级手术次数",
         ss.three_level           AS "三级手术次数",
         ss.four_level            AS "四级手术次数_病案",
         ss2.ss_total             AS "总手术次数",
         t1.total_fees            AS "总费用"
  FROM (((((his_bi.dw_inp_patient_info_m t1
      LEFT JOIN his_bi.v_system_organization t2 ON (((t1.out_dept_code) :: text = (t2.code) :: text)))
      LEFT JOIN his_bi.bds_bds_icd10 icd10 ON (((icd10.ficd10) :: text =
                                                (substr((t1.out_diag_code) :: text, 1, 5) || '00' :: text))))
      LEFT JOIN his_bi.v_system_organization t3 ON (((t1.in_dept_code) :: text = (t3.code) :: text)))
      LEFT JOIN (SELECT ods_patient_opertion_info.patient_id,
                        ods_patient_opertion_info.visit_id,
                        sum(
                          CASE
                            WHEN ((ods_patient_opertion_info.surgerygrade) :: text = '1' :: text) THEN 1
                            ELSE 0
                              END) AS one_level,
                        sum(
                          CASE
                            WHEN ((ods_patient_opertion_info.surgerygrade) :: text = '2' :: text) THEN 1
                            ELSE 0
                              END) AS two_level,
                        sum(
                          CASE
                            WHEN ((ods_patient_opertion_info.surgerygrade) :: text = '3' :: text) THEN 1
                            ELSE 0
                              END) AS three_level,
                        sum(
                          CASE
                            WHEN ((ods_patient_opertion_info.surgerygrade) :: text = '4' :: text) THEN 1
                            ELSE 0
                              END) AS four_level
                 FROM his_bi.ods_patient_opertion_info
                 WHERE ((ods_patient_opertion_info.surgerygrade IS NOT NULL) AND
                        ((ods_patient_opertion_info.surgerytype) :: text = ANY
                         (ARRAY[('1'::character varying)::text, ('4'::character varying)::text])))
                 GROUP BY ods_patient_opertion_info.patient_id, ods_patient_opertion_info.visit_id) ss ON ((
    ((t1.patient_id) :: text = (ss.patient_id) :: text) AND (t1.visit_id = (ss.visit_id) :: numeric))))
      LEFT JOIN (SELECT ods_patient_opertion_info.patient_id, ods_patient_opertion_info.visit_id, count(1) AS ss_total
                 FROM his_bi.ods_patient_opertion_info
                 WHERE ((ods_patient_opertion_info.surgerygrade IS NOT NULL) AND
                        ((ods_patient_opertion_info.surgerytype) :: text = ANY
                         (ARRAY[('1'::character varying)::text, ('4'::character varying)::text])))
                 GROUP BY ods_patient_opertion_info.patient_id, ods_patient_opertion_info.visit_id) ss2 ON ((
    ((t1.patient_id) :: text = (ss2.patient_id) :: text) AND (t1.visit_id = (ss2.visit_id) :: numeric))));

alter table view_dw_inp_patient_info_m
  owner to postgres;

