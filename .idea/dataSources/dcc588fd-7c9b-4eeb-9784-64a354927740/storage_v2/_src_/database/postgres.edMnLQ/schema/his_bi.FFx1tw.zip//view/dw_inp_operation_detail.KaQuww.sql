create view dw_inp_operation_detail as
  SELECT op_1.brxh                AS "病人序号",
         op_1.patient_id          AS "病人id",
         op_1.visit_id            AS "就诊次数",
         op_1.mrn                 AS "病案号",
         op_1.surgerycode         AS "手术编码",
         op_1.surgeryname         AS "手术名称",
         op_1.surgerygrade        AS "手术级别",
         op_1.cutgrade            AS "切口等级",
         op_1.healgrade           AS "切口愈合等级",
         op_1.anethesiatype       AS "麻醉方式",
         op_1.surgerydate         AS "手术日期",
         op_1.surgerry_operator   AS "手术医生",
         op_1.ane_operator        AS "麻醉医师",
         op_1.employee_assistant1 AS "一助",
         op_1.employee_assistant2 AS "二助",
         op_1.insert_time         AS "插入时间",
         op_1.surgerytype         AS "手术类型",
         orgks.name               AS "出院科室",
         orgks.root_name          AS "保健部名称",
         org.name                 AS "病区",
         tm.team_name             AS "诊疗小组",
         c."是否死亡",
         pai.discharge_dept_date  AS "出院时间"
  FROM (((((his_bi.ods_patient_opertion_info op_1
      LEFT JOIN his_bi.pts_pai_visit pai ON ((((pai.patient_id) :: text = (op_1.patient_id) :: text) AND
                                              (pai.visit_id = op_1.visit_id))))
      LEFT JOIN his_bi.pts_pts_basic_org_medi_team tm ON ((tm.team_id = pai.team_id)))
      LEFT JOIN his_bi.v_system_organization org ON (((pai.admission_ward) :: text = (org.code) :: text)))
      LEFT JOIN his_bi.v_system_organization orgks ON (((pai.discharge_dept) :: text = (orgks.code) :: text)))
      LEFT JOIN (SELECT d_1.value AS "是否死亡", d_1.patient_id, d_1.visit_id
                 FROM his_bi.dwd_inp_medical_d d_1
                 WHERE ((d_1.key) :: text = 'D00155' :: text)) c ON ((
    ((c.patient_id) :: text = (op_1.patient_id) :: text) AND (c.visit_id = op_1.visit_id))))
  WHERE (op_1.surgerydate >= to_date('20200101' :: text, 'yyyymmdd' :: text));

alter table dw_inp_operation_detail
  owner to postgres;

