create function fun_dw_inp_patient_amount_m(v_start_month character varying, v_end_month character varying)
  returns character varying
language plpgsql
as $$
/***
函数名称：住院患者费用相关指标月汇总
    作用：汇总统计某月住院患者费用相关指标
  开发人：wy 2020-06-11
命名规范：FUN_模型层级(DW)_业务解释_日期类型M，M表示按月统计
业务解释：根据保存数据的DW表规划来的
    入参：v_start_month，v_end_month  格式均为yyyymm，可以一次运行多天的数据
		
		说明：由于采用INSERT INTO SELECT方式进行数据汇总后，再将结果插入到目标表的方式，
				  性能较低，可能会导致函数执行超过PG配置项statment_timeout所配置的超时时长，
				  从而导致函数执行被PG终结，采用PG COPY特性能大幅度提升该业务场景性能，操作步骤如下：
					1. 执行COPY TO命令将SELECT结果保存csv临时文件
					2. 执行COPY FROM命令将临时文件数据加载到目标表
					注意：该方案适用于数据量大且性能低下的统计，性能能满足要求的，为了方便开发、维护，可继续使用INSERT INTO SELECT方案
***/
DECLARE
  c_monthlist   record;
  o_start_month varchar;
  o_end_month   varchar;
  i_start_month varchar;
  i_end_month   varchar;
  i_count       int4;
	tmp_file 			varchar;  --COPY方案临时文件名：该文件将被保存在所连接的服务器的文件目录。
BEGIN
	/*
	  COPY方案临时文件名。
		注意：
		1. 该文件将被保存在所连接的服务器的文件目录中，每一个函数必须使用自定义能够与其他函数区分的文件名
		2. 方便维护，历史文件都保存到'/home/postgres/'目录中。
		TODO : 后续规划统一临时文件目录，KETTLE调度完成之后，需要删除对应的临时文件（*需要想办法在每台服务器上统一创建临时目录）
	*/
	tmp_file := '/home/postgres/fun_dw_inp_patient_amount_m.csv';
	
  /*如果指标没有历史指标数据，甘肃默认以202001开始计算，结束月份以当前月份往前推1个月*/
  select count(1),to_char((date_trunc('month', now()) + interval '-1 month'),'yyyymm')
	       into i_count,i_end_month
    from his_bi.dw_inp_patient_amount_m;
   
  if(i_count = 0)
    then 
      i_start_month := '202001';
      --raise notice '0 i_start_month is: %', i_start_month;
  else if(i_count > 0)
    then
      i_start_month := i_end_month;
      --raise notice '1 i_start_month is: %', i_start_month;
  end if;
  end if;
    
  if(length(trim(v_start_month)) = 0 and length(trim(v_end_month)) = 0)
  /*kettle 调用时，如果不设置参数，默认传入 空字符串，那么默认取当前月份前1个月为截止月份 */
    then 
      o_start_month := i_start_month;
      o_end_month := i_end_month;
      --raise notice '2 o_start_month is: %', o_start_month;
      --raise notice '2 o_end_month is: %', o_end_month;
  else if (length(trim(v_start_month)) <> 0 and length(trim(v_end_month)) <> 0)
  /*PG function 如果参入任何参数，那么以实际入参为准*/
    then 
      o_start_month := v_start_month;
      o_end_month := v_end_month;
      --raise notice '3 o_start_month is: %', o_start_month;
      --raise notice '3 o_end_month is: %', o_end_month;
  end if;
  end if;
  
  for c_monthlist in (select distinct month_id from his_bi.dim_date_info where month_id >= o_start_month and month_id <= o_end_month order by month_id)
  loop 
  
   --raise notice '4 c_monthlist.month_id is: %', c_monthlist.month_id;
   
    delete from his_bi.dw_inp_patient_amount_m where month_id = c_monthlist.month_id;
		 
	  -- 执行COPY命令，保存统计结果到临时文件（tmp_file）
		execute '
    copy (
		
				select 
					'''||c_monthlist.month_id||''' as month_id,
					hd1.patient_id,
					hd1.visit_id,
					hd1.pai_visit_id,
					COALESCE(sum(hd1.value),0) as total_fees,

					COALESCE(sum(ha1.value),0) as service_fess,
					COALESCE(sum(ha2.value),0) as anti_pham_fees,
					COALESCE(sum(ha3.value),0) as support_fess,
					COALESCE(sum(ha4.value),0) as basic_fess,
					COALESCE(sum(ha5.value),0) as key_point_fess,
					COALESCE(sum(ha6.value),0) as non_res_fess,
					COALESCE(sum(ha7.value),0) as res_fess,
					COALESCE(sum(ha8.value),0) as special_fess,
					COALESCE(sum(ha9.value),0) as pham_fees,

					COALESCE(sum(hd2.value),0) as material_fees,
					COALESCE(sum(hd4.value),0) as inspect_fees,
					COALESCE(sum(hd5.value),0) as check_fees,
					COALESCE(sum(hd6.value),0) as cur_fees,
					COALESCE(sum(hd7.value),0) as examination_fees,
					COALESCE(sum(hd8.value),0) as western_fees,
					COALESCE(sum(hd9.value),0) as chinese_patent_fees,
					COALESCE(sum(hd10.value),0) as herb_fees,
					COALESCE(sum(hd11.value),0) as nurse_fess,
					COALESCE(sum(hd12.value),0) as operation_fess,
					COALESCE(sum(hd13.value),0) as tdsp_fess,
					COALESCE(sum(hd14.value),0) as yntj_fess,
					COALESCE(sum(hd16.value),0) as bed_fess,
					COALESCE(sum(hd15.value),0) as other_fees
				from his_bi.dwd_inp_income_d hd1
				left join his_bi.dwd_inp_income_d hd2 on hd1.pai_visit_id = hd2.pai_visit_id and hd2.key = ''D05002'' and hd1.st_date = hd2.st_date
				left join his_bi.dwd_inp_income_d hd4 on hd1.pai_visit_id = hd4.pai_visit_id and hd4.key = ''D05004'' and hd1.st_date = hd4.st_date
				left join his_bi.dwd_inp_income_d hd5 on hd1.pai_visit_id = hd5.pai_visit_id and hd5.key = ''D05005'' and hd1.st_date = hd5.st_date
				left join his_bi.dwd_inp_income_d hd6 on hd1.pai_visit_id = hd6.pai_visit_id and hd6.key = ''D05006'' and hd1.st_date = hd6.st_date
				left join his_bi.dwd_inp_income_d hd7 on hd1.pai_visit_id = hd7.pai_visit_id and hd7.key = ''D05007'' and hd1.st_date = hd7.st_date
				left join his_bi.dwd_inp_income_d hd8 on hd1.pai_visit_id = hd8.pai_visit_id and hd8.key = ''D05008'' and hd1.st_date = hd8.st_date
				left join his_bi.dwd_inp_income_d hd9 on hd1.pai_visit_id = hd9.pai_visit_id and hd9.key = ''D05009'' and hd1.st_date = hd9.st_date
				left join his_bi.dwd_inp_income_d hd10 on hd1.pai_visit_id = hd10.pai_visit_id and hd10.key = ''D05010'' and hd1.st_date = hd10.st_date
				left join his_bi.dwd_inp_income_d hd11 on hd1.pai_visit_id = hd11.pai_visit_id and hd11.key = ''D05018'' and hd1.st_date = hd11.st_date
				left join his_bi.dwd_inp_income_d hd12 on hd1.pai_visit_id = hd12.pai_visit_id and hd12.key = ''D05019'' and hd1.st_date = hd12.st_date
				left join his_bi.dwd_inp_income_d hd13 on hd1.pai_visit_id = hd13.pai_visit_id and hd13.key = ''D05020'' and hd1.st_date = hd13.st_date
				left join his_bi.dwd_inp_income_d hd14 on hd1.pai_visit_id = hd14.pai_visit_id and hd14.key = ''D05021'' and hd1.st_date = hd14.st_date
				left join his_bi.dwd_inp_income_d hd15 on hd1.pai_visit_id = hd15.pai_visit_id and hd15.key = ''D05022'' and hd1.st_date = hd15.st_date
				left join his_bi.dwd_inp_income_d hd16 on hd1.pai_visit_id = hd16.pai_visit_id and hd16.key = ''D05023'' and hd1.st_date = hd16.st_date

				left join his_bi.dwd_inp_income_d ha1 on hd1.pai_visit_id = ha1.pai_visit_id and ha1.key = ''D05001'' and hd1.st_date = ha1.st_date
				left join his_bi.dwd_inp_income_d ha2 on hd1.pai_visit_id = ha2.pai_visit_id and ha2.key = ''D05011'' and hd1.st_date = ha2.st_date
				left join his_bi.dwd_inp_income_d ha3 on hd1.pai_visit_id = ha3.pai_visit_id and ha3.key = ''D05012'' and hd1.st_date = ha3.st_date
				left join his_bi.dwd_inp_income_d ha4 on hd1.pai_visit_id = ha4.pai_visit_id and ha4.key = ''D05013'' and hd1.st_date = ha4.st_date
				left join his_bi.dwd_inp_income_d ha5 on hd1.pai_visit_id = ha5.pai_visit_id and ha5.key = ''D05014'' and hd1.st_date = ha5.st_date
				left join his_bi.dwd_inp_income_d ha6 on hd1.pai_visit_id = ha6.pai_visit_id and ha6.key = ''D05015'' and hd1.st_date = ha6.st_date
				left join his_bi.dwd_inp_income_d ha7 on hd1.pai_visit_id = ha7.pai_visit_id and ha7.key = ''D05016'' and hd1.st_date = ha7.st_date
				left join his_bi.dwd_inp_income_d ha8 on hd1.pai_visit_id = ha8.pai_visit_id and ha8.key = ''D05017'' and hd1.st_date = ha8.st_date
				left join his_bi.dwd_inp_income_d ha9 on hd1.pai_visit_id = ha9.pai_visit_id and ha9.key = ''D05003'' and hd1.st_date = ha9.st_date

				left join his_bi.dim_date_info df on hd1.st_date = df.day_id and df.month_id = '''||c_monthlist.month_id||'''
				where hd1.key = ''D05000''
				  and hd1.value <> 0
					and df.month_id = '''||c_monthlist.month_id||'''
				group by
				hd1.patient_id,
				hd1.visit_id,
				hd1.pai_visit_id
				
	 )to '''||tmp_file||''' WITH CSV' ;
			
			---- 执行COP FROM Y命令，将统计结果从临时文件加载到目标表（tmp_file）
      execute 'COPY his_bi.dw_inp_patient_amount_m FROM '''||tmp_file||''' WITH CSV';
				 
   end loop;
   RETURN 'SUCCESS';  
END;
$$;

alter function fun_dw_inp_patient_amount_m(varchar, varchar)
  owner to postgres;

