create function fun_kpi_master_m_wy(v_start_month character varying, v_end_month character varying)
  returns character varying
language plpgsql
as $$
/***
函数名称：三级公立绩效指标函数
    作用：三级公立绩效指标函数
  开发人：wy 2020年6月24日
命名规范：FUN_模型层级(DWD或者DW)_KPI编码_日期类型D或者M，D表示按天统计，M表示按月统计
 KPI编码：根据原子指标编码规划来的
    入参：v_start_date，v_end_date  格式均为yyyymmdd，可以一次运行多天的数据
***/
DECLARE
  c_monthlist   record;
  o_start_month varchar;
  o_end_month   varchar;
  i_start_month varchar;
  i_end_month   varchar;
  i_count       int4;
	tmp_file 			varchar;  --COPY方案临时文件名：该文件将被保存在所连接的服务器的文件目录。
BEGIN
	/*
	  COPY方案临时文件名。
		注意：
		1. 该文件将被保存在所连接的服务器的文件目录中，每一个函数必须使用自定义能够与其他函数区分的文件名
		2. 方便维护，历史文件都保存到'/home/postgres/'目录中。
		TODO : 后续规划统一临时文件目录，KETTLE调度完成之后，需要删除对应的临时文件（*需要想办法在每台服务器上统一创建临时目录）
	*/
	
  /*如果指标没有历史指标数据，甘肃默认以202001开始计算，结束月份以当前月份往前推1个月*/
  select count(1),to_char((date_trunc('month', now()) + interval '-1 month'),'yyyymm')
	       into i_count,i_end_month
    from his_bi.kpi_master_m;
   
  if(i_count = 0)
    then 
      i_start_month := '202001';
      --raise notice '0 i_start_month is: %', i_start_month;
  else if(i_count > 0)
    then
      i_start_month := i_end_month;
      --raise notice '1 i_start_month is: %', i_start_month;
  end if;
  end if;
    
  if(length(trim(v_start_month)) = 0 and length(trim(v_end_month)) = 0)
  /*kettle 调用时，如果不设置参数，默认传入 空字符串，那么默认取当前月份前1个月为截止月份 */
    then 
      o_start_month := i_start_month;
      o_end_month := i_end_month;
      --raise notice '2 o_start_month is: %', o_start_month;
      --raise notice '2 o_end_month is: %', o_end_month;
  else if (length(trim(v_start_month)) <> 0 and length(trim(v_end_month)) <> 0)
  /*PG function 如果参入任何参数，那么以实际入参为准*/
    then 
      o_start_month := v_start_month;
      o_end_month := v_end_month;
      --raise notice '3 o_start_month is: %', o_start_month;
      --raise notice '3 o_end_month is: %', o_end_month;
  end if;
  end if;
	  for c_monthlist in (select distinct month_id from his_bi.dim_date_info where month_id >= o_start_month and month_id <= o_end_month order by month_id)
    loop
    --raise notice '4 c_daylist.day_id is: %', c_daylist.day_id;
	
  
--新生儿呼吸窘迫综合征（NRDS）病种例数
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX01007';      
	insert into his_bi.kpi_master_m	
		select
		dg.month_id,
		'JX01007' as kpi_code,
		count(distinct dg.pai_visit_id) as kpi_value,
		now() as update_time,
		count(distinct dg.pai_visit_id) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_drgs_patient_m dg
		where 1=1
		and dg.drgs_name = 'D00128'
		and dg.month_id = c_monthlist.month_id
		group by dg.month_id;
		
		
	--新生儿呼吸窘迫综合征（NRDS）平均住院日
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100701';      
	insert into his_bi.kpi_master_m	
		select
		dg.month_id,
		'JX0100701' as kpi_code,
		round(sum(dg.in_days)/count(distinct dg.pai_visit_id),2) as kpi_value,
		now() as update_time,
		round(sum(dg.in_days)/count(distinct dg.pai_visit_id),2) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_drgs_patient_m dg
		where 1=1
		and dg.drgs_name = 'D00128'
		and dg.month_id = c_monthlist.month_id
		group by dg.month_id;


	--新生儿呼吸窘迫综合征（NRDS）出院患者占用总床日数
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100702';      
	insert into his_bi.kpi_master_m	
		select
		dg.month_id,
		'JX0100702' as kpi_code,
		sum(dg.in_days) as kpi_value,
		now() as update_time,
		sum(dg.in_days) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_drgs_patient_m dg
		where 1=1
		and dg.drgs_name = 'D00128'
		and dg.month_id = c_monthlist.month_id
		group by dg.month_id;

	--新生儿呼吸窘迫综合征（NRDS）总出院人数
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100703';      
	insert into his_bi.kpi_master_m	
		select
		dg.month_id,
		'JX0100703' as kpi_code,
		count(distinct dg.pai_visit_id) as kpi_value,
		now() as update_time,
		count(distinct dg.pai_visit_id) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_drgs_patient_m dg
		where 1=1
		and dg.drgs_name = 'D00128'
		and dg.month_id = c_monthlist.month_id
		group by dg.month_id;


	--新生儿呼吸窘迫综合征（NRDS）次均费用
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100704';      
	insert into his_bi.kpi_master_m	
		select
		dg.month_id,
		'JX0100704' as kpi_code,
		round(sum(dg.total_fees)/count(distinct dg.pai_visit_id),2) as kpi_value,
		now() as update_time,
		round(sum(dg.total_fees)/count(distinct dg.pai_visit_id),2) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_drgs_patient_m dg
		where 1=1
		and dg.drgs_name = 'D00128'
		and dg.month_id = c_monthlist.month_id
		group by dg.month_id;


	--新生儿呼吸窘迫综合征（NRDS）总出院费用
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100705';      
	insert into his_bi.kpi_master_m	
		select
		dg.month_id,
		'JX0100705' as kpi_code,
		sum(dg.total_fees) as kpi_value,
		now() as update_time,
		sum(dg.total_fees) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_drgs_patient_m dg
		where 1=1
		and dg.drgs_name = 'D00128'
		and dg.month_id = c_monthlist.month_id
		group by dg.month_id;


  --新生儿呼吸窘迫综合征（NRDS）实际占用总床日数
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100706';      
	insert into his_bi.kpi_master_m	
		select
		dg.month_id,
		'JX0100706' as kpi_code,
		sum(dg.in_days) as kpi_value,
		now() as update_time,
		sum(dg.in_days) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_drgs_patient_m dg
		where 1=1
		and dg.drgs_name = 'D00128'
		and dg.month_id = c_monthlist.month_id
		group by dg.month_id;

	--新生儿呼吸窘迫综合征（NRDS）病死率
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100707';      
	insert into his_bi.kpi_master_m	
		select
		dg.month_id,
		'JX0100707' as kpi_code,
		count(distinct(case when dg.lyfs = '5' then dg.pai_visit_id end))/count(distinct dg.pai_visit_id) as kpi_value,
		now() as update_time,
		count(distinct(case when dg.lyfs = '5' then dg.pai_visit_id end))/count(distinct dg.pai_visit_id) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_drgs_patient_m dg
		where 1=1
		and dg.drgs_name = 'D00128'
		and dg.month_id = c_monthlist.month_id
		group by dg.month_id;



	--新生儿呼吸窘迫综合征（NRDS）死亡人数
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100708';      
	insert into his_bi.kpi_master_m	
		select
		dg.month_id,
		'JX0100708' as kpi_code,
		count(distinct(case when dg.lyfs = '5' then dg.pai_visit_id end)) as kpi_value,
		now() as update_time,
		count(distinct(case when dg.lyfs = '5' then dg.pai_visit_id end)) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_drgs_patient_m dg
		where 1=1
		and dg.drgs_name = 'D00128'
		and dg.month_id = c_monthlist.month_id
		group by dg.month_id;


	--儿童哮喘病种例数
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX01008';      
	insert into his_bi.kpi_master_m	
		select
		dg.month_id,
		'JX01008' as kpi_code,
		count(distinct dg.pai_visit_id) as kpi_value,
		now() as update_time,
		count(distinct dg.pai_visit_id) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_drgs_patient_m dg
		where 1=1
		and dg.drgs_name = 'D00225'
		and dg.month_id = c_monthlist.month_id
		group by dg.month_id;
		

	--儿童哮喘平均住院日
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100801';      
	insert into his_bi.kpi_master_m	
		select
		dg.month_id,
		'JX0100801' as kpi_code,
		round(sum(dg.in_days)/count(distinct dg.pai_visit_id),2) as kpi_value,
		now() as update_time,
		round(sum(dg.in_days)/count(distinct dg.pai_visit_id),2) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_drgs_patient_m dg
		where 1=1
		and dg.drgs_name = 'D00225'
		and dg.month_id = c_monthlist.month_id
		group by dg.month_id;


	--儿童哮喘出院患者占用总床日数
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100802';      
	insert into his_bi.kpi_master_m	
		select
		dg.month_id,
		'JX0100802' as kpi_code,
		sum(dg.in_days) as kpi_value,
		now() as update_time,
		sum(dg.in_days) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_drgs_patient_m dg
		where 1=1
		and dg.drgs_name = 'D00225'
		and dg.month_id = c_monthlist.month_id
		group by dg.month_id;

  --儿童哮喘总出院人数
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100803';      
	insert into his_bi.kpi_master_m	
		select
		dg.month_id,
		'JX0100803' as kpi_code,
		count(distinct dg.pai_visit_id) as kpi_value,
		now() as update_time,
		count(distinct dg.pai_visit_id) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_drgs_patient_m dg
		where 1=1
		and dg.drgs_name = 'D00225'
		and dg.month_id = c_monthlist.month_id
		group by dg.month_id;

	--儿童哮喘次均费用
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100804';      
	insert into his_bi.kpi_master_m	
		select
		dg.month_id,
		'JX0100804' as kpi_code,
		round(sum(dg.total_fees)/count(distinct dg.pai_visit_id),2) as kpi_value,
		now() as update_time,
		round(sum(dg.total_fees)/count(distinct dg.pai_visit_id),2) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_drgs_patient_m dg
		where 1=1
		and dg.drgs_name = 'D00225'
		and dg.month_id = c_monthlist.month_id
		group by dg.month_id;


	--儿童哮喘总出院费用
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100805';      
	insert into his_bi.kpi_master_m	
		select
		dg.month_id,
		'JX0100805' as kpi_code,
		sum(dg.total_fees) as kpi_value,
		now() as update_time,
		sum(dg.total_fees) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_drgs_patient_m dg
		where 1=1
		and dg.drgs_name = 'D00225'
		and dg.month_id = c_monthlist.month_id
		group by dg.month_id;


--儿童哮喘出院患者占用总床日数
delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100806';      
insert into his_bi.kpi_master_m	
		select
		dg.month_id,
		'JX0100806' as kpi_code,
		sum(dg.in_days) as kpi_value,
		now() as update_time,
		sum(dg.in_days) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_drgs_patient_m dg
		where 1=1
		and dg.drgs_name = 'D00225'
		and dg.month_id = c_monthlist.month_id
		group by dg.month_id;

	--儿童哮喘病死率
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100807';      
	insert into his_bi.kpi_master_m	
		select
		dg.month_id,
		'JX0100807' as kpi_code,
		count(distinct(case when dg.lyfs = '5' then dg.pai_visit_id end))/count(distinct dg.pai_visit_id) as kpi_value,
		now() as update_time,
		count(distinct(case when dg.lyfs = '5' then dg.pai_visit_id end))/count(distinct dg.pai_visit_id) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_drgs_patient_m dg
		where 1=1
		and dg.drgs_name = 'D00225'
		and dg.month_id = c_monthlist.month_id
		group by dg.month_id;


	--儿童哮喘死亡人数
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0100808';      
	insert into his_bi.kpi_master_m	
		select
		dg.month_id,
		'JX0100808' as kpi_code,
		count(distinct(case when dg.lyfs = '5' then dg.pai_visit_id end)) as kpi_value,
		now() as update_time,
		count(distinct(case when dg.lyfs = '5' then dg.pai_visit_id end)) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_drgs_patient_m dg
		where 1=1
		and dg.drgs_name = 'D00225'
		and dg.month_id = c_monthlist.month_id
		group by dg.month_id;
		

	--门诊处方数
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX01602';      
	insert into his_bi.kpi_master_m	
		select
		substr(dd.st_date,1,6) as month_id,
		'JX01602' as kpi_code,
		sum(value) as kpi_value,
		now() as update_time,
		sum(value) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dwd_outp_quantity_d dd 
		where dd.key = 'D00035'
		and substr(dd.st_date,1,6) = c_monthlist.month_id
		group by substr(dd.st_date,1,6);
		
	--抗菌药物使用强度(DDDs)
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX017';      
	insert into his_bi.kpi_master_m	
		select
		month_id,
		'JX017' as kpi_code,
		round(sum(kjyw_ddd_sum)/sum(in_days) * 100,2) as kpi_value,
		now() as update_time,
		round(sum(kjyw_ddd_sum)/sum(in_days) * 100,2) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_patient_info_m 
		where 1=1
		and month_id = c_monthlist.month_id
		group by month_id;
		
		
	--住院患者抗菌药物消耗量（累计DDD数）
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX01701';      
	insert into his_bi.kpi_master_m	
		select
		month_id,
		'JX01701' as kpi_code,
		sum(kjyw_ddd_sum) as kpi_value,
		now() as update_time,
		sum(kjyw_ddd_sum) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_patient_info_m 
		where 1=1
		and month_id = c_monthlist.month_id
		group by month_id;
		
		
	--出院者占用总床日
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX01702'; 
	insert into his_bi.kpi_master_m
		select 
		month_id,
		'JX01702' as kpi_code,
		sum(in_days) as kpi_value,
		now() as update_time,
		sum(in_days) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_patient_info_m d 
		where 1=1
		and month_id = c_monthlist.month_id
		group by month_id;
		
	--门诊患者使用基本药物人次数
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX01801';      
	insert into his_bi.kpi_master_m	
		select 
		am.month_id,
		'JX01801' as kpi_code,
		count(distinct am.patient_id||am.visit_id) as kpi_value,
		now() as update_time,
		count(distinct am.patient_id||am.visit_id) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_outp_patient_amount_m am 
		where am.basic_fees > 0
		and am.month_id = c_monthlist.month_id
		group by am.month_id;

  --同期门诊诊疗总人次数（不包括健康体检者及未开具药物处方患者）
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX01802';      
	insert into his_bi.kpi_master_m
		select 
		month_id,
		'JX01802' as kpi_code,
		COALESCE(count(distinct d.outp_visit_id),0) as kpi_value,
		now() as update_time,
		COALESCE(count(distinct d.outp_visit_id),0) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_outp_patient_info_m d 
		where 1=1
		and exists
		(
			select outp_visit_id from his_bi.dw_outp_patient_amount_m 
			where (pham_fees > 0 or tj_fees < 0)
			and outp_visit_id = d.outp_visit_id
		)
		and month_id = c_monthlist.month_id
		group by month_id;

	--出院患者使用基本药物人次数
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX01901';      
	insert into his_bi.kpi_master_m	
		select 
		am.month_id,
		'JX01901' as kpi_code,
		count(distinct am.pai_visit_id) as kpi_value,
		now() as update_time,
		count(distinct am.pai_visit_id) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_patient_amount_m am 
		where am.basic_fees > 0
		and am.month_id = c_monthlist.month_id
		group by am.month_id;
		
		
  --同期出院总人次数（不包括未用药患者）
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX01902';      
	insert into his_bi.kpi_master_m
		select 
		month_id,
		'JX01902' as kpi_code,
		COALESCE(count(distinct d.pai_visit_id),0) as kpi_value,
		now() as update_time,
		COALESCE(count(distinct d.pai_visit_id),0) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_patient_info_m d 
		where 1=1
		and exists
		(
			select pai_visit_id from his_bi.dw_inp_patient_amount_m 
			where pham_fees > 0
			and pai_visit_id = d.pai_visit_id
		)
		and month_id = c_monthlist.month_id
		group by month_id;
		
	--出院人数
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX01605';      
	insert into his_bi.kpi_master_m
		select 
		month_id,
		'JX01605' as kpi_code,
		COALESCE(count(distinct d.pai_visit_id),0) as kpi_value,
		now() as update_time,
		COALESCE(count(distinct d.pai_visit_id),0) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_patient_info_m d 
		where 1=1
		and month_id = c_monthlist.month_id
		group by month_id;		
		
	--实际占用总床日数
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX02501';      
	insert into his_bi.kpi_master_m	
		select 
		to_char(stat_date,'yyyymm') as month_id,
		'JX02501' as kpi_code,
		sum(bed_used) as kpi_value,
		now() as update_time,
		sum(bed_used) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_dept_work_d am
		where 1=1
		and to_char(stat_date,'yyyymm') = c_monthlist.month_id
		group by to_char(stat_date,'yyyymm');
	
	
	--医院实际开放床位数
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX02602';      
	insert into his_bi.kpi_master_m	
		select 
		to_char(stat_date,'yyyymm') as month_id,
		'JX02602' as kpi_code,
		sum(sy_num) as kpi_value,
		now() as update_time,
		sum(sy_num) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_dept_work_d am
		where 1=1
		and to_char(stat_date,'yyyymm') = c_monthlist.month_id
		group by to_char(stat_date,'yyyymm');
	
	
	--门诊收入	
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX02701';      
	insert into his_bi.kpi_master_m	
		select 
		am.month_id as month_id,
		'JX02701' as kpi_code,
		sum(am.total_fees) as kpi_value,
		now() as update_time,
		sum(am.total_fees) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_outp_patient_amount_m am
		where 1=1
		and am.month_id = c_monthlist.month_id
		group by am.month_id;
		
		
	--医疗收入
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX02702';
	insert into his_bi.kpi_master_m		
		select 
		ff.month_id,
		'JX02702' as kpi_code,
		sum(fees) as kpi_value,
		now() as update_time,
		sum(fees) as self_value,
		null as check_flag,
		null as check_comm
		from
		(
			select 
			am.month_id,
			sum(total_fees) as fees
			from his_bi.dw_outp_patient_amount_m am
			where 1=1
			and am.month_id = c_monthlist.month_id
			group by am.month_id
			union
			select 
			bm.month_id,
			sum(total_fees) as fees
			from his_bi.dw_inp_patient_amount_m bm
			where 1=1
			and bm.month_id = c_monthlist.month_id
			group by bm.month_id
		)ff
		group by ff.month_id;

	--门诊收入	
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX02802';      
	insert into his_bi.kpi_master_m	
		select 
		am.month_id as month_id,
		'JX02802' as kpi_code,
		sum(am.total_fees) as kpi_value,
		now() as update_time,
		sum(am.total_fees) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_outp_patient_amount_m am
		where 1=1
		and am.month_id = c_monthlist.month_id
		group by am.month_id;


	--住院收入
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX02901';
	insert into his_bi.kpi_master_m
		select 
		am.month_id as month_id,
		'JX02901' as kpi_code,
		sum(am.total_fees) as kpi_value,
		now() as update_time,
		sum(am.total_fees) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_patient_amount_m am
		where 1=1
		and am.month_id = c_monthlist.month_id
		group by am.month_id;
		
		
		
	--医疗收入
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX02902';
	insert into his_bi.kpi_master_m		
		select 
		ff.month_id,
		'JX02902' as kpi_code,
		sum(fees) as kpi_value,
		now() as update_time,
		sum(fees) as self_value,
		null as check_flag,
		null as check_comm
		from
		(
			select 
			am.month_id,
			sum(total_fees) as fees
			from his_bi.dw_outp_patient_amount_m am
			where 1=1
			and am.month_id = c_monthlist.month_id
			group by am.month_id
			union
			select 
			bm.month_id,
			sum(total_fees) as fees
			from his_bi.dw_inp_patient_amount_m bm
			where 1=1
			and bm.month_id = c_monthlist.month_id
			group by bm.month_id
		)ff
		group by ff.month_id;
		
		
	--医疗服务收入
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX03101';
	insert into his_bi.kpi_master_m		
		select 
		ff.month_id,
		'JX03101' as kpi_code,
		sum(fees) as kpi_value,
		now() as update_time,
		sum(fees) as self_value,
		null as check_flag,
		null as check_comm
		from
		(
			select 
			am.month_id,
			sum(service_fees) as fees
			from his_bi.dw_outp_patient_amount_m am
			where 1=1
			and am.month_id = c_monthlist.month_id
			group by am.month_id
			union
			select 
			bm.month_id,
			sum(service_fees) as fees
			from his_bi.dw_inp_patient_amount_m bm
			where 1=1
			and bm.month_id = c_monthlist.month_id
			group by bm.month_id
		)ff
		group by ff.month_id;


	--药品收入
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX03102';
	insert into his_bi.kpi_master_m		
		select 
		ff.month_id,
		'JX03102' as kpi_code,
		sum(fees) as kpi_value,
		now() as update_time,
		sum(fees) as self_value,
		null as check_flag,
		null as check_comm
		from
		(
			select 
			am.month_id,
			sum(pham_fees) as fees
			from his_bi.dw_outp_patient_amount_m am
			where 1=1
			and am.month_id = c_monthlist.month_id
			group by am.month_id
			union
			select 
			bm.month_id,
			sum(pham_fees) as fees
			from his_bi.dw_inp_patient_amount_m bm
			where 1=1
			and bm.month_id = c_monthlist.month_id
			group by bm.month_id
		)ff
		group by ff.month_id;
		
	--卫生材料收入
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX03103';
	insert into his_bi.kpi_master_m		
		select 
		ff.month_id,
		'JX03103' as kpi_code,
		sum(fees) as kpi_value,
		now() as update_time,
		sum(fees) as self_value,
		null as check_flag,
		null as check_comm
		from
		(
			select 
			am.month_id,
			sum(material_fees) as fees
			from his_bi.dw_outp_patient_amount_m am
			where 1=1
			and am.month_id = c_monthlist.month_id
			group by am.month_id
			union
			select 
			bm.month_id,
			sum(material_fees) as fees
			from his_bi.dw_inp_patient_amount_m bm
			where 1=1
			and bm.month_id = c_monthlist.month_id
			group by bm.month_id
		)ff
		group by ff.month_id;		
		
	--检查收入
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX03104';
	insert into his_bi.kpi_master_m		
		select 
		ff.month_id,
		'JX03104' as kpi_code,
		sum(fees) as kpi_value,
		now() as update_time,
		sum(fees) as self_value,
		null as check_flag,
		null as check_comm
		from
		(
			select 
			am.month_id,
			sum(check_fees) as fees
			from his_bi.dw_outp_patient_amount_m am
			where 1=1
			and am.month_id = c_monthlist.month_id
			group by am.month_id
			union
			select 
			bm.month_id,
			sum(check_fees) as fees
			from his_bi.dw_inp_patient_amount_m bm
			where 1=1
			and bm.month_id = c_monthlist.month_id
			group by bm.month_id
		)ff
		group by ff.month_id;	

	--化验收入
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX03105';
	insert into his_bi.kpi_master_m		
		select 
		ff.month_id,
		'JX03105' as kpi_code,
		sum(fees) as kpi_value,
		now() as update_time,
		sum(fees) as self_value,
		null as check_flag,
		null as check_comm
		from
		(
			select 
			am.month_id,
			sum(inspect_fees) as fees
			from his_bi.dw_outp_patient_amount_m am
			where 1=1
			and am.month_id = c_monthlist.month_id
			group by am.month_id
			union
			select 
			bm.month_id,
			sum(inspect_fees) as fees
			from his_bi.dw_inp_patient_amount_m bm
			where 1=1
			and bm.month_id = c_monthlist.month_id
			group by bm.month_id
		)ff
		group by ff.month_id;	


		
	--医疗收入
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX03106';
	insert into his_bi.kpi_master_m		
		select 
		ff.month_id,
		'JX03106' as kpi_code,
		sum(fees) as kpi_value,
		now() as update_time,
		sum(fees) as self_value,
		null as check_flag,
		null as check_comm
		from
		(
			select 
			am.month_id,
			sum(total_fees) as fees
			from his_bi.dw_outp_patient_amount_m am
			where 1=1
			and am.month_id = c_monthlist.month_id
			group by am.month_id
			union
			select 
			bm.month_id,
			sum(total_fees) as fees
			from his_bi.dw_inp_patient_amount_m bm
			where 1=1
			and bm.month_id = c_monthlist.month_id
			group by bm.month_id
		)ff
		group by ff.month_id;
		
		--辅助用药收入
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX03201';
	insert into his_bi.kpi_master_m		
		select 
		ff.month_id,
		'JX03201' as kpi_code,
		sum(fees) as kpi_value,
		now() as update_time,
		sum(fees) as self_value,
		null as check_flag,
		null as check_comm
		from
		(
			select 
			am.month_id,
			sum(support_fees) as fees
			from his_bi.dw_outp_patient_amount_m am
			where 1=1
			and am.month_id = c_monthlist.month_id
			group by am.month_id
			union
			select 
			bm.month_id,
			sum(support_fees) as fees
			from his_bi.dw_inp_patient_amount_m bm
			where 1=1
			and bm.month_id = c_monthlist.month_id
			group by bm.month_id
		)ff
		group by ff.month_id;
	
	
	--药品总收入
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX03202';
	insert into his_bi.kpi_master_m		
		select 
		ff.month_id,
		'JX03202' as kpi_code,
		sum(fees) as kpi_value,
		now() as update_time,
		sum(fees) as self_value,
		null as check_flag,
		null as check_comm
		from
		(
			select 
			am.month_id,
			sum(pham_fees) as fees
			from his_bi.dw_outp_patient_amount_m am
			where 1=1
			and am.month_id = c_monthlist.month_id
			group by am.month_id
			union
			select 
			bm.month_id,
			sum(pham_fees) as fees
			from his_bi.dw_inp_patient_amount_m bm
			where 1=1
			and bm.month_id = c_monthlist.month_id
			group by bm.month_id
		)ff
		group by ff.month_id;


	--总收入
	/*delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX03402';
	insert into his_bi.kpi_master_m		
		select 
		ff.month_id,
		'JX03402' as kpi_code,
		sum(fees) as kpi_value,
		now() as update_time,
		sum(fees) as self_value,
		null as check_flag,
		null as check_comm
		from
		(
			select 
			am.month_id,
			sum(total_fees) as fees
			from his_bi.dw_outp_patient_amount_m am
			where 1=1
			and am.month_id = c_monthlist.month_id
			group by am.month_id
			union
			select 
			bm.month_id,
			sum(total_fees) as fees
			from his_bi.dw_inp_patient_amount_m bm
			where 1=1
			and bm.month_id = c_monthlist.month_id
			group by bm.month_id
		)ff
		group by ff.month_id;*/


	--医疗收入
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX0350101';
	insert into his_bi.kpi_master_m		
		select 
		ff.month_id,
		'JX0350101' as kpi_code,
		sum(fees) as kpi_value,
		now() as update_time,
		sum(fees) as self_value,
		null as check_flag,
		null as check_comm
		from
		(
			select 
			am.month_id,
			sum(total_fees) as fees
			from his_bi.dw_outp_patient_amount_m am
			where 1=1
			and am.month_id = c_monthlist.month_id
			group by am.month_id
			union
			select 
			bm.month_id,
			sum(total_fees) as fees
			from his_bi.dw_inp_patient_amount_m bm
			where 1=1
			and bm.month_id = c_monthlist.month_id
			group by bm.month_id
		)ff
		group by ff.month_id;
	
  
	
	--医疗收入
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX03701';
	insert into his_bi.kpi_master_m		
		select 
		ff.month_id,
		'JX03701' as kpi_code,
		sum(fees) as kpi_value,
		now() as update_time,
		sum(fees) as self_value,
		null as check_flag,
		null as check_comm
		from
		(
			select 
			am.month_id,
			sum(total_fees) as fees
			from his_bi.dw_outp_patient_amount_m am
			where 1=1
			and am.month_id = c_monthlist.month_id
			group by am.month_id
			union
			select 
			bm.month_id,
			sum(total_fees) as fees
			from his_bi.dw_inp_patient_amount_m bm
			where 1=1
			and bm.month_id = c_monthlist.month_id
			group by bm.month_id
		)ff
		group by ff.month_id;


	

	
	--门诊收入	
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX03802';      
	insert into his_bi.kpi_master_m	
		select 
		am.month_id as month_id,
		'JX03802' as kpi_code,
		sum(am.total_fees) as kpi_value,
		now() as update_time,
		sum(am.total_fees) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_outp_patient_amount_m am
		where 1=1
		and am.month_id = c_monthlist.month_id
		group by am.month_id;
		
		
	--门诊人次	
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX03803';      
	insert into his_bi.kpi_master_m	
		select 
		am.month_id as month_id,
		'JX03803' as kpi_code,
		count(distinct outp_visit_id) as kpi_value,
		now() as update_time,
		count(distinct outp_visit_id) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_outp_patient_info_m am
		where 1=1
		and am.month_id = c_monthlist.month_id
		group by am.month_id;

	--门诊患者次均药品费用	
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX03901';      
	insert into his_bi.kpi_master_m			
		select
		c_monthlist.month_id,
		'JX03901' as kpi_code,
		case when sum(patient_num)<>0 then round(sum(pham_fees)/sum(patient_num),4) else null end  as kpi_value,
		now() as update_time,
		case when sum(patient_num)<>0 then round(sum(pham_fees)/sum(patient_num),4) else null end as self_value,
		null as check_flag,
		null as check_comm
		from
		(
				select 
				am.month_id as month_id,
				sum(am.pham_fees) as pham_fees,
				0 as patient_num
				from his_bi.dw_outp_patient_amount_m am
				where 1=1
				and am.month_id = c_monthlist.month_id
				group by am.month_id
				union
				select 
				bm.month_id as month_id,
				0 as pham_fees,
				count(distinct bm.outp_visit_id) as patient_num
				from his_bi.dw_outp_patient_info_m bm
				where 1=1
				and bm.month_id = c_monthlist.month_id
				group by bm.month_id
		)ff;
		

	--门诊药品收入	
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX03902';      
	insert into his_bi.kpi_master_m	
		select 
		am.month_id as month_id,
		'JX03902' as kpi_code,
		sum(am.pham_fees) as kpi_value,
		now() as update_time,
		sum(am.pham_fees) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_outp_patient_amount_m am
		where 1=1
		and am.month_id = c_monthlist.month_id
		group by am.month_id;
		
	--住院收入
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX03002';
	insert into his_bi.kpi_master_m
		select 
		am.month_id as month_id,
		'JX03002' as kpi_code,
		sum(am.total_fees) as kpi_value,
		now() as update_time,
		sum(am.total_fees) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_patient_amount_m am
		where 1=1
		and am.month_id = c_monthlist.month_id
		group by am.month_id;
	
	
	--门诊人次	
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX03903';      
	insert into his_bi.kpi_master_m	
		select 
		am.month_id as month_id,
		'JX03903' as kpi_code,
		count(distinct outp_visit_id) as kpi_value,
		now() as update_time,
		count(distinct outp_visit_id) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_outp_patient_info_m am
		where 1=1
		and am.month_id = c_monthlist.month_id
		group by am.month_id;
	
	--出院均次医药费用	
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX04001';      
	insert into his_bi.kpi_master_m	
		select 
		am.month_id as month_id,
		'JX04001' as kpi_code,
		round(sum(am.total_fees)/count(distinct am.pai_visit_id),2) as kpi_value,
		now() as update_time,
		round(sum(am.total_fees)/count(distinct am.pai_visit_id),2) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_patient_info_m am
		where 1=1
		and am.month_id = c_monthlist.month_id
		group by am.month_id;
		
		
	--住院收入
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX04002';
	insert into his_bi.kpi_master_m
		select 
		am.month_id as month_id,
		'JX04002' as kpi_code,
		sum(am.total_fees) as kpi_value,
		now() as update_time,
		sum(am.total_fees) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_patient_amount_m am
		where 1=1
		and am.month_id = c_monthlist.month_id
		group by am.month_id;
	
    
	--实际占用总床日数
  delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX04003';
	insert into his_bi.kpi_master_m
		select 
		month_id,
		'JX04003' as kpi_code,
		sum(d.in_days) as kpi_value,
		now() as update_time,
		sum(d.in_days) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_patient_info_m d 
		where 1=1
		and month_id = c_monthlist.month_id
		group by month_id;
	

	--出院者占用总床日
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX04004'; 
	insert into his_bi.kpi_master_m
		select 
		month_id,
		'JX04004' as kpi_code,
		sum(d.in_days) as kpi_value,
		now() as update_time,
		sum(d.in_days) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_patient_info_m d 
		where 1=1
		and month_id = c_monthlist.month_id
		group by month_id;
	
	
	--出院人数
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX04005';      
	insert into his_bi.kpi_master_m
		select 
		month_id,
		'JX04005' as kpi_code,
		COALESCE(count(distinct d.pai_visit_id),0) as kpi_value,
		now() as update_time,
		COALESCE(count(distinct d.pai_visit_id),0) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_patient_info_m d 
		where 1=1
		and month_id = c_monthlist.month_id
		group by month_id;	

	--出院患者次均药品费用
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX04101';      
	insert into his_bi.kpi_master_m			
		select
		c_monthlist.month_id,
		'JX04101' as kpi_code,
		round(sum(pham_fees)/sum(patient_num),2) as kpi_value,
		now() as update_time,
		round(sum(pham_fees)/sum(patient_num),2) as self_value,
		null as check_flag,
		null as check_comm
		from
		(
				select 
				am.month_id as month_id,
				sum(am.pham_fees) as pham_fees,
				0 as patient_num
				from his_bi.dw_inp_patient_amount_m am
				where 1=1
				and am.month_id = c_monthlist.month_id
				group by am.month_id
				union
				select 
				bm.month_id as month_id,
				0 as pham_fees,
				count(distinct bm.pai_visit_id) as patient_num
				from his_bi.dw_inp_patient_info_m bm
				where 1=1
				and bm.month_id = c_monthlist.month_id
				group by bm.month_id
		)ff;



	--出院患者药品费用
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX04102';
	insert into his_bi.kpi_master_m
		select 
		am.month_id as month_id,
		'JX04102' as kpi_code,
		sum(am.pham_fees) as kpi_value,
		now() as update_time,
		sum(am.pham_fees) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_patient_amount_m am
		where 1=1
		and am.month_id = c_monthlist.month_id
		group by am.month_id;
		
	--实际占用总床日数
  delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX04103';
	insert into his_bi.kpi_master_m
		select 
		month_id,
		'JX04103' as kpi_code,
		sum(d.in_days) as kpi_value,
		now() as update_time,
		sum(d.in_days) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_patient_info_m d 
		where 1=1
		and month_id = c_monthlist.month_id
		group by month_id;
	

	--出院者占用总床日
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX04104'; 
	insert into his_bi.kpi_master_m
		select 
		month_id,
		'JX04104' as kpi_code,
		sum(d.in_days) as kpi_value,
		now() as update_time,
		sum(d.in_days) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_patient_info_m d 
		where 1=1
		and month_id = c_monthlist.month_id
		group by month_id;


	--出院人数
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX04105';      
	insert into his_bi.kpi_master_m
		select 
		month_id,
		'JX04105' as kpi_code,
		COALESCE(count(distinct d.pai_visit_id),0) as kpi_value,
		now() as update_time,
		COALESCE(count(distinct d.pai_visit_id),0) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_inp_patient_info_m d 
		where 1=1
		and month_id = c_monthlist.month_id
		group by month_id;	
		
	---门诊患者基本药物处方占比
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX018';
	insert into his_bi.kpi_master_m
		select
		t1.month_id,
		'JX018' as kpi_code,
		round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as kpi_value,
		now() as update_time,
		round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as self_value,
		null as check_flag,
		null as check_comm
		from
		his_bi.kpi_master_m t1
		left join his_bi.kpi_master_m t2 on t1.kpi_code = t2.kpi_code and t1.month_id = t2.month_id 
		and t2.kpi_code='JX01801'
		where
		t1.month_id=c_monthlist.month_id
		and t1.kpi_code in('JX01801','JX01802')
		group by 
		t1.month_id;

	---19.住院患者基本药物使用率
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX019';
	insert into his_bi.kpi_master_m
		select
		t1.month_id,
		'JX019' as kpi_code,
		round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as kpi_value,
		now() as update_time,
		round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as self_value,
		null as check_flag,
		null as check_comm
		from
		his_bi.kpi_master_m t1
		left join his_bi.kpi_master_m t2 on t1.kpi_code = t2.kpi_code and t1.month_id = t2.month_id 
		and t2.kpi_code='JX01901'
		where
		t1.month_id=c_monthlist.month_id
		and t1.kpi_code in('JX01901','JX01902')
		group by 
		t1.month_id;

	---门诊患者预约后平均等待时间
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX023';
	insert into his_bi.kpi_master_m
		select
		left(t1.jzsj,6) as month_id,
		'JX023' as kpi_code,
		COALESCE(avg(t1.qd_jf),0) as kpi_value,
		now() as update_time,
		COALESCE(avg(t1.qd_jf),0)as self_value,
		null as check_flag,
		null as check_comm
		from
		his_bi.dw_outp_fsjz t1
		where
		left(t1.jzsj,6)=c_monthlist.month_id
		and t1.qd_jf<2880
		group by 
		left(t1.jzsj,6);

	---27.门诊收入占医疗收入比例
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX027';
	insert into his_bi.kpi_master_m
		select
		t1.month_id,
		'JX027' as kpi_code,
		round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as kpi_value,
		now() as update_time,
		round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as self_value,
		null as check_flag,
		null as check_comm
		from
		his_bi.kpi_master_m t1
		left join his_bi.kpi_master_m t2 on t1.kpi_code = t2.kpi_code and t1.month_id = t2.month_id 
		and t2.kpi_code='JX02701'
		where
		t1.month_id=c_monthlist.month_id
		and t1.kpi_code in('JX02701','JX02702')
		group by 
		t1.month_id;

	---29.住院收入占医疗收入比例
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX029';
	insert into his_bi.kpi_master_m
		select
		t1.month_id,
		'JX029' as kpi_code,
		round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as kpi_value,
		now() as update_time,
		round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as self_value,
		null as check_flag,
		null as check_comm
		from
		his_bi.kpi_master_m t1
		left join his_bi.kpi_master_m t2 on t1.kpi_code = t2.kpi_code and t1.month_id = t2.month_id 
		and t2.kpi_code='JX02901'
		where
		t1.month_id=c_monthlist.month_id
		and t1.kpi_code in('JX02901','JX02902')
		group by 
		t1.month_id;

	---31.医疗服务收入（不含药品、耗材、检查检验收入）占医疗收入比例▲
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX031';
	insert into his_bi.kpi_master_m
		select
		t1.month_id,
		'JX031' as kpi_code,
		round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as kpi_value,
		now() as update_time,
		round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as self_value,
		null as check_flag,
		null as check_comm
		from
		his_bi.kpi_master_m t1
		left join his_bi.kpi_master_m t2 on t1.kpi_code = t2.kpi_code and t1.month_id = t2.month_id 
		and t2.kpi_code='JX03101'
		where
		t1.month_id=c_monthlist.month_id
		and t1.kpi_code in('JX03101','JX03106')
		group by 
		t1.month_id;

	---32.辅助用药收入占比
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX032';
	insert into his_bi.kpi_master_m
		select
		t1.month_id,
		'JX032' as kpi_code,
		round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as kpi_value,
		now() as update_time,
		round(COALESCE(max(t2.kpi_value),0)/max(t1.kpi_value),5)*100 as self_value,
		null as check_flag,
		null as check_comm
		from
		his_bi.kpi_master_m t1
		left join his_bi.kpi_master_m t2 on t1.kpi_code = t2.kpi_code and t1.month_id = t2.month_id 
		and t2.kpi_code='JX03201'
		where
		t1.month_id=c_monthlist.month_id
		and t1.kpi_code in('JX03201','JX03202')
		group by 
		t1.month_id;	

	--医疗收入增幅
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX037';
	insert into his_bi.kpi_master_m		
		select 
		c_monthlist.month_id,
		'JX037' as kpi_code,
		case when sum(last_fee) <> 0 then round((sum(fees)-sum(last_fee))/sum(last_fee),2)*100 else null end as kpi_value,
		now() as update_time,
		case when sum(last_fee) <> 0 then round((sum(fees)-sum(last_fee))/sum(last_fee),2)*100 else null end as self_value,
		null as check_flag,
		null as check_comm
		from
		(
			select 
			am.month_id,
			sum(total_fees) as fees,
			0 as last_fee
			from his_bi.dw_outp_patient_amount_m am
			where 1=1
			and am.month_id = c_monthlist.month_id
			group by am.month_id
			union
			select 
			bm.month_id,
			sum(total_fees) as fees,
			0 as last_fee
			from his_bi.dw_inp_patient_amount_m bm
			where 1=1
			and bm.month_id = c_monthlist.month_id
			group by bm.month_id
			union
			select 
			cm.month_id,
			0 as fees,
			sum(total_fees) as last_fee
			from his_bi.dw_outp_patient_amount_m cm
			where 1=1
			and cm.month_id = TO_CHAR(to_date(c_monthlist.month_id,'yyyymm') + INTERVAL '-1 MONTH','yyyymm') 
			group by cm.month_id
			union
			select 
			dm.month_id,
			0 as fees,
			sum(total_fees) as last_fee
			from his_bi.dw_inp_patient_amount_m dm
			where 1=1
			and dm.month_id = TO_CHAR(to_date(c_monthlist.month_id,'yyyymm') + INTERVAL '-1 MONTH','yyyymm') 
			group by dm.month_id
		)ff
		group by c_monthlist.month_id;	
		
  --门诊次均费用增幅
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX038';      
	insert into his_bi.kpi_master_m	
		select 
		c_monthlist.month_id,
		'JX038' as kpi_code,
		case when max(ff.last_jc_fees) <>0 then round((max(ff.jc_fees)-max(ff.last_jc_fees))/max(ff.last_jc_fees),4)*100 else null end as kpi_value,
		now() as update_time,
		case when max(ff.last_jc_fees) <>0 then round((max(ff.jc_fees)-max(ff.last_jc_fees))/max(ff.last_jc_fees),4)*100 else null end as self_value,
		null as check_flag,
		null as check_comm
		from
		(
			select 
			am.month_id as month_id,
			round(sum(am.total_fees)/count(distinct am.outp_visit_id),2) as jc_fees,
			0 as last_jc_fees
			from his_bi.dw_outp_patient_info_m am
			where 1=1
			and am.month_id = c_monthlist.month_id
			group by am.month_id
			union
			select 
			am.month_id as month_id,
			0 as jc_fees,
			round(sum(am.total_fees)/count(distinct am.outp_visit_id),2) as last_jc_fees
			from his_bi.dw_outp_patient_info_m am
			where 1=1
			and am.month_id = TO_CHAR(to_date(c_monthlist.month_id,'yyyymm') + INTERVAL '-1 MONTH','yyyymm')
			group by am.month_id
		)ff;

	--门诊患者次均医药费用	
	delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX03801';      
	insert into his_bi.kpi_master_m	
		select 
		am.month_id as month_id,
		'JX03801' as kpi_code,
		round(sum(am.total_fees)/count(distinct am.outp_visit_id),2) as kpi_value,
		now() as update_time,
		round(sum(am.total_fees)/count(distinct am.outp_visit_id),2) as self_value,
		null as check_flag,
		null as check_comm
		from his_bi.dw_outp_patient_info_m am
		where 1=1
		and am.month_id = c_monthlist.month_id
		group by am.month_id;
		
	---住院次均药品费用增幅
  delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX041';
	insert into his_bi.kpi_master_m
    select 
    c_monthlist.month_id,
    'JX041' as kpi_code,
    case when max(ff.last_jc_fees) <>0 then round((max(ff.jc_fees)-max(ff.last_jc_fees))/max(ff.last_jc_fees),4)*100 else null end as kpi_value,
    now() as update_time,
    case when max(ff.last_jc_fees) <>0 then round((max(ff.jc_fees)-max(ff.last_jc_fees))/max(ff.last_jc_fees),4)*100 else null end as self_value,
    null as check_flag,
    null as check_comm
    from
    (
      select 
      am.month_id as month_id,
      am.kpi_value as jc_fees,
      0 as last_jc_fees
      from his_bi.kpi_master_m am
      where 1=1
      and am.month_id = c_monthlist.month_id
            and am.kpi_code='JX04101'
      group by am.month_id,am.kpi_value
      union
      select 
      am.month_id as month_id,
      0 as jc_fees,
      am.kpi_value as last_jc_fees
      from his_bi.kpi_master_m am
      where 1=1
            and am.kpi_code='JX04101'
      and am.month_id = TO_CHAR(to_date(c_monthlist.month_id,'yyyymm') + INTERVAL '-1 MONTH','yyyymm')
      group by am.month_id, am.kpi_value
    )ff;



  ---住院次均费用增幅
  delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX040';  
  insert into his_bi.kpi_master_m	
    select 
    c_monthlist.month_id,
    'JX040' as kpi_code,
    case when max(ff.last_jc_fees) <>0 then round((max(ff.jc_fees)-max(ff.last_jc_fees))/max(ff.last_jc_fees),4)*100 else null end as kpi_value,
    now() as update_time,
    case when max(ff.last_jc_fees) <>0 then round((max(ff.jc_fees)-max(ff.last_jc_fees))/max(ff.last_jc_fees),4)*100 else null end as self_value,
    null as check_flag,
    null as check_comm
    from
    (
      select 
      am.month_id as month_id,
      am.kpi_value as jc_fees,
      0 as last_jc_fees
      from his_bi.kpi_master_m am
      where 1=1
      and am.month_id = c_monthlist.month_id
            and am.kpi_code='JX04001'
      group by am.month_id,am.kpi_value
      union
      select 
      am.month_id as month_id,
      0 as jc_fees,
      am.kpi_value as last_jc_fees
      from his_bi.kpi_master_m am
      where 1=1
            and am.kpi_code='JX04001'
      and am.month_id = TO_CHAR(to_date(c_monthlist.month_id,'yyyymm') + INTERVAL '-1 MONTH','yyyymm')
      group by am.month_id, am.kpi_value
    )ff;


  --门诊次均费用增幅
  delete from his_bi.kpi_master_m where month_id = c_monthlist.month_id and kpi_code = 'JX039';   
	insert into his_bi.kpi_master_m
    select 
    c_monthlist.month_id,
    'JX039' as kpi_code,
    case when max(ff.last_jc_fees) <>0 then round((max(ff.jc_fees)-max(ff.last_jc_fees))/max(ff.last_jc_fees),4)*100 else null end as kpi_value,
    now() as update_time,
    case when max(ff.last_jc_fees) <>0 then round((max(ff.jc_fees)-max(ff.last_jc_fees))/max(ff.last_jc_fees),4)*100 else null end as self_value,
    null as check_flag,
    null as check_comm
    from
    (
      select 
      am.month_id as month_id,
      am.kpi_value as jc_fees,
      0 as last_jc_fees
      from his_bi.kpi_master_m am
      where 1=1
      and am.month_id = c_monthlist.month_id
            and am.kpi_code='JX03901'
      group by am.month_id,am.kpi_value
      union
      select 
      am.month_id as month_id,
      0 as jc_fees,
      am.kpi_value as last_jc_fees
      from his_bi.kpi_master_m am
      where 1=1
            and am.kpi_code='JX03901'
      and am.month_id = TO_CHAR(to_date(c_monthlist.month_id,'yyyymm') + INTERVAL '-1 MONTH','yyyymm')
      group by am.month_id, am.kpi_value
    )ff;

   end loop;
   RETURN 'SUCCESS';  
END;
$$;

alter function fun_kpi_master_m_wy(varchar, varchar)
  owner to postgres;

